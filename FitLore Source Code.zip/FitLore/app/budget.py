"""Fail-closed local allowances, shared by processes using this runtime directory.

These count attempts, not dollars; they cannot inspect provider credit balances.
"""
import os
import sqlite3
from pathlib import Path


class BudgetBlocked(RuntimeError):
    pass


BASE_LIMITS = {"generation": 10, "retrieval": 10, "ingestion": 1, "vector_write": 1}


def _limits(db):
    limits = dict(BASE_LIMITS)
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='ingestion_retry_grant'").fetchone():
        limits["ingestion"] += db.execute("SELECT COUNT(*) FROM ingestion_retry_grant").fetchone()[0]
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='quality_evaluation_grant'").fetchone():
        if db.execute('SELECT COUNT(*) FROM quality_evaluation_grant').fetchone()[0]:
            limits['retrieval'] += 15
            limits['generation'] += 15
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='quality_retest_grant'").fetchone():
        if db.execute('SELECT COUNT(*) FROM quality_retest_grant').fetchone()[0]:
            limits['retrieval'] += 15
            limits['generation'] += 15
    return limits


def current_limits():
    path = Path(os.getenv("PATCHBRIEF_BUDGET_DB", "data/runtime/budget.sqlite3"))
    if not path.exists():
        return dict(BASE_LIMITS)
    with sqlite3.connect(path, timeout=10) as db:
        return _limits(db)


def grant_ingestion_retry(reason):
    """Explicit operator action only; preserves attempts and permits at most one retry.

    Not exposed by an API and never called by ingestion or provider error handlers.
    """
    require_cloud()
    if not isinstance(reason, str) or not 10 <= len(reason) <= 500:
        raise ValueError("Record a specific retry reason")
    path = Path(os.getenv("PATCHBRIEF_BUDGET_DB", "data/runtime/budget.sqlite3"))
    if not path.exists():
        raise BudgetBlocked("No ingestion attempt to retry")
    with sqlite3.connect(path, timeout=10) as db:
        db.execute("BEGIN IMMEDIATE")
        row = db.execute("SELECT attempts FROM usage WHERE kind='ingestion'").fetchone()
        if not row or row[0] != 1 or _limits(db)["ingestion"] != 1:
            raise BudgetBlocked("A retry may be granted only once, after the first ingestion attempt")
        db.execute("CREATE TABLE ingestion_retry_grant (id INTEGER PRIMARY KEY CHECK(id=1), reason TEXT NOT NULL, created TEXT DEFAULT CURRENT_TIMESTAMP)")
        db.execute("INSERT INTO ingestion_retry_grant(id,reason) VALUES(1,?)", (reason,))


def require_cloud():
    if os.getenv("PATCHBRIEF_ALLOW_CLOUD", "false").lower() != "true":
        raise BudgetBlocked("Cloud calls are locked. Verify provider credit-only billing before setting PATCHBRIEF_ALLOW_CLOUD=true.")


def grant_quality_evaluation(reason):
    """Operator-only, single 15-question allowance; never resets existing usage.

    Explicit user request for quality evaluation and verified provider billing
    are prerequisites. No route or retry handler invokes this function.
    """
    require_cloud()
    if not isinstance(reason, str) or not 20 <= len(reason) <= 500:
        raise ValueError('Record the evaluation authorization and billing check')
    path = Path(os.getenv('PATCHBRIEF_BUDGET_DB', 'data/runtime/budget.sqlite3'))
    if not path.exists():
        raise BudgetBlocked('Verify the existing ledger before granting evaluation attempts')
    with sqlite3.connect(path, timeout=10) as db:
        db.execute('BEGIN IMMEDIATE')
        db.execute('CREATE TABLE IF NOT EXISTS quality_evaluation_grant(id INTEGER PRIMARY KEY CHECK(id=1), reason TEXT NOT NULL, created TEXT DEFAULT CURRENT_TIMESTAMP)')
        if db.execute('SELECT 1 FROM quality_evaluation_grant').fetchone():
            raise BudgetBlocked('The single quality evaluation allowance was already granted')
        db.execute('INSERT INTO quality_evaluation_grant(id,reason) VALUES(1,?)', (reason,))


def grant_quality_retest(reason):
    """One operator-authorized 15-case comparison after an actual corrective change."""
    require_cloud()
    if not isinstance(reason,str) or not 30<=len(reason)<=500:
        raise ValueError('Record the corrective change and provider billing recheck')
    path=Path(os.getenv('PATCHBRIEF_BUDGET_DB','data/runtime/budget.sqlite3'))
    with sqlite3.connect(path,timeout=10) as db:
        db.execute('BEGIN IMMEDIATE')
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='quality_evaluation_grant'").fetchone():
            raise BudgetBlocked('Complete the initial evaluation before any retest grant')
        db.execute('CREATE TABLE IF NOT EXISTS quality_retest_grant(id INTEGER PRIMARY KEY CHECK(id=1), reason TEXT NOT NULL, created TEXT DEFAULT CURRENT_TIMESTAMP)')
        if db.execute('SELECT 1 FROM quality_retest_grant').fetchone():
            raise BudgetBlocked('The single comparison allowance was already granted')
        db.execute('INSERT INTO quality_retest_grant(id,reason) VALUES(1,?)',(reason,))


def reserve(kind):
    require_cloud()
    path = Path(os.getenv("PATCHBRIEF_BUDGET_DB", "data/runtime/budget.sqlite3"))
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path, timeout=10) as db:
        db.execute("CREATE TABLE IF NOT EXISTS usage (kind TEXT PRIMARY KEY, attempts INTEGER NOT NULL)")
        db.execute("BEGIN IMMEDIATE")
        limits = _limits(db)
        row = db.execute("SELECT attempts FROM usage WHERE kind=?", (kind,)).fetchone()
        used = row[0] if row else 0
        if used >= limits[kind]:
            raise BudgetBlocked(f"Local {kind} allowance exhausted ({limits[kind]} attempts). Cloud work stopped.")
        db.execute("INSERT INTO usage VALUES (?, 1) ON CONFLICT(kind) DO UPDATE SET attempts=attempts+1", (kind,))
