"""Small, reviewable corpus: editor-written summaries of authoritative sources.

The snapshot is intentionally bounded. It is not a feed of current vulnerabilities.
Version facts are manually reviewed structured data, never model-generated.
"""
SNAPSHOT = "2026-10-17"
SOURCES = {
    "vite": "https://github.com/vitejs/vite/security/advisories/GHSA-vg6x-rcgg-rjx6",
    "next": "https://github.com/vercel/next.js/security/advisories/GHSA-f82v-jwr5-mffw",
    "axios": "https://github.com/axios/axios/security/advisories/GHSA-jr5f-v2jv-69x6",
}

CASES = {
    "vite": {
        "package": "vite", "cve": "CVE-2025-24010", "ghsa": "GHSA-vg6x-rcgg-rjx6",
        "title": "Development server cross-origin exposure", "severity": "moderate",
        "version": "5.4.11", "published": "2025-01-20",
        "ranges": [("0.0.0", "4.5.6"), ("5.0.0", "5.4.12"), ("6.0.0", "6.0.9")],
        "fixes": {"4": "4.5.6", "5": "5.4.12", "6": "6.0.9"},
        "question": "Which configuration changes should we check before upgrading behind a reverse proxy?",
        "context": "Development server behind a reverse proxy using a custom hostname. Confirmed installed version comes from a lockfile snapshot.",
        "tests": ["Check development-server access through the configured reverse proxy.", "Verify allowed origins and hostnames; test HMR after the upgrade.", "Confirm untrusted origins do not receive development-server content."],
        "gaps": ["Confirm the actual reverse-proxy hostname and trusted backend origins.", "Confirm whether a plugin opens its own WebSocket connection."],
    },
    "next": {
        "package": "next", "cve": "CVE-2025-29927", "ghsa": "GHSA-f82v-jwr5-mffw",
        "title": "Authorization bypass in Next.js middleware", "severity": "critical",
        "version": "14.2.24", "published": "2025-03-21",
        "ranges": [("11.1.4", "12.3.5"), ("13.0.0", "13.5.9"), ("14.0.0", "14.2.25"), ("15.0.0", "15.2.3")],
        "fixes": {"12": "12.3.5", "13": "13.5.9", "14": "14.2.25", "15": "15.2.3"},
        "question": "What evidence and regression checks belong in our middleware patch ticket?",
        "context": "Self-hosted application; authorization may occur in middleware. Deployment and route ownership need confirmation.",
        "tests": ["Verify protected routes still enforce authorization after the update.", "Check ingress handling of the advisory's middleware header in a controlled test environment.", "Confirm the deployed artifact contains the reviewed patched version."],
        "gaps": ["Confirm whether authorization depends on middleware.", "Verify the hosting environment rather than inferring it from package versions."],
    },
    "axios": {
        "package": "axios", "cve": "CVE-2025-27152", "ghsa": "GHSA-jr5f-v2jv-69x6",
        "title": "Absolute URL requests can expose credentials", "severity": "moderate",
        "version": "1.7.9", "published": "2025-03-07",
        "ranges": [("0.0.0", "0.29.1"), ("1.0.0", "1.7.10")],
        "fixes": {"0": "0.30.0", "1": "1.8.2"},
        "ambiguous": [("0.29.1", "0.30.0"), ("1.7.10", "1.8.2")],
        "question": "What URL-validation and credential-handling checks should accompany this upgrade?",
        "context": "Server-side axios client with baseURL and an API credential header. User input may contribute to request paths.",
        "tests": ["Verify user-provided URLs cannot redirect credential-bearing requests to an untrusted host.", "Check approved absolute-URL use cases after updating.", "Confirm deployed lockfile resolution and run HTTP-client regression tests."],
        "gaps": ["Confirm whether untrusted input reaches URL arguments.", "Inspect actual credential forwarding and URL validation in the application."],
    },
}

_PASSAGES = {
    "vite": [
        ("versions", "Affected versions and fixes", "The advisory lists affected Vite versions through 4.5.5, 5.0.0 through 5.4.11, and 6.0.0 through 6.0.8. Fixes start at 4.5.6, 5.4.12, and 6.0.9 in those release branches."),
        ("impact", "Local development is in scope", "Permissive CORS and missing WebSocket origin validation can let websites access the development server. The advisory explicitly includes a server running only on the local machine; development-only use is not proof of safety."),
        ("migration", "Reverse proxies and backend integration", "For backend integration without server.origin, add the trusted backend origin to server.cors.origin. Reverse proxies or custom domains may require the actual hostname in server.allowedHosts. Avoid wildcard trust."),
        ("websocket", "Plugin compatibility", "Plugins that establish their own browser WebSocket connection may need updates after the fix. The advisory describes an opt-out with security consequences; preserving the protection and updating the plugin should be investigated first."),
    ],
    "next": [
        ("versions", "Branch-specific patches", "Affected ranges are >=11.1.4 <12.3.5, >=13.0.0 <13.5.9, >=14.0.0 <14.2.25, and >=15.0.0 <15.2.3. The listed patches are 12.3.5, 13.5.9, 14.2.25, and 15.2.3. Next.js 11 users are directed to the workaround."),
        ("impact", "Middleware authorization", "Authorization checks can be bypassed when they occur in Next.js middleware. Whether an application uses middleware for authorization requires application-specific evidence."),
        ("hosting", "Hosting qualification", "The vendor advisory says deployments hosted on Vercel are automatically protected against this vulnerability. The package version alone does not establish where an application is hosted."),
        ("workaround", "Ingress workaround", "If patching is infeasible, the vendor recommends preventing external requests containing the x-middleware-subrequest header from reaching the application. This is a workaround for the named advisory, not a universal security guarantee."),
    ],
    "axios": [
        ("versions", "Version evidence", "The vendor advisory lists affected versions <=1.7.9 and <=0.29.0 and patched versions 1.8.2 and 0.30.0. Intermediate versions between the affected and patched boundaries are not conclusively classified by this snapshot."),
        ("impact", "Absolute URLs and baseURL", "An absolute URL can override baseURL in an axios request. With credential headers attached, this can expose credentials to another host and may enable server-side request forgery."),
        ("conditions", "Affected usage", "The advisory identifies software using baseURL without validating path parameters. Both server-side and client-side usage can be impacted; application call sites must be inspected to determine actual exposure."),
        ("validation", "Review URL handling", "The advisory discusses checking the destination after combining the base URL and supplied path. A remediation review should examine URL-validation behavior together with the documented package fix."),
    ],
}

DOCUMENTS = [
    {"id": f"{package}-{suffix}", "package": package, "cve": CASES[package]["cve"],
     "title": title, "text": content, "url": SOURCES[package],
     "published": CASES[package]["published"], "snapshot": SNAPSHOT,
     "kind": "Editorial summary of vendor advisory", "section": title}
    for package, passages in _PASSAGES.items() for suffix, title, content in passages
]

POLICIES = {
    "standard": {"name": "Standard response", "fictional": True, "text": "SAMPLE POLICY — fictional, for demonstration. Critical: review within 24 hours. High: review within 72 hours. Moderate: review within 7 days. Every patch needs an owner, regression tests, and reviewer approval. Review times start at alert intake; they are not promised resolution times."},
    "accelerated": {"name": "Accelerated response", "fictional": True, "text": "SAMPLE POLICY — fictional, for demonstration. Critical: review within 4 hours. High: review within 24 hours. Moderate: review within 48 hours. Every patch needs an owner, regression tests, and reviewer approval. Review times start at alert intake; they are not promised resolution times."},
}

def examples():
    return [{**{k: c[k] for k in ("package", "cve", "title", "severity", "version", "question", "context")},
             "id": key, "alert": {
                 "number": i, "state": "open", "dependency": {"package": {"ecosystem": "npm", "name": key}, "scope": "development" if key == "vite" else "runtime", "manifest_path": "package-lock.json"},
                 "security_advisory": {"cve_id": c["cve"], "ghsa_id": c["ghsa"], "summary": c["title"], "severity": c["severity"]},
                 "security_vulnerability": {"package": {"ecosystem": "npm", "name": key}, "first_patched_version": {"identifier": c["fixes"].get(c["version"].split('.')[0])}}
             }} for i, (key, c) in enumerate(CASES.items(), 1)]
