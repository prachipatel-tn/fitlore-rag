"""Authored, fictional walkthroughs. Demo wardrobes never replace personal data."""
CASES = [
 {
  'id':'townhall','title':'The townhall moment','subtitle':'Two pieces. A more intentional presence.',
  'audience':'Your next visible moment at work','duration':'5-minute walkthrough','palette':['Black linen','Warm brown','Optional brass'],
  'question':'How can I make my black linen skirt and brown wool T-shirt feel professional for a townhall?',
  'brief':'Illustrative townhall rehearsal. The only supplied wardrobe facts are a black linen skirt and a brown wool T-shirt. The goal is to explore a professional presentation while retaining these pieces. Attendance versus speaking, workplace dress expectations, skirt length, garment fit, venue temperature, shoes, accessories and spending preferences are not supplied.',
  'garments':[
   {'name':'Black linen skirt','category':'Bottom','color':'Black','material':'Linen','shape':'skirt','notes':'Length, cut, lining and fit are unknown.'},
   {'name':'Brown wool T-shirt','category':'Top','color':'Brown','material':'Wool','shape':'tee','notes':'Shade, weight, sleeve length and fit need confirmation.'}
  ],
  'directions':[
   {'title':'Quiet conviction','description':'Let the black-and-brown combination stay simple. Try a clean tuck if the wool and skirt waistband allow it. Steam the linen according to its care label and check the tee for pilling.','detail':'The intervention is finish and proportion. It does not require a new colour palette.','optional':['A polished black loafer or flat, if you own one','One small piece of jewellery, if you enjoy wearing it'],'tradeoff':'A tucked wool tee may feel bulky. Compare a neat untucked hem before deciding.'},
   {'title':'A little more structure','description':'Keep the same skirt and tee. If the room calls for more formality, try an open black or charcoal jacket you already own. Compare its hem with the skirt in a full-length mirror.','detail':'A structured outer layer is an option to test; it is not a workplace requirement.','optional':['An existing jacket or clean-lined cardigan','An existing structured bag, only if useful'],'tradeoff':'Wool plus a jacket may be too warm. Try the complete look before committing.'}
  ],
  'questions':['Are you attending or presenting?','What does this workplace expect people to wear?','What is the skirt’s length and cut, and does the tee tuck comfortably?','Which shoes do you own and feel comfortable standing in?'],
  'checks':['Try both a clean tuck and a neat untucked hem. Choose the one that feels comfortable.','Sit, walk and climb a step to check movement, coverage and the skirt waistband.','If presenting, rehearse reaching, holding a microphone and wearing any mic clip.','Take a photo in the intended lighting. Check whether you like the silhouette; no appearance score is assigned.'],
  'followup':'Did the wool feel too warm? Did the waistband sit comfortably? Would you repeat the combination?',
  'queries':['black linen skirt brown wool T-shirt townhall','sitting walking fit comfort','stock price personality unknown']
 },
 {
  'id':'creator','title':'The creator launch','subtitle':'One point of view, across the whole shoot.',
  'audience':'A fictional independent creator','duration':'4-minute walkthrough','palette':['Ivory','Dark denim','Optional red'],
  'question':'Build a coherent look for a launch shoot using my ivory shirt and dark jeans.',
  'brief':'Fictional creator launch. Supplied sample pieces: ivory shirt and dark jeans. The goal is visual continuity across portraits and behind-the-scenes images. No sponsor contract, brand restrictions, approved product claims, footwear or publishing permissions have been supplied.',
  'garments':[{'name':'Ivory shirt','category':'Top','color':'Ivory','material':'Not specified','shape':'shirt','notes':'Fictional sample piece.'},{'name':'Dark straight jeans','category':'Bottom','color':'Dark denim','material':'Denim','shape':'trousers','notes':'Fictional sample piece; fit needs checking.'}],
  'directions':[
   {'title':'The recognisable thread','description':'Use the shirt and jeans as a consistent base. Try one existing accent accessory across the portrait and behind-the-scenes frames.','detail':'Continuity comes from repeated choices rather than a different outfit for every frame.','optional':['An accent accessory you already own','Comfortable footwear suitable for the shoot location'],'tradeoff':'A repeated accent can feel too styled; compare a simpler frame.'},
   {'title':'From portrait to process','description':'Keep the same base, then compare a neat shirt hem for portraits with rolled sleeves for working shots, if that feels natural.','detail':'These are creative shot suggestions, not approved sponsor deliverables.','optional':['An existing layer for outdoor frames'],'tradeoff':'Sleeve changes and layers require continuity notes if frames will be edited together.'}
  ],
  'questions':['What is the launch about?','Are there sponsor requirements or prohibited brands?','Where will the shoot happen?','Which deliverables and claims are actually approved?'],
  'checks':['Try the outfit under the actual lighting.','Check movement and any required microphone placement.','Keep a short continuity note for sleeves, accessories and layers.','Review captions and brand claims separately before publishing.'],
  'followup':'Which combination felt like you, and which frames were actually useful?',
  'queries':['ivory shirt dark jeans launch','wardrobe anchor source guidance','brand restrictions unknown']
 },
 {
  'id':'conference','title':'The first conference talk','subtitle':'Prepare the look. Leave room for your ideas.',
  'audience':'A fictional first-time speaker','duration':'4-minute walkthrough','palette':['Navy','Cream','Black'],
  'question':'Help me prepare a comfortable conference speaking look from my navy jacket, cream knit, trousers and flats.',
  'brief':'Fictional conference speaking rehearsal. Available sample pieces: navy jacket, cream knit, black trousers and black flats. The goal is comfort through travel and a standing presentation. Actual shoe comfort, venue temperature, dress expectations and mic setup are not verified.',
  'garments':[{'name':'Navy jacket','category':'Layer','color':'Navy','material':'Not specified','shape':'jacket','notes':'Fictional sample.'},{'name':'Cream knit','category':'Top','color':'Cream','material':'Knit','shape':'tee','notes':'Fictional sample.'},{'name':'Black trousers','category':'Bottom','color':'Black','material':'Not specified','shape':'trousers','notes':'Fictional sample.'},{'name':'Black flats','category':'Shoes','color':'Black','material':'Not specified','shape':'shoes','notes':'Comfort is not verified.'}],
  'directions':[
   {'title':'Ready for the room','description':'Try the navy jacket over the cream knit with black trousers and flats. Test the layers together while standing and speaking.','detail':'Every named piece is supplied in this fictional case. No purchase is assumed.','optional':[],'tradeoff':'The jacket adds structure but could feel warm under lights.'},
   {'title':'The lighter rehearsal','description':'Compare the cream knit and trousers without the jacket. Keep the jacket available if the venue feels cold.','detail':'The simpler option helps you compare comfort rather than assume more layers are always better.','optional':[],'tradeoff':'Check that this level of formality works for your event.'}
  ],
  'questions':['What are the event dress expectations?','Will you wear a lapel mic or a headset?','How long will you stand and travel?','Have these flats been comfortable during a similar day?'],
  'checks':['Rehearse your opening in the complete outfit.','Test reaching, sitting and holding a clicker.','Check microphone placement with the event team.','Prepare a practical backup for temperature changes.'],
  'followup':'Which layer did you actually wear, and what helped you concentrate on the talk?',
  'queries':['navy jacket cream knit conference','standing comfort rehearsal fit','microphone temperature unknown']
 }
]

def find_case(id):
 return next((c for c in CASES if c['id']==id),None)
