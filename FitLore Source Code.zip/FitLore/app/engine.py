import re
import time
from datetime import datetime, timezone

from app.corpus import CASES, SNAPSHOT
from app.integrations import generate_recommendations
from app.retrieval import retrieve


def version_tuple(value):
    # Deliberately reject ranges, prereleases, aliases, git refs and inferred versions.
    if not isinstance(value, str) or not re.fullmatch(r"\d+\.\d+\.\d+", value):
        return None
    return tuple(map(int, value.split(".")))


def assess_version(case, version, has_evidence=True):
    v = version_tuple(version)
    if not v or not has_evidence:
        return "unknown", None
    if any(version_tuple(lo) <= v < version_tuple(hi) for lo, hi in case.get("ambiguous", [])):
        return "unknown", None
    for lo, hi in case["ranges"]:
        if version_tuple(lo) <= v < version_tuple(hi):
            return "in_affected_range", case["fixes"].get(str(v[0]))
    # Only classify versions in release families documented by the snapshot.
    known_majors = {str(version_tuple(bound)[0]) for pair in case["ranges"] for bound in pair} | set(case["fixes"])
    if str(v[0]) not in known_majors:
        return "unknown", None
    return "outside_documented_range", None


def normalize_alert(alert):
    advisory = alert.get("security_advisory", {})
    dep = alert.get("dependency", {}).get("package", {})
    if not isinstance(advisory, dict) or not isinstance(dep, dict):
        raise ValueError("Invalid Dependabot advisory or package object")
    package = dep.get("name", "")
    ecosystem = dep.get("ecosystem", "")
    cve, ghsa = advisory.get("cve_id", ""), advisory.get("ghsa_id", "")
    if not all(isinstance(x, str) for x in (package, ecosystem)) or not package:
        raise ValueError("Expected dependency.package.name and ecosystem")
    if ecosystem != "npm":
        raise ValueError("This release supports npm alerts only")
    if not (isinstance(cve, str) and cve or isinstance(ghsa, str) and ghsa):
        raise ValueError("Expected a CVE or GHSA identifier in security_advisory")
    case = CASES.get(package)
    matched = case and (cve == case["cve"] or ghsa == case["ghsa"])
    if matched and cve and cve != case["cve"]:
        matched = False
    if matched and ghsa and ghsa != case["ghsa"]:
        matched = False
    return package, cve or ghsa, case if matched else None


def policy_rule(text, severity):
    # Accept only an explicit clause; free-form text is shown without inferring an SLA.
    pattern = rf"\b{re.escape(severity)}\s*:\s*review within\s+(\d+)\s+(hours?|days?)\b"
    matches = list(re.finditer(pattern, text, re.IGNORECASE))
    if len(matches) != 1:
        return None
    return matches[0].group(0)


def analyze(req):
    start = time.perf_counter()
    package, identifier, case = normalize_alert(req.alert)
    query = f"{req.question} {req.context} {req.installed_version} affected patched migration"
    docs, strategy = retrieve(query, package, case["cve"] if case else identifier,
                              live=req.mode == "live", excluded=req.exclude_sources)
    evidence_ids = {d["id"] for d in docs}
    status, patch = assess_version(case, req.installed_version, f"{package}-versions" in evidence_ids) if case else ("unknown", None)
    severity = case["severity"] if case else "unknown"
    clause = policy_rule(req.policy_text, severity)
    gaps = ["Confirm the installed version against the deployed artifact; the supplied value is user-provided.",
            "Review newer advisories before selecting a current release. This corpus is a bounded historical snapshot."]
    if case:
        gaps += case["gaps"]
    else:
        gaps.append("This advisory/package pair is outside the curated corpus. No remediation conclusion is available.")
    if status == "unknown":
        gaps.append("Version applicability is unresolved. Supply a stable exact version and the matching version evidence.")
    if status == "in_affected_range" and not patch:
        gaps.append("No same-major patch is documented here; review vendor workaround and supported upgrade branches.")
    if not clause:
        gaps.append("No single supported review-time clause found. Assign priority and timing with the team.")
    docs_by_id = {d["id"]: d for d in docs}
    migration_ids = {"vite": ["vite-migration", "vite-websocket"], "next": ["next-hosting", "next-workaround"], "axios": ["axios-conditions", "axios-validation"]}.get(package, [])
    recs = [{"text": docs_by_id[i]["text"], "source_ids": [i], "kind": "Curated source summary"} for i in migration_ids if i in docs_by_id]
    if req.mode == "live" and docs:
        recs = generate_recommendations({"question": req.question, "context": req.context,
            "locked_facts": {"version_status": status, "documented_patch": patch, "severity": severity},
            "evidence": docs})
    if req.policy_text:
        docs.append({"id": "team-policy", "title": req.policy_name, "text": req.policy_text,
                     "url": None, "kind": "User-supplied policy · not independently verified",
                     "snapshot": SNAPSHOT, "section": "Explicit review-time clauses"})
    result = {"package": package, "identifier": case["cve"] if case else identifier,
        "title": case["title"] if case else "Advisory outside the current corpus",
        "installed_version": req.installed_version or "Not supplied", "severity": severity,
        "version_status": status, "documented_patch": patch,
        "version_source_ids": [f"{package}-versions"] if f"{package}-versions" in evidence_ids else [],
        "exposure_status": "under_investigation", "mode": req.mode,
        "generated_at": datetime.now(timezone.utc).isoformat(), "snapshot": SNAPSHOT,
        "retrieval": strategy, "question": req.question, "context": req.context,
        "policy_clause": clause, "policy_name": req.policy_name,
        "recommendations": recs, "suggested_tests": case["tests"] if case and docs else [],
        "gaps": gaps, "evidence": docs, "elapsed_ms": round((time.perf_counter() - start) * 1000),
        "disclaimer": "Draft for human review. Version matching does not establish application exploitability. Documented patches address this named advisory, not all known vulnerabilities.",
        "citation_check": "Source IDs validated; semantic support requires review." if req.mode == "live" else "Curated summaries tied to retrieved evidence; no model called."}
    result["markdown"] = to_markdown(result)
    return result


def to_markdown(r):
    lines = [f"# PatchBrief: {r['package']} — {r['identifier']}", "", r["title"], "",
        f"- Mode: {r['mode']}", f"- Corpus snapshot: {r['snapshot']}",
        f"- Installed version (user supplied): {r['installed_version']}",
        f"- Version status: {r['version_status']}", f"- Application exposure: {r['exposure_status']}",
        f"- Retrieval: {r['retrieval']}", "", "## Proposed review", ""]
    if r["documented_patch"]:
        lines += [f"The vendor documents {r['documented_patch']} as a fix in this release branch for the named advisory. [{r['package']}-versions]", "Check current release support and newer advisories before choosing a deployment target.", ""]
    else:
        lines += ["No upgrade target inferred from the available evidence.", ""]
    lines += [f"Policy: {r['policy_clause']} [team-policy]" if r["policy_clause"] else "Policy timing: requires review.", "", "## Evidence-backed considerations", ""]
    for item in r["recommendations"]:
        lines.append(f"- {item['text']} " + " ".join(f"[{i}]" for i in item["source_ids"]))
    lines += ["", "## Suggested verification (engineering suggestions, not vendor mandates)", ""]
    lines += [f"- [ ] {t}" for t in r["suggested_tests"]]
    lines += ["", "## Unresolved evidence", ""] + [f"- [ ] {g}" for g in r["gaps"]]
    lines += ["", "## Review ownership", "", "- Owner: unassigned", "- Reviewer: unassigned", "- Decision: pending", "", "## Sources", ""]
    for d in r["evidence"]:
        lines.append(f"- [{d['id']}] {d['title']} — {d.get('url') or 'Supplied policy'} ({d['kind']})")
    lines += ["", r["disclaimer"], "", r["citation_check"]]
    return "\n".join(lines)
