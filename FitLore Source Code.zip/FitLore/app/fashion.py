"""Local fashion prototype. No network calls or model-generated claims."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Literal
router = APIRouter(prefix='/api/fashion')
SOURCES = [
 {'id':'vogue-fall','title':'Vogue · 6 Key Fall 2026 Fashion Trends','date':'2026-09-28','url':'https://www.vogue.com/article/fall-winter-2026-fashion-trends','summary':'Editorial coverage highlights expressive styling, contrasting textures and reinterpreted wardrobe staples. This is seasonal editorial coverage, not a real-time popularity ranking.'},
 {'id':'pinterest-2026','title':'Pinterest Predicts · 2026','date':'2025-12','url':'https://business.pinterest.com/en-gb/pdf/pinterest-predicts/2026-trend-report/','summary':'An annual forecast includes lace as a cross-category theme. A forecast is not confirmation that a style is currently popular.'}]
PHOTO_ROWS = [('The white-blazer edit',
  'Minimal',
  '1571513722275-4b41940f54b8',
  'IXYxqP4zejo',
  'Aiony Haust',
  'White blazer against a neutral studio background',
  ['White blazer', 'Red floral accent', 'Soft neutral palette'],
  'Let one clean silhouette do the work. Keep the surrounding colours quiet.',
  'Understated authority'),
 ('City after hours',
  'Street',
  '1577974213190-c07a5dd4467c',
  'KX79hBvKI20',
  'pawel szvmanski',
  'A woman styling a blazer on a city street',
  ['Dark blazer', 'Strappy white top', 'Dark trousers'],
  'Borrow the contrast between a structured outer layer and an easy attitude.',
  'Expressive original'),
 ('A softer entrance',
  'Expressive',
  '1684220530051-09725d205b4b',
  '9Y7dd2_5C7g',
  'Vladimir Yelizarov',
  'A woman in a white dress with a pink bag outdoors',
  ['White dress', 'Pink bag', 'Light colour palette'],
  'A single colourful accessory gives a simple base a point of view.',
  'Approachable expert'),
 ('Sharp, on your terms',
  'Tailored',
  '1653743074931-5edd30a1a2c3',
  '14kF8RRCGwM',
  'DAVOD',
  'A person wearing a suit and tie on a city street',
  ['Suit jacket', 'Tie', 'Tailored layers'],
  'Use the suit as a starting point. Adjust formality to the actual occasion.',
  'Understated authority'),
 ('The downtown edit',
  'Tailored',
  '1566758456102-02bea9470947',
  'fDO5TYBEIVQ',
  'Jusdevoyage',
  'A woman wearing a dark blazer and sunglasses in Montreal',
  ['Dark blazer', 'Sunglasses', 'Structured silhouette'],
  'A dark outer layer creates a simple anchor for the rest of your look.',
  'Understated authority'),
 ('Room to lead',
  'Minimal',
  '1613186145425-5bb4eca455d7',
  'oQJrKxqU0Vc',
  'Natasha Hall',
  'A woman in a light blazer by a meeting-room window',
  ['Light blazer', 'Understated layers', 'Soft contrast'],
  'Try lighter tailoring when you want structure without an all-dark palette.',
  'Approachable expert')]
LOOKS=[{'id':str(i+1),'name':r[0],'aesthetic':r[1],'image':f'/static/images/{r[2]}.jpg','photo_url':f'https://unsplash.com/photos/{r[3]}','photographer':r[4],'alt':r[5],'pieces':r[6],'styling_note':r[7],'direction':r[8],'source_ids':[],'note':'Photographic inspiration. Styling notes are FitLore suggestions; no endorsement or product availability is implied.'} for i,r in enumerate(PHOTO_ROWS)]
class StyleRequest(BaseModel):
 look_id: str
 occasion: Literal['Everyday','Campus','Work','Evening']='Everyday'
 footwear: Literal['Flats','Sneakers','Heels']='Flats'
 coverage: Literal['Any','More coverage']='Any'
 intensity: Literal['Subtle','Balanced','Statement']='Balanced'
@router.get('/catalog')
def catalog():
 return {'looks':LOOKS,'sources':SOURCES,'mode':'local','cloud_enabled':False,'updated':'2026-10-17'}
@router.post('/style')
def style(req:StyleRequest):
 look=next((x for x in LOOKS if x['id']==req.look_id),None)
 if not look: raise HTTPException(404,'Look not found')
 top={'Everyday':'Relaxed knit','Campus':'Cotton overshirt','Work':'Structured blazer','Evening':'Draped blouse'}[req.occasion]
 if req.coverage=='More coverage': top='Long-sleeve '+top.lower()
 return {'look':look,'pieces':[top,'Wide-leg trousers' if req.intensity=='Statement' else 'Straight-leg trousers',{'Flats':'Loafers','Sneakers':'Low-top sneakers','Heels':'Block heels'}[req.footwear], 'Statement shoulder bag' if req.intensity=='Statement' else 'Simple shoulder bag'], 'explanation':f"Keep the {look['aesthetic'].lower()} direction and its colour palette. {top} sets the tone for {req.occasion.lower()}, while your selected footwear keeps the look aligned with your preference.",'source_ids':look['source_ids'],'mode':'Local styling rules · no AI call','coverage':req.coverage,'intensity':req.intensity}

class ConsultRequest(BaseModel):
 name: str = ''
 role: str = 'Founder'
 moment: Literal['Investor event','Speaking engagement','New leadership role','Creator launch']='Investor event'
 qualities: Literal['Credible and approachable','Creative and expressive','Calm and authoritative']='Credible and approachable'
 formality: Literal['Relaxed','Balanced','Formal']='Balanced'
 budget: Literal['Use what I own','One considered addition']='Use what I own'
 direction: Literal['approachable','understated','expressive']='approachable'

@router.post('/consult')
def consult(req: ConsultRequest):
 titles={'approachable':'Approachable expert','understated':'Understated authority','expressive':'Expressive original'}
 garments={'Relaxed':['Soft overshirt','Straight-leg trousers','Clean low-top sneakers'], 'Balanced':['Unstructured blazer','Straight-leg trousers','Comfortable loafers'], 'Formal':['Structured jacket','Coordinating trousers','Polished flats or dress shoes']}[req.formality]
 accent={'approachable':'A soft blue or warm neutral accent','understated':'A restrained tonal palette','expressive':'One vivid accent you already enjoy wearing'}[req.direction]
 name=req.name.strip() or '[Your name]'
 role=req.role.strip() or '[Your role]'
 return {'title':titles[req.direction], 'brief':f"For your {req.moment.lower()}, aim to express {req.qualities.lower()} qualities in a way you feel comfortable sustaining.", 'outfit':garments+[accent], 'introduction':f"Hi, I’m {name}. I’m a {role.lower()} working on [your actual focus]. I’m here to [your goal for this occasion]. I’d love to hear about [a genuine shared interest].", 'photo':['Choose an uncluttered location related to your work or interests.','Use a comfortable pose and an expression that feels natural to you.','Capture one head-and-shoulders image and one wider environmental portrait.','Check the final image represents how you want to appear; avoid misleading edits.'], 'checklist':['Confirm the event dress expectations and audience.','Try the complete outfit while sitting, standing and walking.','Replace the bracketed introduction fields with accurate details.','Practise your introduction aloud and shorten anything that feels unnatural.','Prepare one real example of your work and two questions for others.'], 'budget_note':'Start with your existing pieces; no purchase is required.' if req.budget=='Use what I own' else 'First assemble the look from your wardrobe. Consider at most one missing piece after checking fit and your own spending limit.', 'tradeoff':{'approachable':'A softer presentation may feel less ceremonial in highly formal settings. Check the event expectations.','understated':'A restrained direction may feel less expressive; add a personal detail if that matters to you.','expressive':'A stronger visual accent can feel unfamiliar. Keep it only if it feels comfortable and appropriate to the occasion.'}[req.direction], 'provenance':{'user_facts':['name','role','moment','qualities','formality','budget'],'creative_suggestions':['direction','outfit','photo brief','checklist'],'status':'Local consultation templates. Not professional assessment, AI inference, or retrieved advice.'}}
