"""Personal RAG workspace. Local, single-user; no external traffic in rehearsal mode."""
import base64
import io
import json
import os
import re
import time
import uuid
from typing import Literal
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field, field_validator
from app import studio_rag as rag
from app.studio import db, put, objects, now
from app.budget import reserve, current_limits
from app.demo_cases import CASES, find_case
from app import personal_vectors as hosted

router = APIRouter(prefix='/api/fitlore')

GUIDES = [
 ('guide-method', 'Start with your real life', 'Separate what you wear regularly, what you aspire to try, and how you want to feel. These are preferences to discuss, not a diagnosis. Start with owned pieces and explain what each proposed change achieves.', 'https://goop.com/style/outfitting-ideas/allison-bornstein-interview/'),
 ('guide-process', 'Build before you buy', 'Begin with the occasion, lifestyle, preferences and wardrobe. Select anchor pieces, build initial combinations, then identify specific gaps. Offer practical shoe alternatives and explain how to adapt each look.', 'https://thestylelab.substack.com/p/behind-the-scenes-a-client-lookbook'),
 ('guide-rehearsal', 'Try the complete look', 'Before the occasion, check the complete outfit for sitting, walking and movement. Fit and tailoring need physical confirmation. A photograph or generated preview cannot guarantee comfort or fit.', 'https://www.vogue.co.uk/article/secrets-of-a-celebrity-stylist-kate-young'),
 ('guide-integrity', 'Evidence and shopping policy', 'Do not infer personality, competence, body measurements or colour season from appearance. Prices, delivery dates and stock require current verification. Unknown facts must stay unknown. Product links are references, not purchase recommendations or availability guarantees. A creative suggestion is not a fact.', ''),
]

class Profile(BaseModel):
 name: str = Field(min_length=1, max_length=100)
 event: str = Field(min_length=3, max_length=200)
 goals: str = Field(min_length=3, max_length=1000)
 preferences: str = Field(default='', max_length=1500)
 avoid: str = Field(default='', max_length=1000)
 budget_cents: int = Field(default=10000, ge=0, le=10000000)
 footwear: Literal['Any', 'Flats', 'Sneakers', 'Heels'] = 'Flats'
 coverage: Literal['Any', 'Sleeves'] = 'Sleeves'

class Garment(BaseModel):
 name: str = Field(min_length=2, max_length=100)
 category: Literal['Top', 'Bottom', 'Dress', 'Layer', 'Shoes', 'Accessory']
 color: str = Field(default='', max_length=50)
 notes: str = Field(default='', max_length=1000)
 footwear: Literal['Any', 'Flats', 'Sneakers', 'Heels'] = 'Any'
 sleeves: bool = False
 available: bool = True
 image: str = Field(default='', max_length=85000)
 @field_validator('image')
 @classmethod
 def valid_image(cls, v):
  if not v: return v
  if not v.startswith('data:image/jpeg;base64,'): raise ValueError('Use a JPEG photo')
  try: raw = base64.b64decode(v.split(',', 1)[1], validate=True)
  except Exception: raise ValueError('Invalid image')
  if not raw.startswith(b'\xff\xd8\xff'): raise ValueError('Invalid JPEG')
  return v

class Document(BaseModel):
 title: str = Field(min_length=2, max_length=200)
 text: str = Field(min_length=5, max_length=30000)
 url: str = Field(default='', max_length=2000)
 @field_validator('url')
 @classmethod
 def valid_url(cls, v):
  from urllib.parse import urlparse
  p=urlparse(v)
  if v and (p.scheme!='https' or not p.hostname or p.username): raise ValueError('Use an HTTPS source link')
  return v

class Upload(BaseModel):
 filename: str = Field(min_length=1, max_length=200)
 content: str = Field(max_length=115000)

class Consultation(BaseModel):
 question: str = Field(min_length=3, max_length=2000)
 mode: Literal['demo', 'live'] = 'demo'

class Feedback(BaseModel):
 outcome: Literal['Wore it', 'Would try', 'Needs changes', 'Not for me']
 text: str = Field(default='', max_length=2000)

def unsupported_photo_assessment(question):
 text=question.lower()
 return bool(re.search(r'personality|body measurements|colou?r season|undertone',text) and re.search(r'photo|picture|image|appearance',text))

def seed(c):
 if not c.execute("SELECT 1 FROM objects WHERE id='personal-profile'").fetchone():
  p=Profile(name='Alex · sample client',event='First client presentation',goals='Feel prepared, approachable and still like myself',preferences='Reuse my wardrobe. A neutral base with one blue accent.',avoid='Uncomfortable shoes and unnecessary purchases')
  put(c,'personal-profile',{'id':'personal-profile',**p.model_dump(),'revision':1,'updated':now(),'sample':True})
  rows=[('Navy cotton blazer','Layer','Navy',True,'Any'),('Ivory long-sleeve shirt','Top','Ivory',True,'Any'),('Charcoal straight trousers','Bottom','Charcoal',False,'Any'),('Black leather loafers','Shoes','Black',False,'Flats'),('Blue silk scarf','Accessory','Blue',False,'Any'),('White low-top sneakers','Shoes','White',False,'Sneakers')]
  for i,(name,cat,col,sleeves,footwear) in enumerate(rows):
   put(c,'garment',{'id':f'garment-{i}',**Garment(name=name,category=cat,color=col,sleeves=sleeves,footwear=footwear,notes='Fictional demo wardrobe item; replace with your own.').model_dump(),'revision':1,'sample':True,'updated':now()})
 for id,title,text,url in GUIDES:
  if not c.execute('SELECT 1 FROM objects WHERE id=?',(id,)).fetchone():
   put(c,'personal-document',{'id':id,'title':title,'text':text,'url':url,'revision':1,'updated':'2026-10-17','kind':'FitLore editorial summary' if url else 'Application policy','editable':False})

def record(c, id, kind):
 row=c.execute('SELECT payload FROM objects WHERE id=? AND kind=?',(id,kind)).fetchone()
 if not row: raise HTTPException(404,'Record not found')
 return json.loads(row['payload'])

def corpus(c):
 seed(c)
 p=record(c,'personal-profile','personal-profile')
 docs=[{'id':'personal-profile','title':'Current personal brief','revision':p['revision'],'text':f"Name: {p['name']}. Occasion: {p['event']}. Goals: {p['goals']}. Preferences: {p['preferences']}. Avoid: {p['avoid']}. Budget ceiling: USD {p['budget_cents']/100:.2f}. Footwear: {p['footwear']}. Coverage: {p['coverage']}. {'Fictional sample.' if p.get('sample') else 'User supplied.'}", 'url':'','kind':'Personal brief','updated':p['updated']}]
 for g in objects(c,'garment'):
  docs.append({'id':g['id'],'title':g['name'],'revision':g['revision'],'text':f"Wardrobe item: {g['name']}. Category: {g['category']}. Colour: {g['color']}. Sleeves: {g['sleeves']}. Footwear type: {g['footwear']}. Available: {g['available']}. Notes: {g['notes']}",'url':'','kind':'Wardrobe','updated':g['updated']})
 docs.extend(objects(c,'personal-document'))
 for f in objects(c,'personal-feedback'):
  if f.get('demo_case_id'):continue
  docs.append({'id':f['id'],'title':'Client feedback','revision':1,'text':f"Outcome: {f['outcome']}. Client said: {f['text']}",'url':'','kind':'Feedback','updated':f['created']})
 nodes=rag.chunks(docs)
 lookup={d['id']:d for d in docs}
 for n in nodes:
  d=lookup[n['document_id']];n.update(url=d.get('url',''),kind=d['kind'],updated=d['updated'])
 return nodes

def check_capacity(c):
 try:corpus(c)
 except ValueError as exc:raise HTTPException(409,str(exc)) from exc

def tables(c):
 c.execute('CREATE TABLE IF NOT EXISTS personal_index(id INTEGER PRIMARY KEY CHECK(id=1), signature TEXT, model TEXT, created TEXT)')
 c.execute('CREATE TABLE IF NOT EXISTS personal_vectors(id TEXT PRIMARY KEY, payload TEXT, vector TEXT)')
 c.execute('CREATE TABLE IF NOT EXISTS personal_hosted_index(id INTEGER PRIMARY KEY CHECK(id=1), signature TEXT, model TEXT, index_name TEXT, namespace TEXT)')

def pipeline_status(c, nodes):
 tables(c);s=c.execute('SELECT * FROM personal_index WHERE id=1').fetchone()
 remote=c.execute('SELECT * FROM personal_hosted_index WHERE id=1').fetchone() if hosted.enabled() else None
 active=remote if hosted.enabled() else s
 stale=bool(active and (active['signature']!=rag.signature(nodes) or active['model']!=os.getenv('NEBIUS_EMBEDDING_MODEL') or (hosted.enabled() and (active['index_name']!=os.getenv('PINECONE_INDEX') or active['namespace']!=hosted.namespace(rag.signature(nodes),os.getenv('NEBIUS_EMBEDDING_MODEL',''))))))
 return {'cloud_enabled':os.getenv('PATCHBRIEF_ALLOW_CLOUD','false').lower()=='true' and os.getenv('FITLORE_RAG_ALLOW_CLOUD','false').lower()=='true','indexed':bool(active),'stale':stale,'chunks':len(nodes),'embedding_model':os.getenv('NEBIUS_EMBEDDING_MODEL','Not configured'),'generation_model':os.getenv('NEBIUS_MODEL','Not configured'),'indexed_at':s['created'] if s else None,'store':'Pinecone · local document and embedding cache' if hosted.enabled() else 'Local SQLite vectors','vector_index':os.getenv('PINECONE_INDEX') if hosted.enabled() else None,'namespace':remote['namespace'] if remote else None,'tracing':'Not used','limits':current_limits()}

def sync_hosted(nodes, vectors, sig, model):
 if not hosted.enabled():return
 ns=hosted.namespace(sig,model)
 with db() as c:
  tables(c);prior=c.execute('SELECT * FROM personal_hosted_index WHERE id=1').fetchone()
  if prior and (prior['signature'],prior['model'],prior['index_name'],prior['namespace'])==(sig,model,os.environ['PINECONE_INDEX'],ns):return
 ns=hosted.upload(nodes,vectors,sig,model)
 with db() as c:
  c.execute('BEGIN IMMEDIATE')
  if rag.signature(corpus(c))!=sig:raise ValueError('Sources changed during hosted upload. Re-index before consultation.')
  tables(c);c.execute('INSERT OR REPLACE INTO personal_hosted_index VALUES(1,?,?,?,?)',(sig,model,os.environ['PINECONE_INDEX'],ns))

STOP={'the','a','an','what','is','are','for','of','and','to','in','my','our','i','me','can','do','how','with','should'}
def terms(text):
 aliases={'prefer':'preference','preferences':'preference','goals':'goal','pieces':'item','items':'item'}
 return {aliases.get(t,t) for t in re.findall(r'\w+',text.lower()) if t not in STOP}
def lexical(question,nodes,k=5):
 query_terms=terms(question)
 scored=[{**n,'score':len(query_terms & terms(n['text']+' '+n['title']))} for n in nodes]
 return sorted([n for n in scored if n['score']],key=lambda n:(-n['score'],n['id']))[:k]

def proposals(p, garments):
 available=[g for g in garments if g['available']]
 groups={cat:[g for g in available if g['category']==cat] for cat in ['Top','Bottom','Dress','Layer','Shoes','Accessory']}
 shoes=[g for g in groups['Shoes'] if p['footwear']=='Any' or g['footwear']==p['footwear']]
 options=[]
 for base in [[t,b] for t in groups['Top'] for b in groups['Bottom']]+[[d] for d in groups['Dress']]:
  layers=groups['Layer']
  if p['coverage']=='Sleeves' and not any(g['sleeves'] for g in base):
   layers=[g for g in layers if g['sleeves']]
   if not layers: continue
  for shoe in shoes[:2]:
   pieces=base+layers[:1]+[shoe]+groups['Accessory'][:1]
   options.append({'title':'Your wardrobe, considered' if not options else 'Another way to wear it','item_ids':[g['id'] for g in pieces],'pieces':[g['name'] for g in pieces],'additional_cost_cents':0,'rationale':'A local combination of available wardrobe items. Footwear and sleeve settings are checked; style, fit and free-text preferences need your review.'})
   if len(options)==3:return options
 return options

@router.get('/state')
def state():
 with db() as c:
  nodes=corpus(c);p=record(c,'personal-profile','personal-profile');sig=rag.signature(nodes)
  sessions=objects(c,'consultation')[::-1]
  for s in sessions:
   s['stale']=s['corpus_signature']!=sig if not s.get('demo_case_id') else s['corpus_signature']!=rag.signature(demo_nodes(s['demo_case_id']))
  return {'profile':p,'garments':objects(c,'garment'),'documents':objects(c,'personal-document'),'consultations':sessions,'feedback':objects(c,'personal-feedback'),'pipeline':pipeline_status(c,nodes),'notice':'Local single-user project. Demo role selectors are not authentication. Use fictional data for shared demonstrations.'}

@router.put('/profile')
def profile(req:Profile):
 with db() as c:
  seed(c);old=record(c,'personal-profile','personal-profile')
  p={'id':'personal-profile',**req.model_dump(),'revision':old['revision']+1,'updated':now(),'sample':False};put(c,'personal-profile',p);check_capacity(c);return p

@router.post('/wardrobe')
def add_garment(req:Garment):
 with db() as c:
  seed(c)
  if len(objects(c,'garment'))>=60:raise HTTPException(409,'Local project limit: 60 wardrobe items')
  g={'id':uuid.uuid4().hex,**req.model_dump(),'revision':1,'updated':now(),'sample':False};put(c,'garment',g);check_capacity(c);return g

@router.put('/wardrobe/{id}')
def update_garment(id:str,req:Garment):
 with db() as c:
  old=record(c,id,'garment');g={'id':id,**req.model_dump(),'revision':old['revision']+1,'updated':now(),'sample':False};put(c,'garment',g);check_capacity(c);return g

@router.delete('/wardrobe/{id}')
def delete_garment(id:str):
 with db() as c:
  record(c,id,'garment');c.execute('DELETE FROM objects WHERE id=?',(id,));return {'deleted':id}

def save_document(req):
 with db() as c:
  seed(c)
  if len(objects(c,'personal-document'))>=30:raise HTTPException(409,'Local project limit: 30 documents')
  d={'id':uuid.uuid4().hex,**req.model_dump(),'revision':1,'updated':now(),'kind':'User supplied source','editable':True};put(c,'personal-document',d)
  corpus(c)  # Validate chunk limit before committing.
  return d

@router.post('/documents')
def document(req:Document):
 try:return save_document(req)
 except ValueError as e:raise HTTPException(422,str(e))

@router.post('/documents/upload')
def upload(req:Upload):
 try:
  raw=base64.b64decode(req.content,validate=True)
  if len(raw)>85000:raise ValueError('File limit is 85 KB')
  if req.filename.lower().endswith('.pdf'):
   from pypdf import PdfReader
   reader=PdfReader(io.BytesIO(raw))
   if reader.is_encrypted:raise ValueError('Encrypted PDFs are not supported')
   if len(reader.pages)>20:raise ValueError('PDF limit is 20 pages')
   text='\n\n'.join(f'[Page {i+1}] '+(page.extract_text() or '') for i,page in enumerate(reader.pages))
   if len(re.sub(r'\[Page \d+\]','',text).strip())<5:raise ValueError('No readable text. Scanned PDFs require OCR; paste their text instead.')
  elif req.filename.lower().endswith(('.txt','.md')):text=raw.decode('utf-8')
  else:raise ValueError('Upload PDF, UTF-8 TXT or Markdown')
  return save_document(Document(title=req.filename,text=text))
 except HTTPException:raise
 except Exception as e:raise HTTPException(422,'Could not import document. Use readable PDF (20 pages / 85 KB) or UTF-8 text, up to 30,000 characters.') from e

@router.delete('/documents/{id}')
def delete_document(id:str):
 with db() as c:
  d=record(c,id,'personal-document')
  if not d['editable']:raise HTTPException(403,'Built-in guidance is retained for the demo')
  c.execute('DELETE FROM objects WHERE id=?',(id,));return {'deleted':id}

@router.get('/evidence')
def evidence(q:str='wardrobe',k:int=5):
 if not 1<=k<=10 or len(q)>2000:raise HTTPException(422,'Invalid search limits')
 with db() as c:return {'evidence':lexical(q,corpus(c),k),'mode':'Local keyword retrieval; no embeddings or LLM'}

@router.post('/index')
def index():
 try:
  rag.gate()
  with db() as c:
   nodes=corpus(c);tables(c);sig=rag.signature(nodes);model=os.environ['NEBIUS_EMBEDDING_MODEL'];prior=c.execute('SELECT * FROM personal_index WHERE id=1').fetchone()
   cached=bool(prior and prior['signature']==sig and prior['model']==model)
   rows=c.execute('SELECT id,vector FROM personal_vectors').fetchall() if cached else []
  if cached:
   lookup={r['id']:json.loads(r['vector']) for r in rows}
   sync_hosted(nodes,[lookup[n['id']] for n in nodes],sig,model)
   return {'cached':True,'chunks':len(nodes)}
  reserve('ingestion')
  vectors=rag.embed([n['title']+'\n'+n['text'] for n in nodes])
  rag.validate_vectors(vectors,len(nodes))
  with db() as c:
   c.execute('BEGIN IMMEDIATE')
   if rag.signature(corpus(c))!=sig:raise ValueError('Sources changed during indexing. Try again after edits are complete.')
   tables(c);c.execute('DELETE FROM personal_vectors')
   for n,v in zip(nodes,vectors):c.execute('INSERT INTO personal_vectors VALUES(?,?,?)',(n['id'],json.dumps(n),json.dumps(v)))
   c.execute('INSERT OR REPLACE INTO personal_index VALUES(1,?,?,?)',(sig,model,now()))
  sync_hosted(nodes,vectors,sig,model)
  return {'cached':False,'chunks':len(nodes)}
 except Exception as e:raise rag.translate_error(e) from e

def live_evidence(question,nodes):
 rag.gate()
 with db() as c:
  tables(c);s=c.execute('SELECT * FROM personal_index WHERE id=1').fetchone()
  if not s or s['signature']!=rag.signature(nodes) or s['model']!=os.getenv('NEBIUS_EMBEDDING_MODEL'):raise ValueError('Build a current index before live consultation.')
  rows=c.execute('SELECT payload,vector FROM personal_vectors').fetchall()
  remote=c.execute('SELECT * FROM personal_hosted_index WHERE id=1').fetchone() if hosted.enabled() else None
  if hosted.enabled() and (not remote or remote['signature']!=s['signature'] or remote['model']!=s['model'] or remote['index_name']!=os.getenv('PINECONE_INDEX') or remote['namespace']!=hosted.namespace(s['signature'],s['model'])):raise ValueError('Build a current Pinecone index before live consultation.')
 reserve('retrieval');v=rag.embed([question]);rag.validate_vectors(v,1)
 if hosted.enabled():
  lookup={n['id']:n for n in nodes};dense_order=[lookup[id] for id in hosted.ranked_ids(v[0],nodes,remote['namespace'])]
 else:dense_order=[n for n,_ in sorted([(json.loads(r['payload']),rag.cosine(v[0],json.loads(r['vector']))) for r in rows],key=lambda pair:pair[1],reverse=True)]
 scores={n['id']:0.0 for n in nodes}
 for order in [dense_order,lexical(question,nodes,len(nodes))]:
  for rank,n in enumerate(order,1):scores[n['id']]+=1/(60+rank)
 return sorted(nodes,key=lambda n:scores[n['id']],reverse=True)[:5]

@router.post('/consult')
def consult(req:Consultation):
 started=time.perf_counter()
 try:
  boundary=unsupported_photo_assessment(req.question)
  if req.mode=='live' and not boundary:rag.gate()
  with db() as c:
   nodes=corpus(c);p=record(c,'personal-profile','personal-profile');garments=objects(c,'garment')
  sig=rag.signature(nodes);looks=proposals(p,garments)
  evidence=live_evidence(req.question,nodes) if req.mode=='live' and not boundary else lexical(req.question,nodes)
  # Explicit context is added alongside ranked evidence, never hidden from the user.
  required={'personal-profile'}|{id for look in looks for id in look['item_ids']}
  evidence=list({n['id']:n for n in evidence+[n for n in nodes if n['document_id'] in required]}.values())
  if boundary:result={'claims':[],'suggestions':['Describe your occasion, comfort needs and preferred colours so the plan can use your own preferences.'],'missing_information':['FitLore stores photos locally but does not analyse their contents.','Personality, body measurements, undertones and colour season cannot be established by this application from photos.']}
  elif req.mode=='live':result=rag.validate_answer(rag.generate(req.question,evidence),evidence)
  else:
   brief=next(n for n in nodes if n['document_id']=='personal-profile')
   result={'claims':[{'text':brief['text'],'source_ids':[brief['id']]}],'suggestions':['Try the complete combination while sitting, standing and walking.','Review the free-text preferences and event requirements before choosing.'],'missing_information':['Fit, comfort, event suitability and any current shopping availability have not been verified.']}
  if not looks:result['missing_information'].append('No complete wardrobe combination meets the selected footwear and sleeve settings. Add available items or change those settings.')
  with db() as c:
   if sig!=rag.signature(corpus(c)):raise ValueError('Your sources changed while answering. Run the consultation again.')
   item={'id':uuid.uuid4().hex,'question':req.question,'mode':req.mode,'created':now(),'corpus_signature':sig,'profile_revision':p['revision'],'looks':looks,**result,'evidence':evidence,'latency_ms':round((time.perf_counter()-started)*1000),'status':'draft','notice':'Local evidence rehearsal: extracted brief + deterministic wardrobe combinations. No model call.' if req.mode=='demo' else 'Live RAG reasoning with rule-filtered wardrobe proposals. Citation IDs checked; factual support requires review.'}
   put(c,'consultation',item)
   if boundary:
    item['mode']='boundary';item['notice']='Application capability check. No photo analysis, embeddings or model call was performed.';put(c,'consultation',item)
  return item
 except HTTPException:raise
 except Exception as e:raise rag.translate_error(e) from e

@router.post('/consultations/{id}/feedback')
def feedback(id:str,req:Feedback):
 with db() as c:
  item=record(c,id,'consultation');f={'id':uuid.uuid4().hex,'consultation_id':id,**req.model_dump(),'created':now()}
  if item.get('demo_case_id'):f['demo_case_id']=item['demo_case_id']
  put(c,'personal-feedback',f);item['status']=req.outcome;put(c,'consultation',item);check_capacity(c);return f

def demo_nodes(id):
 case=find_case(id)
 if not case:raise HTTPException(404,'Demo case not found')
 docs=[{'id':'demo-'+id+'-brief','title':case['title']+' · supplied context','text':case['brief'],'revision':1}]
 for i,g in enumerate(case['garments']):
  docs.append({'id':f'demo-{id}-item-{i}','title':g['name'],'text':f"Supplied item: {g['name']}. Material: {g['material']}. Notes: {g['notes']}",'revision':1})
 docs += [{'id':id,'title':title,'text':text,'revision':1,'url':url} for id,title,text,url in GUIDES]
 lookup={d['id']:d for d in docs}
 nodes=rag.chunks(docs)
 for n in nodes:n.update(kind='Authored demo context' if n['document_id'].startswith('demo-') else 'FitLore guidance',url=lookup[n['document_id']].get('url',''),updated='2026-10-17')
 return nodes

@router.get('/demos')
def demos():
 return {'cases':CASES,'notice':'Authored sample journeys. They use separate demo evidence and never replace your personal brief or wardrobe.'}

@router.get('/demos/{id}/evidence')
def demo_evidence(id:str,q:str='wardrobe'):
 if len(q)>2000:raise HTTPException(422,'Question is too long')
 return {'evidence':lexical(q,demo_nodes(id)),'mode':'Local keyword search of this sample case only'}

@router.post('/demos/{id}/rehearse')
def rehearse(id:str):
 started=time.perf_counter();case=find_case(id)
 if not case:raise HTTPException(404,'Demo case not found')
 nodes=demo_nodes(id)
 ranked=lexical(' '.join(case['queries']),nodes,5)
 supplied=[n for n in nodes if n['document_id'].startswith('demo-')]
 evidence=list({n['id']:n for n in ranked+supplied}.values())
 claims=[{'text':n['text'],'source_ids':[n['id']]} for n in supplied]
 item={'id':uuid.uuid4().hex,'demo_case_id':id,'question':case['question'],'mode':'demo','created':now(),'corpus_signature':rag.signature(nodes),'profile_revision':1,'looks':[],
  'claims':claims,'suggestions':[d['description'] for d in case['directions']],
  'missing_information':case['questions'],'evidence':evidence,'latency_ms':round((time.perf_counter()-started)*1000),'status':'draft',
  'walkthrough':case,'notice':'Authored styling walkthrough + local keyword retrieval. No AI model call. Optional pieces are suggestions, not items confirmed in your wardrobe.'}
 with db() as c:put(c,'consultation',item)
 return item

@router.get('/export')
def export():
 return {'format':'fitlore-workspace-v1','exported_at':now(),**state()}

EVAL_CASES=[
 ('Budget ceiling','What is the budget ceiling?','personal-profile'),
 ('Footwear preference','What footwear do I prefer?','personal-profile'),
 ('Occasion','What is my occasion?','personal-profile'),
 ('Goals','What are my goals?','personal-profile'),
 ('Avoidances','What should I avoid?','personal-profile'),
 ('Available pieces','What wardrobe items are available?','garment'),
 ('Purchase policy','Should prices stock and delivery be verified?','guide-integrity'),
 ('Personal inference','Can you infer personality or competence?','guide-integrity'),
 ('Comfort check','How do I check sitting walking movement and fit?','guide-rehearsal'),
 ('Shopping gaps','How do I identify wardrobe gaps and anchor pieces?','guide-process'),
 ('Style intention','How do practical aspirational and emotional preferences differ?','guide-method'),
 ('No lexical match','zxqv abcd987',None),
]

@router.post('/evaluate')
def evaluate():
 started=time.perf_counter()
 with db() as c:nodes=corpus(c)
 results=[]
 for name,q,expected in EVAL_CASES:
  found=lexical(q,nodes);ids=[n['document_id'] for n in found]
  passed=(not found) if expected is None else any(i.startswith(expected) for i in ids)
  results.append({'name':name,'question':q,'expected':expected,'retrieved':ids,'passed':passed})
 return {'mode':'Local retrieval smoke test; not a live RAG quality evaluation','cases':results,'passed':sum(r['passed'] for r in results),'total':len(results),'latency_ms':round((time.perf_counter()-started)*1000),'faithfulness':None,'live_generation_evaluated':False,'corpus_signature':rag.signature(nodes)}
