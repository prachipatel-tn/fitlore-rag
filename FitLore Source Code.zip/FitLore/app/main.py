import hmac
import logging
import os
from pathlib import Path
from typing import Literal

from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from app.corpus import DOCUMENTS, POLICIES, SNAPSHOT, examples
from app.engine import analyze
from app.integrations import connection_status
from app.budget import BudgetBlocked, require_cloud

ROOT = Path(__file__).resolve().parent.parent
app = FastAPI(title="FitLore", version="0.1.0", docs_url=None, redoc_url=None)


from app.fashion import router as fashion_router
app.include_router(fashion_router)
from app.studio import router as studio_router
app.include_router(studio_router)
from app.studio_rag import router as studio_rag_router
app.include_router(studio_rag_router)
from app.fitlore import router as fitlore_router
app.include_router(fitlore_router)
from app.productions import router as productions_router
app.include_router(productions_router)


class AnalysisRequest(BaseModel):
    alert: dict
    installed_version: str = Field(default="", max_length=80)
    question: str = Field(default="Prepare a cited remediation review.", max_length=2000)
    context: str = Field(default="", max_length=4000)
    policy_text: str = Field(default="", max_length=16000)
    policy_name: str = Field(default="Team policy", max_length=120)
    mode: Literal["demo", "live"] = "demo"
    exclude_sources: list[str] = Field(default_factory=list, max_length=12)


@app.middleware("http")
async def security(request: Request, call_next):
    if request.url.path.startswith("/api/") and request.url.path != "/api/status":
        token = os.getenv("PATCHBRIEF_ACCESS_TOKEN", "")
        supplied = request.headers.get("Authorization", "").removeprefix("Bearer ")
        if token and not hmac.compare_digest(token, supplied):
            return JSONResponse({"detail": "Enter the deployment access token in Connections."}, status_code=401)
    if request.method in {"POST", "PUT", "PATCH"}:
        # Cap streamed bodies as well as Content-Length (multipart/chunked bypass prevention).
        size = 0
        chunks = []
        async for chunk in request.stream():
            size += len(chunk)
            if size > 128_000:
                return JSONResponse({"detail": "Request exceeds 128 KB."}, status_code=413)
            chunks.append(chunk)
        request._body = b"".join(chunks)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: https://images.unsplash.com; connect-src 'self'; frame-ancestors 'none'"
    if request.url.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store"
    return response


@app.get("/api/status")
def status():
    return {**connection_status(), "snapshot": SNAPSHOT, "passages": len(DOCUMENTS),
            "source_documents": len({d['url'] for d in DOCUMENTS}), "version": "0.1.0"}


@app.get("/api/examples")
def get_examples():
    return {"cases": examples(), "policies": POLICIES}


@app.get("/api/corpus")
def corpus():
    return {"documents": DOCUMENTS, "snapshot": SNAPSHOT}


@app.post("/api/analyze")
def analyze_alert(req: AnalysisRequest):
    if req.mode == "live" and not connection_status()["live_configured"]:
        raise HTTPException(409, "Live mode needs the configured model, embeddings, and Pinecone credentials. See Connections.")
    try:
        if req.mode == "live":
            require_cloud()
        return analyze(req)
    except BudgetBlocked as exc:
        raise HTTPException(403, str(exc)) from exc
    except (ValueError, KeyError, TypeError, AttributeError) as exc:
        if req.mode == "demo":
            raise HTTPException(422, "Invalid alert structure. Supply a single Dependabot alert with an npm package and CVE/GHSA identifier.") from exc
        raise HTTPException(502, "The live response failed validation. No demo result was substituted. Check provider configuration and retry.") from exc
    except Exception as exc:
        logging.getLogger("patchbrief").error("Analysis failed: %s", type(exc).__name__)
        raise HTTPException(502, "Live retrieval or generation failed. Check credentials, model IDs, index ingestion, and provider availability. No demo result was substituted.") from exc


@app.get("/studio")
def studio_page():
    return FileResponse(ROOT / "web" / "studio.html")


@app.get("/")
def index():
    return FileResponse(ROOT / "web" / "personal.html")


@app.get("/inspiration")
def inspiration():
    return FileResponse(ROOT / "web" / "index.html")


@app.get("/api/docs")
def api_docs():
    return FileResponse(ROOT / "web" / "api.html")


app.mount("/static", StaticFiles(directory=ROOT / "web"), name="static")
