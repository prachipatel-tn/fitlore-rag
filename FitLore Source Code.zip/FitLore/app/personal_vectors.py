"""Bounded personal Pinecone storage. No provisioning, redirects or retries.

Only vectors and source IDs leave the document store. Namespace fingerprints
isolate revisions; local documents remain the source of retrieved text.
"""
import hashlib
import json
import os
import re
from urllib.parse import urlsplit
import httpx
from app.budget import require_cloud, reserve


def enabled():
    value = os.getenv('FITLORE_VECTOR_STORE', 'sqlite').lower()
    if value not in {'sqlite', 'pinecone'}:
        raise ValueError('FITLORE_VECTOR_STORE must be sqlite or pinecone')
    return value == 'pinecone'


def namespace(signature, model):
    prefix = os.getenv('FITLORE_PINECONE_NAMESPACE', 'fitlore-personal-v1')
    if not re.fullmatch(r'[a-zA-Z0-9_-]{1,50}', prefix):
        raise ValueError('Invalid personal namespace prefix')
    return prefix + '-' + hashlib.sha256((signature + model).encode()).hexdigest()[:24]


def request(method, url, body=None):
    require_cloud()
    with httpx.Client(timeout=20, follow_redirects=False) as client:
        response = client.request(method, url, json=body, headers={
            'Api-Key': os.environ['PINECONE_API_KEY'],
            'X-Pinecone-Api-Version': '2025-04',
        })
    response.raise_for_status()
    return response.json()


def target(dimension):
    name = os.environ['PINECONE_INDEX']
    if not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,44}', name):
        raise ValueError('Invalid Pinecone index name')
    info = request('GET', 'https://api.pinecone.io/indexes/' + name)
    if info.get('dimension') != dimension or info.get('metric') != 'cosine':
        raise ValueError('Pinecone index must use cosine and match the embedding dimensions')
    if not info.get('status', {}).get('ready'):
        raise ValueError('Pinecone index is not ready yet')
    host = info.get('host', '')
    parsed = urlsplit('https://' + host)
    if not parsed.hostname or not parsed.hostname.endswith('.pinecone.io') or parsed.netloc != host or parsed.path or parsed.username or parsed.port:
        raise ValueError('Unexpected Pinecone index host')
    return 'https://' + host


def upload(nodes, vectors, signature, model):
    from app.studio_rag import validate_vectors
    dimension = validate_vectors(vectors, len(nodes))
    host = target(dimension)
    ns = namespace(signature, model)
    records = [{'id': n['id'], 'values': v, 'metadata': {'source_id': n['id']}} for n, v in zip(nodes, vectors)]
    body = {'namespace': ns, 'vectors': records}
    if len(json.dumps(body).encode()) > 1_900_000:
        raise ValueError('Hosted upload exceeds the small-demo request limit; narrow the corpus')
    reserve('vector_write')
    result = request('POST', host + '/vectors/upsert', body)
    if result.get('upsertedCount') != len(records):
        raise ValueError('Pinecone did not acknowledge the complete vector batch')
    return ns


def ranked_ids(vector, nodes, ns):
    host = target(len(vector))
    result = request('POST', host + '/query', {
        'namespace': ns, 'vector': vector, 'topK': min(20, len(nodes)),
        'includeValues': False, 'includeMetadata': False,
    })
    ids = [m['id'] for m in result.get('matches', [])]
    allowed = {n['id'] for n in nodes}
    if not ids or any(i not in allowed for i in ids) or len(ids) != len(set(ids)):
        raise ValueError('Hosted results are missing or inconsistent with this source snapshot')
    return ids
