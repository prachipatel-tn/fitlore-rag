"""Local production projects. Role previews are not authenticated vendor accounts.

No provider, booking, messaging or payment calls occur in this module.
"""
import hashlib
import json
import uuid
from datetime import date, timedelta
from typing import Literal
from urllib.parse import urlparse

from fastapi import APIRouter, Header, HTTPException, Query
from pydantic import BaseModel, Field, field_validator

from app.project_templates import ROLE_LABELS, catalogue, template
from app.studio import db, now, objects, put

router = APIRouter(prefix='/api/fitlore/projects')
KIND = 'production-project'
NOTICE = ('Local planning workspace. Role previews are not authenticated accounts. '
          'Confirmations are user-recorded, not independently verified bookings. '
          'No messages, reservations, payments or live AI calls are made.')


class CreateProject(BaseModel):
    template_id: str = Field(min_length=1, max_length=60)
    title: str = Field(default='', max_length=140)
    event_date: date = Field(ge=date(2000, 1, 1), le=date(2100, 12, 31))
    brief: str = Field(default='', max_length=5000)


class Revision(BaseModel):
    revision: int = Field(ge=1)


class BriefUpdate(Revision):
    title: str = Field(min_length=1, max_length=140)
    brief: str = Field(min_length=5, max_length=5000)
    event_date: date = Field(ge=date(2000, 1, 1), le=date(2100, 12, 31))
    budget_cents: int = Field(ge=0, le=100_000_000)


class ResourceUpdate(Revision):
    title: str | None = Field(default=None, min_length=1, max_length=140)
    provider: str | None = Field(default=None, max_length=120)
    status: Literal['requested', 'confirmed', 'unavailable', 'not_needed']
    note: str = Field(min_length=3, max_length=2000)
    fee_cents: int = Field(ge=0, le=100_000_000)
    ready_offset: int = Field(ge=-365, le=365)


class TaskUpdate(Revision):
    status: Literal['todo', 'working', 'done']
    note: str = Field(default='', max_length=2000)


class ResourceCreate(Revision):
    title: str = Field(min_length=1, max_length=140)
    provider: str = Field(default='', max_length=120)
    owner: str = Field(min_length=1, max_length=40)
    kind: Literal['Owned', 'Purchase', 'Loan', 'Gift', 'Service', 'Venue', 'Catering'] = 'Service'
    fee_cents: int = Field(default=0, ge=0, le=100_000_000)
    ready_offset: int = Field(default=-1, ge=-365, le=365)
    note: str = Field(min_length=3, max_length=2000)
    optional: bool = False


class TaskCreate(Revision):
    title: str = Field(min_length=2, max_length=140)
    owner: str = Field(min_length=1, max_length=40)
    day_offset: int = Field(ge=-365, le=365)
    depends_on: list[str] = Field(default_factory=list, max_length=20)
    resource_ids: list[str] = Field(default_factory=list, max_length=20)
    budget_gate: bool = False


class RoleCreate(Revision):
    role: str = Field(min_length=1, max_length=40)


class Document(Revision):
    title: str = Field(min_length=2, max_length=200)
    text: str = Field(min_length=5, max_length=15000)
    url: str = Field(default='', max_length=2000)

    @field_validator('url')
    @classmethod
    def public_reference(cls, v):
        parsed = urlparse(v)
        if v and (parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password):
            raise ValueError('Use an HTTPS source reference.')
        return v


def load(c, project_id):
    row = c.execute('SELECT payload FROM objects WHERE id=? AND kind=?', (project_id, KIND)).fetchone()
    if not row:
        raise HTTPException(404, 'Project not found')
    return json.loads(row['payload'])


def role(value, p):
    if value not in ROLE_LABELS or (value != 'producer' and value not in p['roles']):
        raise HTTPException(400, 'Choose a role included in this project.')


def edit(c, project_id, revision, actor):
    c.execute('BEGIN IMMEDIATE')
    p = load(c, project_id)
    role(actor, p)
    if p['revision'] != revision:
        raise HTTPException(409, 'This project changed. Refresh and review the latest version.')
    return p


def save(c, p, actor, action):
    p['revision'] += 1
    p['updated'] = now()
    p['activity'].insert(0, {'actor': actor, 'action': action, 'created': p['updated']})
    p['activity'] = p['activity'][:60]
    try:
        project_nodes(p)
    except ValueError as exc:
        raise HTTPException(422, 'This change exceeds the local retrieval capacity. Shorten the source text.') from exc
    put(c, KIND, p)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def assess(p):
    """Derived status and transitive invalidation; completion never survives changed inputs."""
    resources = {r['id']: r for r in p['resources']}
    tasks = {t['id']: t for t in p['tasks']}
    total = sum(r['fee_cents'] for r in resources.values() if r['status'] != 'not_needed')
    results = {}

    def visit(id, visiting):
        if id in results:
            return results[id]
        if id in visiting or id not in tasks:
            raise ValueError('Invalid workflow dependency graph')
        t = tasks[id]
        dependencies = [visit(d, visiting | {id}) for d in t['depends_on']]
        blockers = []
        for dependency in dependencies:
            if dependency['effective_status'] != 'done':
                blockers.append('Finish or re-review: ' + dependency['title'])
            if dependency['day_offset'] > t['day_offset']:
                blockers.append('Scheduled before prerequisite: ' + dependency['title'])
        for resource_id in t['resource_ids']:
            r = resources[resource_id]
            waived = r.get('optional', False) and r['status'] == 'not_needed'
            if not waived and r['status'] != 'confirmed':
                blockers.append(r['title'] + ': ' + r['status'])
            if not waived and r['ready_offset'] > t['day_offset']:
                blockers.append(r['title'] + ': ready after this task')
        if t['budget_gate'] and total > p['budget_cents']:
            blockers.append('Planning estimate exceeds the budget ceiling')
        signature = digest({'brief': p['brief_revision'],
                            'sources': p['knowledge_revision'],
                            'task': {k: t[k] for k in ['id', 'owner', 'day_offset', 'depends_on', 'resource_ids', 'budget_gate']},
                            'resources': [resources[i] for i in t['resource_ids']],
                            'dependencies': [(d['id'], d['signature'], d['effective_status']) for d in dependencies],
                            'budget': [p['budget_cents'], total] if t['budget_gate'] else None})
        stale = t['status'] == 'done' and (t.get('completion_signature') != signature or bool(blockers))
        effective = 'needs_review' if stale else 'blocked' if blockers else t['status']
        value = {**t, 'effective_status': effective, 'blockers': blockers,
                 'signature': signature, 'due_date': str(date.fromisoformat(p['event_date']) + timedelta(days=t['day_offset']))}
        results[id] = value
        return value

    for id in tasks:
        visit(id, set())
    ordered = [results[t['id']] for t in p['tasks']]
    return {'tasks': ordered, 'total': len(ordered), 'estimate_cents': total,
            'budget_cents': p['budget_cents'], 'over_budget': total > p['budget_cents'],
            'done': sum(t['effective_status'] == 'done' for t in ordered),
            'needs_review': sum(t['effective_status'] == 'needs_review' for t in ordered),
            'blocked': sum(t['effective_status'] == 'blocked' for t in ordered),
            'unconfirmed': sum(r['status'] in {'requested', 'unavailable'} for r in resources.values())}


def response(p, selected='all'):
    if selected != 'all':
        role(selected, p)
    evaluation = assess(p)
    all_tasks = evaluation.pop('tasks')
    visible = all_tasks if selected == 'all' else [t for t in all_tasks if t['owner'] == selected]
    source = next(t for t in catalogue() if t['id'] == p['template_id'])
    return {**p, 'tasks': visible, 'summary': evaluation, 'view': selected,
            'references': source['references'], 'workflow': source['workflow'],
            'notice': NOTICE, 'role_labels': ROLE_LABELS, 'cloud_calls': False}


@router.get('/templates')
def templates():
    return {'templates': catalogue(), 'role_labels': ROLE_LABELS,
            'market_assessment': 'Aisle Planner, StudioBinder and Event Temple document broad event or production coordination. Personal styling and creator garment access have specialist competitors. Complete cross-category coverage has not been verified.',
            'notice': NOTICE}


@router.get('')
def projects():
    with db() as c:
        loaded = [response(p) for p in reversed(objects(c, KIND))]
        return {'projects': [{k: p[k] for k in ['id', 'title', 'template_id', 'event_date', 'revision', 'updated', 'summary', 'scenario']}
                             for p in loaded], 'notice': NOTICE}


@router.post('')
def create(req: CreateProject):
    t = template(req.template_id)
    if not t:
        raise HTTPException(404, 'Workflow template not found')
    created = now()
    p = {'id': 'production-' + uuid.uuid4().hex, 'template_id': t['id'],
         'title': req.title.strip() or t['title'], 'event_date': str(req.event_date),
         'brief': req.brief.strip() or t['brief'], 'budget_cents': t['budget_cents'],
         'roles': t['roles'], 'resources': t['resources'], 'tasks': t['tasks'],
         'documents': [{'id': 'note-' + str(i), 'title': title, 'text': text, 'url': '', 'revision': 1, 'origin': 'Fictional template note'} for i, (title, text) in enumerate(t['knowledge'])],
         'revision': 1, 'brief_revision': 1, 'knowledge_revision': 1,
         'scenario': 'Template rehearsal · fictional supplier and garment details',
         'created': created, 'updated': created,
         'activity': [{'actor': 'producer', 'action': 'Created a local workflow rehearsal', 'created': created}]}
    with db() as c:
        if len(objects(c, KIND)) >= 40:
            raise HTTPException(409, 'This local workspace supports up to 40 projects.')
        put(c, KIND, p)
    return response(p)


@router.get('/{project_id}')
def project(project_id: str, view: str = 'all'):
    with db() as c:
        return response(load(c, project_id), view)


@router.put('/{project_id}/brief')
def update_brief(project_id: str, req: BriefUpdate, x_demo_role: str = Header(default='producer')):
    with db() as c:
        p = edit(c, project_id, req.revision, x_demo_role)
        if x_demo_role not in {'producer', 'client', 'creator', 'brand', 'boutique', 'image_consultant', 'stylist'}:
            raise HTTPException(403, 'Use the project manager or brief owner view.')
        changes = req.model_dump(mode='json', exclude={'revision'})
        if any(p[k] != v for k, v in changes.items()):
            p.update(changes)
            p['brief_revision'] += 1
            save(c, p, x_demo_role, 'Updated the brief; completed decisions require review')
        return response(p)


@router.put('/{project_id}/resources/{resource_id}')
def update_resource(project_id: str, resource_id: str, req: ResourceUpdate, x_demo_role: str = Header(default='producer')):
    with db() as c:
        p = edit(c, project_id, req.revision, x_demo_role)
        r = next((r for r in p['resources'] if r['id'] == resource_id), None)
        if not r:
            raise HTTPException(404, 'Project resource not found')
        if x_demo_role not in {'producer', r['owner']}:
            raise HTTPException(403, 'Use the responsible role or project manager view.')
        if req.status == 'not_needed' and not r.get('optional', False):
            raise HTTPException(422, 'Only optional resources may be marked not needed.')
        changes = req.model_dump(exclude={'revision'}, exclude_none=True)
        if any(r.get(k) != v for k, v in changes.items()):
            r.update(changes)
            save(c, p, x_demo_role, 'Updated resource: ' + r['title'])
        return response(p)


@router.post('/{project_id}/resources')
def add_resource(project_id: str, req: ResourceCreate, x_demo_role: str = Header(default='producer')):
    with db() as c:
        p = edit(c, project_id, req.revision, x_demo_role)
        role(req.owner, p)
        if len(p['resources']) >= 30:
            raise HTTPException(409, 'This project supports up to 30 resources.')
        p['resources'].append({'id': 'resource-' + uuid.uuid4().hex,
                               **req.model_dump(exclude={'revision'}), 'status': 'requested'})
        save(c, p, x_demo_role, 'Added a requested piece or service: ' + req.title)
        return response(p)


@router.post('/{project_id}/roles')
def add_role(project_id: str, req: RoleCreate, x_demo_role: str = Header(default='producer')):
    with db() as c:
        p = edit(c, project_id, req.revision, x_demo_role)
        if req.role not in ROLE_LABELS:
            raise HTTPException(422, 'Choose a supported collaborator role.')
        if req.role not in p['roles']:
            p['roles'].append(req.role)
            save(c, p, x_demo_role, 'Added a local responsibility view: ' + ROLE_LABELS[req.role])
        return response(p)


@router.post('/{project_id}/tasks')
def add_task(project_id: str, req: TaskCreate, x_demo_role: str = Header(default='producer')):
    with db() as c:
        p = edit(c, project_id, req.revision, x_demo_role)
        role(req.owner, p)
        if len(p['tasks']) >= 40:
            raise HTTPException(409, 'This project supports up to 40 tasks.')
        if not set(req.depends_on) <= {t['id'] for t in p['tasks']} or not set(req.resource_ids) <= {r['id'] for r in p['resources']}:
            raise HTTPException(422, 'Dependencies and resources must belong to this project.')
        p['tasks'].append({'id': 'task-' + uuid.uuid4().hex, **req.model_dump(exclude={'revision'}),
                           'status': 'todo', 'note': '', 'completion_signature': None})
        save(c, p, x_demo_role, 'Added a task: ' + req.title)
        return response(p)


@router.put('/{project_id}/tasks/{task_id}')
def update_task(project_id: str, task_id: str, req: TaskUpdate, x_demo_role: str = Header(default='producer')):
    with db() as c:
        p = edit(c, project_id, req.revision, x_demo_role)
        t = next((t for t in p['tasks'] if t['id'] == task_id), None)
        if not t:
            raise HTTPException(404, 'Project task not found')
        if x_demo_role not in {'producer', t['owner']}:
            raise HTTPException(403, 'Use the responsible role or project manager view.')
        evaluated = next(t for t in assess(p)['tasks'] if t['id'] == task_id)
        if req.status == 'done' and evaluated['blockers']:
            raise HTTPException(409, 'Resolve first: ' + '; '.join(evaluated['blockers']))
        t.update(status=req.status, note=req.note,
                 completion_signature=evaluated['signature'] if req.status == 'done' else None)
        save(c, p, x_demo_role, t['title'] + ': ' + req.status)
        return response(p)


@router.post('/{project_id}/documents')
def add_document(project_id: str, req: Document, x_demo_role: str = Header(default='producer')):
    with db() as c:
        p = edit(c, project_id, req.revision, x_demo_role)
        if len(p['documents']) >= 30:
            raise HTTPException(409, 'This project supports up to 30 source notes.')
        p['documents'].append({'id': 'note-' + uuid.uuid4().hex, **req.model_dump(exclude={'revision'}), 'revision': 1, 'origin': 'User-entered project source'})
        p['knowledge_revision'] += 1
        try:
            project_nodes(p)
        except ValueError as exc:
            raise HTTPException(422, 'This source exceeds the local retrieval capacity. Shorten the text.') from exc
        save(c, p, x_demo_role, 'Added a source; completed decisions require review')
        return response(p)


def project_nodes(p):
    from app.studio_rag import chunks
    evaluated = assess(p)
    docs = [{'id': p['id'] + '-brief', 'title': 'Current project brief', 'text': p['brief'], 'revision': p['brief_revision'], 'url': '', 'kind': 'Project brief'}]
    docs.extend({'id': p['id'] + '-' + d['id'], 'title': d['title'], 'text': d['text'], 'revision': d['revision'], 'url': d['url'], 'kind': d['origin']} for d in p['documents'])
    docs.extend({'id': p['id'] + '-resource-' + r['id'], 'title': r['title'], 'text': f"{r['title']}. Arrangement: {r['kind']}. Supplier or person: {r.get('provider') or 'Not assigned'}. Responsible role: {ROLE_LABELS[r['owner']]}. Recorded status: {r['status']}. Planning fee: USD {r['fee_cents']/100:.2f}. Ready day offset: {r['ready_offset']}. Note: {r['note']}", 'revision': p['revision'], 'url': '', 'kind': 'Resource record'} for r in p['resources'])
    docs.extend({'id': p['id'] + '-task-' + t['id'], 'title': t['title'], 'text': f"{t['title']}. Responsible role: {ROLE_LABELS[t['owner']]}. Due: {t['due_date']}. Status: {t['effective_status']}. Blockers: {'; '.join(t['blockers']) or 'None'}. Note: {t['note']}", 'revision': p['revision'], 'url': '', 'kind': 'Workflow record'} for t in evaluated['tasks'])
    nodes = chunks(docs)
    lookup = {d['id']: d for d in docs}
    for n in nodes:
        n.update(url=lookup[n['document_id']]['url'], kind=lookup[n['document_id']]['kind'])
    return nodes


@router.get('/{project_id}/evidence')
def evidence(project_id: str, q: str = Query(min_length=2, max_length=2000)):
    from app.fitlore import lexical
    with db() as c:
        p = load(c, project_id)
        return {'mode': 'Local keyword retrieval · no AI generation', 'project_id': p['id'],
                'revision': p['revision'], 'evidence': lexical(q, project_nodes(p), 6),
                'notice': 'Only this project is searched. Stored confirmations are not independently verified.'}


@router.get('/{project_id}/export')
def export(project_id: str):
    with db() as c:
        return {'format': 'fitlore-project-v1', **response(load(c, project_id))}
