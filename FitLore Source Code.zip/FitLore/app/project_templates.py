"""Research-supported workflow patterns; all scenario details are fictional fixtures."""
from copy import deepcopy

RESEARCH_DATE = '2026-10-17'
ROLE_LABELS = {
    'client': 'Individual / client', 'creator': 'Influencer / talent',
    'stylist': 'Freelance stylist', 'image_consultant': 'Image consultant',
    'brand': 'Fashion house / brand', 'boutique': 'Independent shop',
    'tailor': 'Tailor', 'makeup_artist': 'Makeup artist',
    'photographer': 'Photographer', 'venue': 'Venue / location scout',
    'caterer': 'Caterer', 'producer': 'Project manager',
}
REFERENCES = {
    'indyx': {'title': 'Indyx · personal wardrobe and human styling', 'url': 'https://www.myindyx.com/', 'finding': 'Personal wardrobes connect to human styling and event-focused lookbooks.'},
    'shopmy': {'title': 'ShopMy · creator brand partnerships', 'url': 'https://guide.shopmy.us/en/articles/17358447-how-do-i-work-with-brand-partners-in-the-app', 'finding': 'Creator workflows distinguish ordinary gifts, posting commitments and paid opportunities.'},
    'runway': {'title': 'Inside Runway · stylist and brand requests', 'url': 'https://www.inside-runway.com/en/faq', 'finding': 'Projects connect garment selection, requests, confirmation, receipt, returns and coverage.'},
    'visualist': {'title': 'Visualist · the client styling journey', 'url': 'https://visualistapp.com/blog/personal-styling-client-visible-plan', 'finding': 'Client decisions sit alongside backstage sourcing, fitting preparation and lookbook delivery.'},
    'honeybook': {'title': 'HoneyBook · independent client workflows', 'url': 'https://www.honeybook.com/faqs', 'finding': 'Independent businesses coordinate inquiry, proposals, scheduling, client documents and payments.'},
    'peerspace': {'title': 'Peerspace · photoshoot locations', 'url': 'https://www.peerspace.com/plan/photo-shoot', 'finding': 'Photoshoot locations can be searched and booked through a specialist venue marketplace.'},
    'studiobinder': {'title': 'StudioBinder · production scheduling', 'url': 'https://www.studiobinder.com/film-scheduling-software/', 'finding': 'Production schedules connect scenes, locations, personnel and call sheets.'},
    'aisle': {'title': 'Aisle Planner · planning and vendor tools', 'url': 'https://help.aisleplanner.com/en/articles/1899152-aisle-planner-subscription-plan-options', 'finding': 'Event professionals use timelines, budgets, design tools, vendor records and client collaboration.'},
    'eventtemple': {'title': 'Event Temple · events and catering', 'url': 'https://www.eventtemple.com/events-and-catering', 'finding': 'Venue and catering workflows connect inquiries, proposals, bookings and banquet event orders.'},
    'seam': {'title': 'Flax & Loom × The Seam · alterations workflow', 'url': 'https://flaxandloomuk.com/pages/repair-aftercare-with-the-seam', 'finding': 'The retailer describes specialist makers, fit adjustments and at-home or studio fittings. Its stated service area is in the UK; this is workflow evidence, not a local supplier recommendation.'},
}


def resource(id, title, owner, kind, fee=0, status='requested', note='Awaiting a recorded confirmation.', optional=False):
    return {'id': id, 'title': title, 'owner': owner, 'kind': kind,
            'fee_cents': fee, 'status': status, 'note': note, 'ready_offset': -14, 'optional': optional}


def task(id, title, owner, offset, depends=(), needs=(), budget_gate=False):
    return {'id': id, 'title': title, 'owner': owner, 'day_offset': offset,
            'depends_on': list(depends), 'resource_ids': list(needs),
            'budget_gate': budget_gate, 'status': 'todo', 'note': '',
            'completion_signature': None}


TEMPLATES = [
    {
        'id': 'personal-occasion', 'title': 'Your moment, considered',
        'category': 'Individual', 'subtitle': 'A townhall, an interview, a room you want to feel ready for.',
        'outcome': 'An agreed look and a practical preparation checklist.',
        'brief': 'Fictional rehearsal: prepare a professional, approachable townhall look using a black linen skirt and brown wool T-shirt. Keep both pieces. Footwear and actual fit still need checking. No new purchase without a separate decision.',
        'roles': ['client', 'stylist', 'tailor'], 'budget_cents': 10000, 'photo': 'townhall',
        'workflow': ['Describe the occasion', 'Review real pieces', 'Try the direction', 'Confirm any alterations', 'Wear and reflect'],
        'references': ['indyx', 'visualist', 'seam'],
        'knowledge': [('Personal brief', 'Keep the black linen skirt and brown wool T-shirt. Use owned clothing first. Footwear has not been supplied. A photo cannot confirm fabric feel or sitting comfort.'), ('Fitting checklist', 'Try sitting, walking and reaching in the proposed look. Any alteration needs a quote and completion date. A proposed tailor is not a confirmed appointment.')],
        'resources': [resource('skirt', 'Black linen skirt', 'client', 'Owned', status='confirmed', note='Fictional supplied wardrobe item; actual fit is untested.'), resource('tee', 'Brown wool T-shirt', 'client', 'Owned', status='confirmed', note='Fictional supplied wardrobe item; actual fit is untested.'), resource('tailor', 'Optional alteration appointment', 'tailor', 'Service', 3500, optional=True)],
        'tasks': [task('brief', 'Agree on the occasion and comfort needs', 'client', -7), task('direction', 'Propose a direction using the two owned pieces', 'stylist', -5, ['brief'], ['skirt', 'tee']), task('rehearsal', 'Try the look; record footwear and comfort', 'client', -3, ['direction']), task('alteration', 'Record alteration decision and fitting result', 'tailor', -2, ['rehearsal'], ['tailor']), task('ready', 'Approve the final look and preparation plan', 'client', -1, ['alteration'], budget_gate=True), task('reflect', 'Record what actually worked', 'client', 1, ['ready'])],
    },
    {
        'id': 'creator-collaboration', 'title': 'A collaboration that feels like you',
        'category': 'Influencer', 'subtitle': 'Bring the brand brief, wardrobe and content decisions together.',
        'outcome': 'A personally relevant look with agreed deliverables and a recorded return.',
        'brief': 'Fictional rehearsal: create one portrait and one short styling video for an independent label. One jacket is loaned, one top is gifted. Posting obligations come from the agreed brief, not from the gift alone. Brand must review the deliverables before publication.',
        'roles': ['creator', 'stylist', 'brand', 'makeup_artist', 'photographer'], 'budget_cents': 60000, 'photo': 'creator',
        'workflow': ['Review the agreement', 'Confirm supplied pieces', 'Agree the look', 'Prepare and shoot', 'Review content', 'Record return and delivery'],
        'references': ['shopmy', 'runway', 'studiobinder'],
        'knowledge': [('Collaboration brief', 'The fictional deliverables are one portrait and one short styling video. Brand review precedes publication. Gifting alone does not establish a posting obligation. No exclusivity or usage rights have been supplied; ask for the actual agreement.'), ('Garment loan note', 'The jacket is a proposed designer loan and needs brand confirmation before the fitting. Record the return separately from content approval. The top is a gift and should not be marked for return.')],
        'resources': [resource('jacket', 'Designer jacket · proposed loan', 'brand', 'Loan'), resource('top', 'Creator-selected top · gift', 'brand', 'Gift'), resource('makeup', 'Makeup session', 'makeup_artist', 'Service', 15000), resource('camera', 'Portrait and video session', 'photographer', 'Service', 30000)],
        'tasks': [task('terms', 'Confirm deliverables and unresolved agreement terms', 'brand', -7), task('selection', 'Approve the proposed look', 'creator', -4, ['terms'], ['jacket', 'top'], True), task('fitting', 'Rehearse styling and record comfort', 'stylist', -2, ['selection'], ['jacket', 'top']), task('makeup', 'Prepare the agreed makeup direction', 'makeup_artist', 0, ['fitting'], ['makeup']), task('shoot', 'Capture the agreed portrait and video', 'photographer', 0, ['makeup'], ['camera']), task('review', 'Record brand content approval', 'brand', 1, ['shoot']), task('delivery', 'Record the published links or delivered files', 'creator', 2, ['review']), task('return', 'Record receipt of the loaned jacket', 'brand', 3, ['shoot'])],
    },
    {
        'id': 'image-refresh', 'title': 'A new chapter, recognizably yours',
        'category': 'Image consultant', 'subtitle': 'An image refresh, fittings and professional portraits.',
        'outcome': 'A client-approved direction, completed fitting and selected portraits.',
        'brief': 'Fictional rehearsal: a client wants a professional image refresh and new portraits. Keep the existing wardrobe where practical. Agree the desired impression with the client; do not infer personality or competence from appearance.',
        'roles': ['client', 'image_consultant', 'tailor', 'makeup_artist', 'photographer'], 'budget_cents': 120000, 'photo': 'conference',
        'workflow': ['Client intake', 'Agree image direction', 'Fit and refine', 'Coordinate portrait preparation', 'Select final images'],
        'references': ['visualist', 'honeybook', 'seam'],
        'knowledge': [('Client consultation', 'The image direction must come from the client’s own goals. The consultant proposes looks; the client approves them. Existing wardrobe comes first. No claim about personality or competence may be inferred from a photo.'), ('Portrait plan', 'The final fitting must precede makeup and portraits. Client image selection follows photography. Service estimates need confirmation; they are not invoices or paid bookings.')],
        'resources': [resource('fitting', 'Wardrobe fitting and alteration review', 'tailor', 'Service', 20000), resource('makeup', 'Portrait makeup session', 'makeup_artist', 'Service', 20000), resource('portraits', 'Professional portrait session', 'photographer', 'Service', 60000)],
        'tasks': [task('intake', 'Record the client’s goals and practical preferences', 'client', -10), task('direction', 'Present a proposed image direction', 'image_consultant', -8, ['intake']), task('approve', 'Approve or revise the direction', 'client', -7, ['direction'], budget_gate=True), task('fit', 'Record the final fitting result', 'tailor', -3, ['approve'], ['fitting']), task('makeup', 'Prepare the approved portrait look', 'makeup_artist', 0, ['fit'], ['makeup']), task('shoot', 'Photograph the approved direction', 'photographer', 0, ['makeup'], ['portraits']), task('select', 'Select portraits and record the useful styling choices', 'client', 3, ['shoot'])],
    },
    {
        'id': 'boutique-shoot', 'title': 'An independent label, in focus',
        'category': 'Shop / fashion house', 'subtitle': 'A small collection, a cohesive shoot, a crew with one plan.',
        'outcome': 'A confirmed location, coordinated crew and reviewed collection imagery.',
        'brief': 'Fictional rehearsal: photograph three looks from an independent boutique. Use the supplied collection. Confirm location access, garment preparation and crew before capture. Product descriptions and final images need the shop’s review.',
        'roles': ['boutique', 'stylist', 'tailor', 'makeup_artist', 'photographer', 'venue', 'producer'], 'budget_cents': 180000, 'photo': 'creator',
        'workflow': ['Agree the collection brief', 'Source and prepare pieces', 'Confirm location and crew', 'Approve the shoot plan', 'Capture and review'],
        'references': ['peerspace', 'studiobinder', 'runway'],
        'knowledge': [('Collection shoot brief', 'Photograph three looks from the supplied fictional collection. The boutique approves styling and product descriptions. Do not claim retailer stock or pricing from a reference link.'), ('Location and crew note', 'The location must confirm access before the producer approves the shoot plan. Garment preparation, makeup and photography have separate owners. A quote or shortlist is not a reservation.')],
        'resources': [resource('collection', 'Boutique collection · three looks', 'boutique', 'Loan'), resource('alterations', 'Garment preparation and fit adjustments', 'tailor', 'Service', 15000), resource('location', 'Daylight studio · shortlist', 'venue', 'Venue', 50000), resource('makeup', 'Shoot makeup and touch-ups', 'makeup_artist', 'Service', 25000), resource('camera', 'Collection photography', 'photographer', 'Service', 65000)],
        'tasks': [task('brief', 'Approve the collection brief', 'boutique', -10), task('style', 'Curate three complete looks', 'stylist', -7, ['brief'], ['collection']), task('fit', 'Prepare garments and record fit checks', 'tailor', -3, ['style'], ['alterations']), task('location', 'Record location access confirmation', 'venue', -3, ['brief'], ['location']), task('plan', 'Approve the crew and shoot plan', 'producer', -1, ['fit', 'location'], ['makeup', 'camera'], True), task('makeup', 'Complete makeup and touch-up preparation', 'makeup_artist', 0, ['plan'], ['makeup']), task('capture', 'Capture collection images', 'photographer', 0, ['makeup'], ['camera']), task('review', 'Review final imagery and garment credits', 'boutique', 2, ['capture'])],
    },
    {
        'id': 'designer-dressing', 'title': 'From designer rail to arrival',
        'category': 'Talent / celebrity', 'subtitle': 'A designer-provided appearance, with decisions and returns connected.',
        'outcome': 'A confirmed designer loan, approved fitting and documented return.',
        'brief': 'Fictional rehearsal: source a designer-provided look for a public appearance. The fashion house decides whether to lend. Any alteration needs explicit permission. A loan does not imply payment, guaranteed publicity or a permanent gift.',
        'roles': ['creator', 'stylist', 'brand', 'tailor', 'makeup_artist', 'photographer'], 'budget_cents': 100000, 'photo': 'conference',
        'workflow': ['Prepare the dressing request', 'Record designer confirmation', 'Fit with permission', 'Approve the full look', 'Prepare the appearance', 'Return and document'],
        'references': ['runway', 'visualist', 'studiobinder'],
        'knowledge': [('Dressing brief', 'The proposed garment is a designer loan, not a gift. Brand acceptance and actual availability must be recorded. The talent approves the final styling. Do not promise a designer loan before acceptance.'), ('Loan conditions', 'Confirm any alteration permission before modifying the garment. Record the agreed return date and return receipt. Credits and any content commitments must be agreed separately; they are not implied by the loan.')],
        'resources': [resource('look', 'Designer-provided look · requested', 'brand', 'Loan'), resource('permission', 'Fitting and alteration permission', 'brand', 'Service'), resource('tailor', 'Appearance fitting', 'tailor', 'Service', 20000), resource('makeup', 'Appearance makeup', 'makeup_artist', 'Service', 30000), resource('photo', 'Arrival photography', 'photographer', 'Service', 30000)],
        'tasks': [task('request', 'Prepare the event and wearer request', 'stylist', -10), task('loan', 'Record the designer’s acceptance and conditions', 'brand', -7, ['request'], ['look', 'permission']), task('fit', 'Fit the garment within the agreed permissions', 'tailor', -3, ['loan'], ['look', 'tailor']), task('approve', 'Approve the full appearance look', 'creator', -2, ['fit'], budget_gate=True), task('makeup', 'Prepare the agreed makeup direction', 'makeup_artist', 0, ['approve'], ['makeup']), task('arrival', 'Record the appearance and approved credits', 'photographer', 0, ['makeup'], ['photo']), task('return', 'Record the designer garment’s return receipt', 'brand', 2, ['arrival'])],
    },
    {
        'id': 'brand-dinner', 'title': 'A gathering with a point of view',
        'category': 'Brand / event team', 'subtitle': 'An intimate launch, from the creative brief to the final service.',
        'outcome': 'A coordinated venue, catering plan, content brief and event closeout.',
        'brief': 'Fictional rehearsal: host a 24-guest brand dinner with a creator appearance and event photographs. Confirm the venue, access, service details and guest count before approving the run of show. Costs are planning estimates, not bookings or payments.',
        'roles': ['brand', 'creator', 'producer', 'venue', 'caterer', 'photographer'], 'budget_cents': 350000, 'photo': 'townhall',
        'workflow': ['Agree the event purpose', 'Confirm venue and guest count', 'Confirm service and creative plans', 'Approve the run of show', 'Execute and recap'],
        'references': ['aisle', 'eventtemple', 'honeybook', 'peerspace'],
        'knowledge': [('Event brief', 'The fictional dinner has 24 guests. The brand approves the purpose and final run of show. Creator participation and photography need separate confirmation.'), ('Venue and service note', 'Record venue access before service planning. The caterer confirms menu, serving count and timing. Keep the event plan, service plan and current guest count aligned. Supplier selection does not constitute booking or payment.')],
        'resources': [resource('venue', 'Dinner venue and access window', 'venue', 'Venue', 90000), resource('catering', '24-guest catering estimate', 'caterer', 'Catering', 170000), resource('creator', 'Creator appearance · proposed', 'creator', 'Service'), resource('photos', 'Event photography', 'photographer', 'Service', 50000)],
        'tasks': [task('brief', 'Approve event purpose and 24-guest brief', 'brand', -14), task('venue', 'Record venue and access confirmation', 'venue', -10, ['brief'], ['venue']), task('service', 'Confirm menu, serving count and service timing', 'caterer', -5, ['venue'], ['catering']), task('creator', 'Agree the creator appearance and content expectations', 'creator', -5, ['brief'], ['creator']), task('plan', 'Approve the shared run of show', 'producer', -1, ['service', 'creator'], ['photos'], True), task('host', 'Record event execution and service handoffs', 'producer', 0, ['plan']), task('photos', 'Deliver event images for brand review', 'photographer', 1, ['host'], ['photos']), task('recap', 'Record delivered work and supplier follow-up', 'brand', 3, ['photos'])],
    },
]


def template(id):
    return next((deepcopy(t) for t in TEMPLATES if t['id'] == id), None)


def catalogue():
    return [{**{k: t[k] for k in ['id', 'title', 'category', 'subtitle', 'outcome', 'roles', 'budget_cents', 'photo', 'workflow']},
             'references': [{**REFERENCES[k], 'checked': RESEARCH_DATE} for k in t['references']],
             'verification': 'The workflow pattern is supported by public sources. This scenario is fictional; demand and outcomes have not been validated.'}
            for t in TEMPLATES]
