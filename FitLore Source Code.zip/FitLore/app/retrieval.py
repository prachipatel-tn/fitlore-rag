import math
import os
import re
from collections import Counter
from functools import lru_cache

from app.corpus import DOCUMENTS
from app.budget import reserve


def tokens(text):
    return re.findall(r"[a-z0-9_.-]+", text.lower())


def lexical_search(query, package, cve, excluded=()):
    docs = [d for d in DOCUMENTS if d["package"] == package and d["cve"] == cve and d["id"] not in excluded]
    if not docs:
        return []
    bags = [Counter(tokens(d["title"] + " " + d["text"])) for d in docs]
    avg = sum(sum(b.values()) for b in bags) / len(bags)
    scores = []
    for d, bag in zip(docs, bags):
        score = 0.0
        for term in set(tokens(query)):
            freq = bag[term]
            df = sum(term in b for b in bags)
            idf = math.log(1 + (len(docs) - df + .5) / (df + .5))
            score += idf * freq * 2.5 / (freq + 1.5 * (.25 + .75 * sum(bag.values()) / avg))
        scores.append({**d, "retrieval_score": round(score, 4)})
    return sorted(scores, key=lambda d: d["retrieval_score"], reverse=True)


@lru_cache(maxsize=1)
def embedding_model():
    from llama_index.embeddings.openai_like import OpenAILikeEmbedding
    return OpenAILikeEmbedding(model_name=os.environ["NEBIUS_EMBEDDING_MODEL"],
        api_base=os.getenv("NEBIUS_BASE_URL", "https://api.tokenfactory.nebius.com/v1/"),
        api_key=os.environ["NEBIUS_API_KEY"], embed_batch_size=16, timeout=30, max_retries=0)


def vector_store():
    from pinecone import Pinecone
    from llama_index.vector_stores.pinecone import PineconeVectorStore
    pc = Pinecone(api_key=os.environ["PINECONE_API_KEY"])
    return PineconeVectorStore(pinecone_index=pc.Index(os.environ["PINECONE_INDEX"]),
        namespace=os.getenv("PINECONE_NAMESPACE", "patchbrief-v1"))


def dense_search(query, package, cve):
    reserve("retrieval")
    from llama_index.core import VectorStoreIndex
    from llama_index.core.vector_stores import MetadataFilter, MetadataFilters
    index = VectorStoreIndex.from_vector_store(vector_store(), embed_model=embedding_model())
    retriever = index.as_retriever(similarity_top_k=4, filters=MetadataFilters(filters=[
        MetadataFilter(key="package", value=package), MetadataFilter(key="cve", value=cve)]))
    return [n.node.metadata["source_id"] for n in retriever.retrieve(query)]


def retrieve(query, package, cve, live=False, excluded=()):
    lexical = lexical_search(query, package, cve, excluded)
    if not live or not lexical:
        return lexical, "BM25 · local snapshot"
    dense_ids = dense_search(query, package, cve)
    known = {d["id"] for d in lexical}
    dense_ids = list(dict.fromkeys(i for i in dense_ids if i in known))
    if not dense_ids:
        raise RuntimeError("No matching vectors. Ingest this corpus into the configured namespace first.")
    scores = Counter()
    for ids in ([d["id"] for d in lexical], dense_ids):
        for rank, source_id in enumerate(ids, 1):
            scores[source_id] += 1 / (60 + rank)
    # Reciprocal-rank fusion is a ranking method, not a learned reranker.
    return sorted([{**d, "retrieval_score": round(scores[d["id"]], 5)} for d in lexical],
                  key=lambda d: d["retrieval_score"], reverse=True), "BM25 + Pinecone · reciprocal-rank fusion"
