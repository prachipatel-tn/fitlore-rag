"""Single-workspace local agency demo. Role selection is NOT authentication."""
import json
import os
import re
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse
from typing import Literal
from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel, Field, field_validator
from app.fashion import LOOKS

router=APIRouter(prefix='/api/studio')
ROLES=['consultant','client','manager','finance','analyst','admin']
EDITORS={'consultant','manager','admin'}
def now(): return datetime.now(timezone.utc).isoformat()
def db():
 p=Path(os.getenv('FITLORE_STUDIO_DB','data/runtime/fitlore.sqlite3'));p.parent.mkdir(parents=True,exist_ok=True)
 c=sqlite3.connect(p);c.row_factory=sqlite3.Row
 c.execute('CREATE TABLE IF NOT EXISTS objects(id TEXT PRIMARY KEY, kind TEXT, payload TEXT)')
 c.execute('CREATE TABLE IF NOT EXISTS activity(id INTEGER PRIMARY KEY, actor TEXT, action TEXT, created TEXT)')
 return c

def put(c,kind,p):
 c.execute('INSERT OR REPLACE INTO objects VALUES(?,?,?)',(p['id'],kind,json.dumps(p)))
def objects(c,kind):return [json.loads(r['payload']) for r in c.execute('SELECT payload FROM objects WHERE kind=? ORDER BY rowid',(kind,))]
def get(c,id):
 r=c.execute('SELECT payload FROM objects WHERE id=?',(id,)).fetchone()
 if not r:raise HTTPException(404,'Record not found')
 return json.loads(r['payload'])
def log(c,role,action):c.execute('INSERT INTO activity(actor,action,created) VALUES(?,?,?)',(role,action,now()))
def permit(role,allowed):
 if role not in ROLES:raise HTTPException(400,'Unknown demo view')
 if role not in allowed:raise HTTPException(403,'This action belongs to another demo role')
def seed(c):
 if c.execute("SELECT 1 FROM objects WHERE id='project'").fetchone():return
 put(c,'project',{'id':'project','client':'Alex Morgan · fictional demo','entity':'Person','event':'Founder keynote & press portraits','goals':'Credible, approachable, inventive','preferences':'Comfortable flats; sleeves; neutral base with one distinctive accent. Reuse owned clothing first.','avoid':'No unverified awards or exaggerated claims in the bio.','budget_cents':50000,'consultant':'Jordan · demo consultant','revision':1})
 for d in [
 {'id':'brief','title':'Client image brief · fictional fixture','text':'Alex Morgan is a fictional founder preparing a keynote and press portraits. The desired image is credible, approachable and inventive. Alex prefers comfortable flats and sleeves, a neutral base and one distinctive accent. Reuse owned garments before recommending purchases. The wardrobe budget and planning ceiling is USD 500 before tax and shipping.','type':'Client brief'},
 {'id':'event','title':'Event brief · fictional fixture','text':'The fictional founder keynote includes seated conversation, standing presentation and press portraits. The sample event dress expectation is smart casual. The final outfit needs a sitting and walking comfort check. The client must approve the final look and the introduction before use.','type':'Event brief'},
 {'id':'brand','title':'Brand messaging brief · fictional fixture','text':'The fictional founder brand values clarity, curiosity and approachability. Introductions should use the person’s actual role and verified work. Awards, revenue, partnerships and audience reach are not supplied; do not invent them. Public claims require client approval.','type':'Brand brief'},
 {'id':'process','title':'Studio approval procedure · demo policy','text':'Consultants create proposals and cite source notes. Draft looks can be submitted for client review. The client approves or requests changes. Editing an approved look resets it to draft. Changing the client brief makes earlier looks stale. Finance approves estimated expense lines separately; approval is not a purchase or payment.','type':'Studio policy'}]:
  d.update(url='',created=now(),revision=1);put(c,'document',d)
 for i,(title,url,kind) in enumerate([
 ('UNIQLO · women’s blazer collection','https://www.uniqlo.com/us/en/women/outerwear-and-blazers/blazers','Collection'),
 ('Everlane · The Modern Loafer, Black','https://www.everlane.com/products/womens-leather-modern-loafer-black','Product'),
 ('COS · women’s wide-leg trousers','https://www.cos.com/en-us/women/trousers/wide-leg-trousers','Collection')]):
  put(c,'source',{'id':'source'+str(i),'title':title,'url':url,'type':kind,'notes':'Research reference found October 17, 2026. Not a price, size or stock verification.','created':now(),'availability':'Unverified','price_cents':None})
 c.commit()

class Project(BaseModel):
 client:str=Field(min_length=1,max_length=120)
 entity:Literal['Person','Brand']='Person'
 event:str=Field(min_length=1,max_length=200)
 goals:str=Field(min_length=1,max_length=1000)
 preferences:str=Field(default='',max_length=2000)
 avoid:str=Field(default='',max_length=1000)
 budget_cents:int=Field(default=50000,ge=0,le=100000000)
 consultant:str=Field(default='Jordan · demo consultant',max_length=120)
class Source(BaseModel):
 title:str=Field(min_length=1,max_length=200)
 url:str=Field(default='',max_length=2000)
 type:Literal['Product','Collection','Research','Owned item']='Research'
 notes:str=Field(default='',max_length=5000)
 price_cents:int|None=Field(default=None,ge=0,le=100000000)
 @field_validator('url')
 @classmethod
 def valid_url(cls,v):
  if v and (urlparse(v).scheme!='https' or not urlparse(v).hostname or urlparse(v).username):raise ValueError('Use a public HTTPS reference URL')
  return v
class Look(BaseModel):
 title:str=Field(min_length=1,max_length=120)
 rationale:str=Field(default='',max_length=3000)
 photo_id:str=Field(default='1',max_length=10)
 pieces:list[str]=Field(default_factory=list,max_length=15)
 source_ids:list[str]=Field(default_factory=list,max_length=20)
class Decision(BaseModel):
 status:Literal['draft','review','approved','changes']
 note:str=Field(default='',max_length=2000)
class Comment(BaseModel):
 target:str=Field(default='project',max_length=100)
 text:str=Field(min_length=1,max_length=3000)
class Expense(BaseModel):
 title:str=Field(min_length=1,max_length=200)
 amount_cents:int=Field(ge=0,le=100000000)
 source_id:str=Field(default='',max_length=100)
class Document(BaseModel):
 title:str=Field(min_length=1,max_length=200)
 text:str=Field(min_length=1,max_length=30000)
class Query(BaseModel):
 question:str=Field(min_length=3,max_length=2000)
class Point(BaseModel):
 x:float=Field(ge=0,le=900)
 y:float=Field(ge=0,le=500)
class Stroke(BaseModel):
 color:Literal['#252820','#9c493d','#69793d']='#252820'
 points:list[Point]=Field(max_length=1500)
class Sketch(BaseModel):
 strokes:list[Stroke]=Field(max_length=100)

@router.get('/state')
def state(x_demo_role:str=Header(default='consultant')):
 permit(x_demo_role,set(ROLES))
 with db() as c:
  seed(c);p=get(c,'project');looks=objects(c,'look')
  for l in looks:l['stale']=l['brief_revision']!=p['revision']
  expenses=objects(c,'expense');approved=sum(e['amount_cents'] for e in expenses if e['status']=='approved')
  return {'project':p,'looks':looks,'sources':objects(c,'source'),'comments':objects(c,'comment'),'documents':objects(c,'document') if x_demo_role in EDITORS|{'analyst'} else [],'sketch':objects(c,'sketch'),'expenses':expenses if x_demo_role in {'finance','manager','admin'} else [],'metrics':{'looks':len(looks),'awaiting_review':sum(l['status']=='review' for l in looks),'approved_looks':sum(l['status']=='approved' and not l['stale'] for l in looks),'stale_looks':sum(l['stale'] for l in looks),'sources':len(objects(c,'source')),'unverified_sources':len(objects(c,'source')),'approved_estimate_cents':approved,'budget_cents':p['budget_cents']},'activity':[dict(r) for r in c.execute('SELECT * FROM activity ORDER BY id DESC LIMIT 30')],'role':x_demo_role,'demo_notice':'Single local workspace. Selectable demo roles are not authenticated accounts; do not deploy publicly or enter confidential client data.'}

@router.put('/project')
def project(req:Project,x_demo_role:str=Header(default='consultant')):
 permit(x_demo_role,EDITORS)
 with db() as c:
  seed(c);old=get(c,'project');p={'id':'project',**req.model_dump(),'revision':old['revision']+1};put(c,'project',p)
  put(c,'document',{'id':'brief','title':'Current client brief · entered in demo','text':f"Client: {p['client']}. Moment: {p['event']}. Goals: {p['goals']}. Preferences: {p['preferences']}. Avoid: {p['avoid']}. Budget ceiling USD {p['budget_cents']/100:.2f}. Assigned consultant: {p['consultant']}.",'type':'Client brief','url':'','created':now(),'revision':p['revision']})
  log(c,x_demo_role,'Updated brief; earlier looks require review');return p
@router.post('/sources')
def source(req:Source,x_demo_role:str=Header(default='consultant')):
 permit(x_demo_role,EDITORS)
 with db() as c:
  seed(c);p={'id':uuid.uuid4().hex,**req.model_dump(),'created':now(),'availability':'Unverified'};put(c,'source',p);log(c,x_demo_role,'Added source: '+req.title);return p
@router.post('/looks')
def look(req:Look,x_demo_role:str=Header(default='consultant')):
 permit(x_demo_role,EDITORS)
 with db() as c:
  seed(c)
  if req.photo_id not in {l['id'] for l in LOOKS}:raise HTTPException(422,'Unknown reference photo')
  if not set(req.source_ids)<= {s['id'] for s in objects(c,'source')}:raise HTTPException(422,'Unknown source')
  p={'id':uuid.uuid4().hex,**req.model_dump(),'brief_revision':get(c,'project')['revision'],'status':'draft','created':now()};put(c,'look',p);log(c,x_demo_role,'Created look: '+req.title);return p
@router.post('/looks/generate')
def generate(x_demo_role:str=Header(default='consultant')):
 permit(x_demo_role,EDITORS)
 with db() as c:
  seed(c);p=get(c,'project');out=[]
  for title,photo,rationale,pieces in [('Approachable expert','6','Soft structure and conversational presence',['Light outer layer','Owned neutral base','Comfortable footwear']),('Understated authority','1','A restrained palette and a clear silhouette',['Structured outer layer','Tonal base','Simple accessories']),('Expressive original','2','One distinctive accent around a familiar base',['Owned base outfit','One expressive accessory','Comfortable footwear'])]:
   item={'id':uuid.uuid4().hex,'title':title,'photo_id':photo,'rationale':f"{rationale}. Brief goals: {p['goals']}. Check against preferences: {p['preferences']}. Local starting proposal, not verified fit.",'pieces':pieces,'source_ids':[],'brief_revision':p['revision'],'status':'draft','created':now()};put(c,'look',item);out.append(item)
  log(c,x_demo_role,'Created three local starting directions from brief');return out
@router.post('/looks/{id}/decision')
def decision(id:str,req:Decision,x_demo_role:str=Header(default='consultant')):
 allowed={'draft':EDITORS,'review':EDITORS,'approved':{'client'},'changes':{'client'}}
 permit(x_demo_role,allowed[req.status])
 with db() as c:
  l=get(c,id)
  if 'brief_revision' not in l:raise HTTPException(422,'Not a look')
  if req.status in {'approved','changes'} and l['status']!='review':raise HTTPException(409,'Submit the look for review first')
  if req.status in {'approved','review'} and l['brief_revision']!=get(c,'project')['revision']:raise HTTPException(409,'This look uses an older brief. Create a revised look before approval.')
  l['status']=req.status;put(c,'look',l);log(c,x_demo_role,f"{req.status}: {l['title']}")
  if req.note:put(c,'comment',{'id':uuid.uuid4().hex,'target':id,'text':req.note,'actor':x_demo_role,'created':now()})
  return l
@router.post('/comments')
def comment(req:Comment,x_demo_role:str=Header(default='client')):
 permit(x_demo_role,set(ROLES))
 with db() as c:
  seed(c);get(c,req.target);p={'id':uuid.uuid4().hex,**req.model_dump(),'actor':x_demo_role,'created':now()};put(c,'comment',p);log(c,x_demo_role,'Added project feedback');return p
@router.post('/expenses')
def expense(req:Expense,x_demo_role:str=Header(default='finance')):
 permit(x_demo_role,{'finance','manager','admin'})
 with db() as c:
  seed(c)
  if req.source_id and req.source_id not in {s['id'] for s in objects(c,'source')}:raise HTTPException(422,'Unknown source')
  p={'id':uuid.uuid4().hex,**req.model_dump(),'status':'proposed','created':now()};put(c,'expense',p);log(c,x_demo_role,'Added planning estimate: '+req.title);return p
@router.post('/expenses/{id}/approve')
def expense_approve(id:str,x_demo_role:str=Header(default='finance')):
 permit(x_demo_role,{'finance','manager','admin'})
 with db() as c:
  p=get(c,id)
  if 'amount_cents' not in p:raise HTTPException(422,'Not an expense')
  p['status']='approved';put(c,'expense',p);log(c,x_demo_role,'Approved estimate (no purchase): '+p['title']);return p
@router.put('/sketch')
def sketch(req:Sketch,x_demo_role:str=Header(default='consultant')):
 permit(x_demo_role,EDITORS)
 with db() as c:
  seed(c);p={'id':'sketch',**req.model_dump(),'created':now()};put(c,'sketch',p);log(c,x_demo_role,'Saved sketch');return p
@router.post('/documents')
def document(req:Document,x_demo_role:str=Header(default='consultant')):
 permit(x_demo_role,EDITORS)
 with db() as c:
  seed(c);p={'id':uuid.uuid4().hex,**req.model_dump(),'type':'Pasted source','url':'','created':now(),'revision':1};put(c,'document',p);log(c,x_demo_role,'Added knowledge document: '+req.title);return p
@router.post('/ask')
def ask(req:Query,x_demo_role:str=Header(default='consultant')):
 permit(x_demo_role,EDITORS|{'analyst'})
 with db() as c:
  seed(c);docs=objects(c,'document');terms=set(re.findall(r'[a-z]{3,}',req.question.lower()))-{'the','and','for','what','does','with','can','this','that','are','our','how'};ranked=[]
  for d in docs:
   words=d['text'].split()
   for start in range(0,len(words),100):
    passage=' '.join(words[start:start+120]);score=len(terms & set(re.findall(r'[a-z]{3,}',passage.lower()))) + 0.5*len(terms & set(re.findall(r'[a-z]{3,}',d['title'].lower())))
    if score:ranked.append({'source_id':d['id'],'title':d['title'],'chunk':start//100,'text':passage,'score':score,'revision':d['revision']})
  ranked.sort(key=lambda x:x['score'],reverse=True)
  return {'answer':'Relevant passages from your workspace follow. These are extracted evidence, not generated recommendations.' if ranked else 'I could not find supporting evidence in this workspace. Add a relevant source or ask your consultant.','citations':ranked[:3],'mode':'Local lexical retrieval · no embeddings or LLM call','rag_complete':False}
