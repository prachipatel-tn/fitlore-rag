# FitLore recording guide

Use the current [click-by-click recording guide](http://127.0.0.1:8000/static/demo-guide.html). It contains the timed five-minute route, all three style stories, all six prepared project workflows, consultant role views, exact form labels and test findings.

A plain-text companion is available at `web/demo-steps.txt`. Machine-readable results are in `output/full-test-results.json`; the test suite report is `output/full-test-results.xml`.

Record the saved live consultation before editing personal sources. The current index is preserved, two live retrieval attempts remain, and the six Recording demo projects are prepared without cloud calls. Reopening saved output consumes no credits.

Verified on 17 October 2026: 145 automated tests passed; 42 desktop views audited with no broken images or horizontal overflow observed; all six workflows passed isolated recall, blocked completion, recovery, full completion and export. Remaining AI relevance weaknesses are documented in the guide.

The latest thirty-run live comparison and remaining weaknesses are documented at /static/quality-report.html. The final local Word report is in output/submission/.
