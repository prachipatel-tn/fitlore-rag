# FitLore local prototype

Run `.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000` from the repository root.

The new home page replaces PatchBrief with fashion discovery: twelve original SVG outfit concepts, four aesthetic filters, search, local outfit adaptation and browser-persisted saved looks. The illustrations are schematic, not photography, fit previews or retail products. Styling responses use deterministic local rules. The trend edit exposes two dated editorial references, not a live trend feed.

Demo: open a look, select Campus / Sneakers / More coverage / Statement, remix, save, close, and open Saved looks. Reload to check persistence. Trend Edit exposes reference dates; Behind the Looks separates current and planned architecture.

API: GET /api/fashion/catalog; POST /api/fashion/style with look_id, occasion, footwear, coverage and intensity. No cloud SDK is called by either endpoint. The existing deployment access-token middleware still applies. The legacy PatchBrief API, tests and provider modules are preserved for migration; their retrieval corpus and ingestion script must NOT be used as a fashion pipeline. Original front-end files are preserved in web/archive.

Not yet implemented: fashion document ingestion, embeddings and retrieval, live model styling, personal uploads, product pricing, named boards, piece-by-piece swaps, automated freshness checks and licensed fashion photography. This local prototype alone does not yet satisfy the handout's complete RAG requirement. Fashion-specific evaluation and a curated reusable corpus are the next implementation stage. Existing secrets were not modified and cloud billing remains locked.

## Personal image studio
The default home is now a consultation brief. Users choose an occasion, desired qualities, formality, budget approach and one of three creative directions. POST /api/fashion/consult returns a locally templated outfit direction, tradeoff, introduction with placeholders, photo brief and preparation checklist. Kits can be downloaded as plain text. Changing the brief flags the existing kit as stale. The brief is not persisted; saved fashion looks remain browser-local.

This does not assess personality or predict audience perceptions. Collaboration, source-grounded image advice, editable shared decision boards and live RAG remain future work. No new cloud services were enabled.


## Photographic lookbook refresh
The discovery view now uses six credited Unsplash photographic references instead of the SVG concepts. Each source page was checked for the free Unsplash License. Images load directly from images.unsplash.com (no API key or paid model call); network access is needed for photography. Source links and photographer names are stored with each look and displayed in cards and the studio. Written adaptations do not alter the photographs and are not try-on previews. The image CSP allows only the specific image host in addition to local/data images. Catalogue filters, search, save, remix and consultation remain local.

## Agency Studio
Open /studio for a persistent SQLite workspace: client/person-or-brand brief, six demo role views, automatic starter looks and custom looks, attached sources, client decisions, comments, sketches, estimates and activity-based analytics. See submission.md for the handout audit and dated competitive research. The default database is data/runtime/fitlore.sqlite3 (gitignored); tests use temporary databases. Role switching is explicitly a local demo and not account authentication. This update adds a project knowledge desk with 120-word lexical retrieval and source passages, not full RAG. Readiness gaps are listed in submission.md.

## Platform expansion research — October 17, 2026

### Product thesis
FitLore connects how a person or brand wants to show up with the references, decisions and work required to do it. It is a shared creative and professional workspace with evidence-backed recommendations. This is a proposed position, not a proven unoccupied market.

Three workspaces share a common data model:
- Personal: upcoming moments, self-declared preferences, wardrobe, preparation and feedback.
- Creator: personal brand brief, ideas, content plans, sponsor leads, campaign briefs, deliverables, approvals and business records.
- Studio: multiple represented people/brands, assignments, creative directions, campaign preparation and client decisions. Freelancers can use a one-person Studio without agency complexity.

Roles are separate from workspace types: owner/client, assigned consultant, manager, finance, analyst, admin. Real authentication, workspace membership and object permissions must precede production/private-client use. The current switcher is still a demo.

### Existing products and counterevidence
Public product/help pages inspected, not hands-on account benchmarks:
- Passionfroot: creator sponsorship workflows, media kits, booking/scheduling, opportunities and payments. https://www.passionfroot.me/creators
- Later: creator tools spanning brand collaborations, scheduling and Link in Bio. https://later.com/creator/
- HoneyBook: AI-powered client relationship platform; contracts/invoices/project workflows, with AI summaries and drafts. https://www.honeybook.com/ and https://www.honeybook.com/product/ai
- Fohr: creator profiles and brand-facing creator opportunities. https://www.fohr.co/for-creators
- Cosmos: visual inspiration collection, discovery across creative categories and collaboration. https://help.cosmos.so/en/articles/11846092-intro-to-cosmos
- Are.na: collecting content and connecting ideas over time. https://www.are.na/about
- Muck Rack: media research, pitching, monitoring and reporting. https://muckrack.com/pr-software/
- Previously researched Hue & Stripe, Milanote, Stylitics, FindMine, ShopMy and Launchmetrics overlap substantially with styling, creative collaboration, commerce and brand operations.

Therefore neither all-in-one nor AI chat nor boards is a defensible uniqueness claim. A testable wedge is identity-consistent execution: recommendations combine approved preferences, project commitments, earlier feedback and current source evidence, with every factual assertion traceable and proposed changes reviewable.

### What makes this native RAG
A creator asks: 'Plan next week's launch content and looks using my sponsor brief, personal style, approved claims and last campaign feedback.' Retrieve scoped sources from each relevant category, expose missing/conflicting evidence, create a draft containing cited constraints and explicitly creative alternatives. Accepting a draft creates structured content/looks/tasks, linked to source IDs and revisions. A changed source invalidates affected decisions.

The retrieval layer should be present in recommendation and planning actions, not only a side-panel chatbot. A visual board is a rendering of a structured creative proposal. Boards, sourcing and saved ideas must not become detached copies of the original evidence.

Example tasks:
- Personal: prepare an outfit and introduction using occasion details, owned clothing and expressed preferences.
- Creator: draft a content plan that incorporates source-supported sponsor requirements, prior approved posts and recorded audience feedback. Do not invent analytics.
- Brand consultant: compare visual concepts against brand guidelines and campaign audience notes.
- Image/PR consultant: draft an appearance brief from approved biography, event notes and communications guidance; never invent credentials or act as crisis counsel.
- Freelancer: draft a proposal from a lead brief, documented availability and prior scope examples; do not invent prices or promises.

### Data and boundaries
Core objects: workspace, membership, represented entity, brief, moment/campaign, source, source chunk, reference asset, product/variant, idea, proposal/look, lead/contact, deliverable, approval, expense, feedback. Relational queries provide exact status, money, dates and assignment relationships. RAG explains and drafts from unstructured documents. They are complementary; financial totals must not come from nearest-neighbour search.

Keep the public inspiration library separate from private workspace knowledge and perishable product information. Public records need source URL, creator/publisher, category, publication date, observed_at and reuse rights. Product records need retailer, variant/size, currency, observed price, stock status and checked_at. An old embedding is not evidence of current availability. Refresh through supported feeds/APIs before a recommendation claims purchasability. Missing data remains unknown.

Fashion, art and cinema can supply references, but 'everything in the world' is not a useful initial corpus. Start with three curated collections and user-supplied documents. Link to rights-restricted originals; do not republish a film still or editorial photograph simply because it is online. No scraping or social publishing integration has been implemented.

### Architecture and sequence
Browser -> authenticated scoped API (pending) -> SQL workspace state + hybrid retrieval -> bounded model draft -> citation/constraint checks -> human review -> structured saved proposal. Shared image-reference retrieval can be multimodal later; the current pipeline is text-only and does not understand photos or sketches.

For the deadline, demonstrate one creator preparing a launch: profile and sponsor brief -> retrieved obligations -> content/look proposal -> approval -> source change -> invalidation. Follow with a regular-user occasion using the same engine. Do not attempt a payments system, automated social publishing or a media-monitoring network before verifying this flow.

### RAG implementation added in this update
app/studio_rag.py adds a separate FitLore pipeline: clean whitespace, 240-word chunks / 40-word overlap; hash IDs tied to source revision and content; Nebius embeddings via LlamaIndex; local SQLite vector storage; cosine and lexical overlap ranking fused with reciprocal ranks; top five evidence chunks; bounded Nebius JSON generation; source-ID validation; stale-index blocking before and after generation. Source ID validation does not prove entailment. Hybrid retrieval thresholds and semantic coverage need a real evaluation.

Endpoints: GET /api/studio/rag/status, POST /api/studio/rag/index, POST /api/studio/rag/answer. Evidence Desk exposes controls and lock state. SQLite avoids provisioning paid vector storage for the tiny demo; a dedicated Pinecone adapter can replace it once hosted storage is justified. The legacy advisory index is not reused.

Both PATCHBRIEF_ALLOW_CLOUD and FITLORE_RAG_ALLOW_CLOUD must be true before cloud operations. Neither was enabled. Indexing sends document text to Nebius; answering sends questions and retrieved passages. Existing persistent attempt allowances apply, including one ingestion attempt; revising and reindexing will require revisiting that allowance intentionally after billing verification. Tracing is disabled in the new pipeline. No real generation, embedding, Pinecone or LangSmith call was made.

56 tests pass. Six new tests cover locked-before-network behavior, mocked end-to-end indexing/retrieval/generation and cache use, stale-index blocking, invented-citation rejection, chunk overlap, and invalid embeddings. This is implementation testing, not measured live retrieval relevance or faithfulness. Source corpus quality, model behavior, real latency and end-to-end provider compatibility remain unverified. Do not mark the Week 2 project complete yet.
