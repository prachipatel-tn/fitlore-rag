# FitLore architecture — current implementation

Current entry point: `/`. The personal workflow supersedes the earlier fashion-feed landing page. `/inspiration` retains photographic exploration; `/studio` retains the separate agency demo. Earlier design notes are preserved in `fitlore-development-history.md` and are not current implementation claims.

## Personal data flow

1. The browser saves a personal brief, garment records and locally resized photos to FastAPI.
2. PDF/text ingestion extracts source text, keeping page markers and provenance metadata.
3. The personal corpus includes current brief, garment text, guidance summaries, uploaded sources and reflections. Agency fixture documents are excluded.
4. Documents become 240-word chunks with 40-word overlap, revision-based IDs and a corpus signature.
5. Explicitly enabled indexing uses LlamaIndex's Nebius adapter and stores vectors in local SQLite.
6. Live queries combine cosine and lexical rankings with reciprocal-rank fusion. Current brief and selected-item context are added explicitly and exposed in the evidence view.
7. Nebius returns factual claims with citation IDs, creative suggestions and missing information. Schema and citation checks reject malformed output. A final signature check rejects answers created while source data changed.
8. Plans and evidence snapshots persist. Reflections join future retrieval and make old indexes stale.

## Boundaries

- `app/fitlore.py`: personal API, storage objects, ingestion, constraints, index, retrieval, consultation and evaluation.
- `app/studio_rag.py`: shared chunking, provider adapters and citation schema validation; separate agency RAG endpoints.
- `app/budget.py`: fail-closed gates and shared persistent attempt ceilings.
- `web/personal.*`: primary interface.
- `scripts/evaluate_fitlore.py`: local checks and explicitly requested live evaluation.
- `tests/test_fitlore.py`: corpus isolation, real PDF extraction, constraints, lock protection, mocked live integration and error paths.

Rehearsal is extracted evidence plus rules, not a fake model response. Wardrobe proposals remain rule-based even in live mode. Local vectors avoid provisioning a paid hosted index. No personal tracing, OCR, image embeddings, retailer inventory feed, professional fit verification or production tenant authentication is implemented.

The local browser flow has been checked for consultation creation, citation navigation, reflection persistence, document upload and evaluation. The full suite passed 72 tests; the current local corpus passed 12/12 lexical checks. Live quality is unmeasured. See README.md for setup and docs/submission.md for outstanding submission steps.

## Rehearsal Room and visual refinement
Three authored sample journeys now have five navigable stages, isolated case corpora, scoped keyword searches and saved demo plans. Sample feedback stays outside the personal retrieval corpus. The Bigger Picture screen maps working personal and agency capabilities and labels the live pipeline as gated. See townhall-walkthrough.md and capabilities.mmd.

## Cohesive navigation update
The main interface now uses Discover, My studio, Wardrobe and Saved looks. The brief, session and sources are grouped under My studio; technical views moved to the footer. Demo shape illustrations were removed in favour of credited editorial photography. Stories now occupy a single continuous page. Navigation uses browser history, section anchors and saved-plan IDs so Back and refresh restore context. Browser checks covered the full brief-to-plan flow, photo loading and navigation restoration; 16 focused personal-project tests passed.
