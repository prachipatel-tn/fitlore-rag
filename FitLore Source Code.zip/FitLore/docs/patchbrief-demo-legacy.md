# Five-minute demo plan

0:00–0:35 — Explain the problem: a dependency alert still needs a defensible
engineering handoff. PatchBrief connects vendor evidence with team policy.

0:35–1:30 — Open Vite, identify the source snapshot and installed version, and
generate a brief. State whether this is local demo or verified live mode. Show
the documented branch fix and reverse-proxy configuration considerations.

1:30–2:10 — Click a citation. Open the original vendor advisory. Explain that the
corpus contains editor-written summaries and the original source remains available.

2:10–2:45 — Switch from the standard sample policy to the accelerated one.
Regenerate and show the changed review window. The vulnerability facts stay the same.

2:45–3:20 — Expand the missing-evidence control and omit the version passage.
Regenerate. Show that version applicability becomes unknown and no patch is inferred.

3:20–3:50 — Restore the evidence, generate again, preview the Markdown ticket,
and export it. Nothing has been posted or automatically approved.

3:50–4:25 — Open Evaluation and run the 15 cases. Explain these are deterministic
behavior checks, not a measured model-faithfulness percentage.

4:25–5:00 — Describe Codex's role, the live stack, and remaining limits. Show a
real LangSmith trace only after delivery is verified. State exactly which
integrations were exercised. Finish with the intended user and next validation step.
