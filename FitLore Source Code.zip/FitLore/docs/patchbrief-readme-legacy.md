# PatchBrief

Turn a dependency alert into a cited, review-ready remediation ticket.

PatchBrief complements Dependabot: it joins vendor advisory evidence, migration
considerations, and explicit team policy. It does not scan source code, infer
reachability, certify safety, close alerts, or submit changes automatically.

## Run locally

Requires Python 3.11 or later (tested with Python 3.12).

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.lock.txt
cp .env.example .env
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000. Demo mode requires no API keys and makes no provider
calls. Existing `.env` files must not be overwritten. The frontend uses plain
HTML, CSS, and JavaScript and is served by the Python API; no Node build is needed.

## Full stack

| Layer | Implementation |
|---|---|
| Browser | Responsive review desk, sources, evaluation, connections, alert/policy upload, Markdown/JSON downloads |
| API | FastAPI, Pydantic validation, explicit errors, request limits, optional deployment token |
| RAG | LlamaIndex nodes, Nebius embeddings, Pinecone vector store, local BM25, reciprocal-rank fusion |
| Generation | Nebius through LlamaIndex OpenAILike; optional Fireworks adapter |
| Observability | LangSmith parent retrieval/generation spans, opt-in for live requests |
| Evaluation | pytest checks plus a reproducible 15-case demo evaluation and a browser evaluation runner |
| Deployment | Replit configuration and Dockerfile |

The app is stateless: submitted alerts and policies are held in the browser and
processed per request, not saved to a shared database. Pinecone stores only the
curated public source passages. LangSmith, when enabled, can receive live request
inputs and outputs, including supplied context and policy. Demo tracing is disabled.

## Connect Nebius, Pinecone, and LangSmith

1. Add server secrets from `.env.example`. Use exact chat and embedding model IDs
   available to your Nebius account; do not assume a model is available based on
   a hard-coded example. The Nebius endpoint defaults to
   `https://api.tokenfactory.nebius.com/v1/`.
2. Set `PINECONE_INDEX` and `PINECONE_NAMESPACE`. The starter uses `patchbrief` and
   `patchbrief-v1`. `python -m scripts.ingest` embeds the 12 curated passages,
   creates the configured index if absent, and writes that namespace. This incurs
   embedding/index usage. It refuses an index with the wrong embedding dimension.
3. Wait for Pinecone indexing consistency, then select **Live RAG** in the app.
4. Optionally set `LANGSMITH_API_KEY`, `LANGSMITH_TRACING=true`, and
   `LANGSMITH_PROJECT=patchbrief`. Inspect a real trace to verify delivery.
5. For Fireworks generation set `MODEL_PROVIDER=fireworks`, `FIREWORKS_API_KEY`,
   and `FIREWORKS_MODEL`. Nebius remains the embedding provider.

Restart the server after changing environment settings. Presence of keys is
reported as configured, not verified. A failed live request returns an explicit
error; it never substitutes demo output. Live adapters are implemented and
locally contract-tested; successful real service calls require credentials.

## Inputs and supported scope

- One Dependabot alert JSON object with `dependency.package.name`, npm ecosystem,
  and a matching `security_advisory.cve_id` or `ghsa_id`.
- An exact stable installed version, supplied separately from the deployed lockfile.
  Ranges, prereleases, tags, and unrecognized release families stay unresolved.
- Deployment context and a review question.
- Optional plain-text or Markdown policy. Timing extraction accepts a single
  explicit clause, e.g. `Critical: review within 24 hours`. Conflicting clauses
  or unsupported prose produce no inferred deadline.

The corpus covers only CVE-2025-24010 (Vite), CVE-2025-29927 (Next.js), and
CVE-2025-27152 (axios). It contains 12 editorial summaries from three authoritative
vendor advisories, reviewed on 2026-10-17. It is a bounded historical snapshot,
not a current vulnerability feed. The historical branch fix is not necessarily
a suitable deployment target today. An unsupported alert receives an abstention.

Vite includes concrete upgrade configuration guidance. Next.js and axios include
vendor conditions and workarounds; this corpus does not contain comprehensive
release notes or migration guides. Those are a future corpus expansion.

## Retrieval and generation

`app/corpus.py` records source identity, original publication date, snapshot date,
package, CVE, section, and text. Semantic section boundaries are the chunking
strategy; the deliberately short reviewed passages do not need further splitting.
Stable IDs preserve citation identity across ingestion.

The local path ranks relevant passages with BM25. Live retrieval combines this
with LlamaIndex/Pinecone dense retrieval and reciprocal-rank fusion (constant 60).
Exact package/CVE filters prevent evidence from a different advisory from crossing
into a review. This is rank fusion, not a learned reranker. Every matching passage
is retained in this small corpus to avoid hiding relevant caveats.

Version facts and policy timing use deterministic code. The model generates only
the additional cited considerations. Citation IDs and output schema are validated;
that validation does not establish semantic entailment. Reviewers must inspect
the displayed source text. Model drafts are labeled separately from local summaries.

## Verification

```sh
python -m pytest -q
python -m scripts.evaluate
```

Reports are written to `output/evaluation/`. The browser's Evaluation view runs
15 behavior checks against the demo API. These are not model-faithfulness scores.
For live evaluation, use the same cases in live mode, inspect retrieved passages,
review each model claim against its cited evidence, and record p50/p95 latency and
provider cost. Do not report live metrics before running them.

## Replit

Import this project into a Python Replit app. Install `requirements.lock.txt`,
add keys in Replit Secrets, and run ingestion from the shell. The supplied `.replit`
configuration launches Uvicorn on port 8000 and uses `$PORT` in deployment.
Set `PATCHBRIEF_ACCESS_TOKEN` before sharing a credentialed deployment. Visitors
enter this separate access token in Connections; provider keys never go to the
browser. For production, replace the shared token with user authentication,
rate limits, tenant isolation, and a secret-management policy.

Deployment is not completed merely by providing this configuration. Verify the
actual deployment URL and a live request before recording the final demo.

## Source references

- https://github.com/vitejs/vite/security/advisories/GHSA-vg6x-rcgg-rjx6
- https://github.com/vercel/next.js/security/advisories/GHSA-f82v-jwr5-mffw
- https://github.com/axios/axios/security/advisories/GHSA-jr5f-v2jv-69x6
- https://developers.llamaindex.ai/python/framework-api-reference/embeddings/openai_like/
- https://docs.tokenfactory.nebius.com/quickstart
- https://docs.langchain.com/langsmith/trace-with-langchain

See `docs/submission.md` for the submission draft and `docs/demo-script.md` for
the walkthrough. No actual user secrets belong in source control or submission assets.

### Credit conservation

Cloud use defaults to locked (`PATCHBRIEF_ALLOW_CLOUD=false`); local demo and local evaluations make no provider calls. `LANGSMITH_TRACING=false` keeps remote traces off. Before enabling cloud, verify credit balances, expiry, applicable products, and no paid overage/automatic top-up in provider billing settings. This application cannot verify those account settings or guarantee a dollar ceiling.

When explicitly unlocked, `app/budget.py` reserves attempts before external work: 10 generations, 10 retrievals, and 1 ingestion total. Failed attempts also count. Counters persist in `data/runtime/budget.sqlite3`, shared by processes on this filesystem; they are not daily resets. Preserve this directory across restarts/deployments. Separate installations have separate allowances. Do not delete the ledger to retry failures without reviewing usage. Model/embedding retries are disabled, generation is capped at 700 output tokens, and dense retrieval requests four matches. Pinecone SDK/control-plane traffic and existing storage can incur usage independently of these attempt counts.

The planned ingestion writes only 12 public advisory passages to index `patchbrief`, namespace `patchbrief-v1`. It does not upload private alerts or team policy. No ingestion has been performed as part of configuring these safeguards. Local mode remains explicitly labeled as a curated demo, not live LLM generation.

Portal inspection: in Pinecone, select the same project as your API key, then open index `patchbrief` and namespace `patchbrief-v1`. After ingestion, expect 12 records, including source IDs such as `vite-versions`, with package, CVE and snapshot metadata. Check index metrics and the organization Usage/Billing view separately. In Nebius Token Factory, inspect the balance, Payments, and auto-top-up settings. In LangSmith, enabled traces appear under Tracing Projects → patchbrief; no project traces are expected while tracing is off. LlamaIndex runs locally; Fireworks and Mem0 are unused by the current Nebius configuration. Keep Replit deployment off until its credit/overage terms are verified.
