# PatchBrief — submission draft

## Overview

PatchBrief helps developers prepare remediation reviews for npm vulnerability
alerts from a curated vendor-advisory corpus in a web review desk. It produces
cited change considerations, deterministic version checks, explicit team-policy
timing, missing-evidence questions, and an exportable GitHub-ready ticket.

The differentiation is the handoff from a scanner alert to a reviewable change
plan. Existing scanners remain in place. This project does not claim to be the
first vulnerability assistant or to outperform commercial scanners.

## One-line RAG definition

My RAG app helps developers answer remediation-review questions from 12 reviewed
passages across three vendor advisories, plus a supplied team policy, in a web
application. Live quality targets are 95% supported factual claims and p95 response
latency under 15 seconds, to be measured rather than assumed. The current demo
evaluation reports deterministic behavior separately.

## Corpus and ingestion

The three advisories cover Vite CVE-2025-24010, Next.js CVE-2025-29927, and axios
CVE-2025-27152. All sources are English vendor security advisories published in
2025 and inspected on 2026-10-17. They are manually summarized into semantic
sections with stable IDs, URLs, package/CVE metadata, and dates. These summaries
are not verbatim source excerpts. No private customer data is included.

Two team policies are explicitly fictional fixtures. Users may replace them with
their own text. The policy does not enter the shared Pinecone index.

Ingestion uses LlamaIndex TextNode objects and Nebius embeddings, storing vectors
in a dedicated Pinecone namespace. The script determines embedding dimension
from a real response and checks it against the index. No automatic freshness SLA
is claimed; the snapshot date is visible and new advisories require reviewed
corpus changes plus re-ingestion.

## Retrieval

BM25 handles exact terms and version-related wording. Live mode adds dense
retrieval with exact package/CVE metadata filters and reciprocal-rank fusion.
The live retriever requests up to eight vectors; this corpus has four passages
per advisory. Curated passage boundaries are the chunking strategy. Embedding
model selection remains account-configurable and must be recorded after live setup.

## Grounding and uncertainty

The model may draft considerations using only retrieved passages. Unknown IDs or
invalid schemas fail validation. Exact version checks, advisory identity, and
policy timing remain outside model control. Missing evidence produces an unknown
status. Application exposure remains under investigation without application
analysis. Unsupported alerts are not answered from a different advisory.

Citation validation establishes that a cited source exists, not that it entails
every model claim. A reviewer can inspect the summary and original source.

## Prompts and tools

The generation prompt is in `app/integrations.py` as SYSTEM_PROMPT. It treats
input documents as data, restricts output to cited recommendations, forbids changes
to deterministic facts, and permits an empty answer when evidence is inadequate.
Codex was used for research, implementation, UI development, and test preparation.
The backend uses FastAPI, LlamaIndex, Pinecone, Nebius, optional Fireworks, and
LangSmith. Replit deployment configuration is included.

## Iterations and observations

1. Narrowed a broad vulnerability chatbot into a remediation-ticket workflow.
2. Distinguished documented affected versions from application exploitability.
3. Added an unknown interval for axios where the advisory's affected and patched
   boundaries leave intermediate versions ambiguous.
4. Prevented a Dependabot affected-version range from being treated as an installed version.
5. Added missing-evidence and policy-switch demos, plus strict live-failure behavior.
6. Kept review-time policies separate from promised remediation deadlines.

## Evaluation and limitations

The generated report in `output/evaluation/demo-report.md` contains measured
results for 15 demo behavior cases. The pytest suite covers API validation,
version boundaries, metadata filters, policy ambiguity, unsupported advisories,
access control, request limits, and missing/failed live integrations.

Before submitting, add the configured model IDs, actual live trace URL, live
evaluation results, observed latency, and deployed URL. These are not yet verified.
Do not characterize demo behavior accuracy as live-model faithfulness.

## Submission checklist

- [ ] Configure credentials and verify real Nebius generation and embeddings.
- [ ] Ingest and verify real Pinecone retrieval.
- [ ] Inspect LangSmith trace delivery.
- [ ] Run and document live generation evaluation.
- [ ] Verify Replit deployment and access controls.
- [ ] Record a video no longer than five minutes.
- [ ] Upload code to GitHub or use the permitted archive option.
- [ ] Copy this reviewed draft and evaluation results into the requested Google Doc.
- [ ] Submit the documentation, code link, and video through the assignment form.

The assignment's Builder of the Week cutoff is October 18, 2026, 11:59 p.m.
Pacific (October 19, 1:59 a.m. Central). Later submissions remain possible under
the handout's stated conditions.
