# FitLore — Week 2 RAG submission draft

## Status
Core custom-use-case RAG application implemented and live Nebius/Pinecone connectivity verified. The submission is not complete: the final Google Doc, recorded demo and GitHub link remain outstanding, and a 30-run live comparison is complete, with remaining relevance and citation failures documented. See the page-by-page handout audit at `/static/project-readiness.html`.

## One-liner
FitLore helps people preparing for a new professional situation answer what they can wear, why it matches their brief and what remains uncertain, using personal preferences, wardrobe metadata, event documents, sourced guidance and reflections. Targets: ≥95% supported factual claims and p95 <15 seconds. These are targets, not measured results.

## Data
Fictional sample client and six sample garments; user-supplied personal and wardrobe metadata; four application-authored guidance summaries/policies; uploaded TXT/Markdown/text PDFs; user feedback. Photos stay local and are not embedded or sent to the model. Stored metadata includes source URL, type, revision and update time. Links are not fetched; stock and prices are unverified.

Guidance references include Allison Bornstein (goop, 2023), Alyssa Rudman (The Style Lab, September 2026) and Kate Young (British Vogue, 2017). These inform process, not current trends. Summaries are not expert endorsements or full copyrighted articles. See strategy-evidence-2026-10-17.csv for the research ledger.

## Ingestion and retrieval
PDF page markers are retained in extracted text. No OCR. Whitespace normalisation, 240-word chunks, 40-word overlap, maximum 128 chunks. Content-derived IDs and corpus fingerprints block stale evidence.

Live pipeline: Nebius embeddings through LlamaIndex; Pinecone vector storage with a local embedding cache (or SQLite-only mode); vector and keyword rankings combined with reciprocal-rank fusion (constant 60); top five passages plus explicit current brief and proposed-item context. Both ranked and required context are visible. Personal and agency corpora are isolated. A free Starter index named fitlore-demo was explicitly provisioned for the live test; application routes never provision resources.

## Generation
The prompt in app/studio_rag.py treats source material as untrusted and requires cited facts, separate creative suggestions and missing information. It prohibits invented prices, stock, credentials and actions. Structured JSON is requested with a source-ID enum. Unknown IDs, unsupported claim paraphrases, truncated output or invalid schemas fail closed; factual claims must be exact source excerpts; freshness is rechecked after generation. Entailment still requires evaluation.

Wardrobe composition remains deterministic in both modes: available items with footwear and sleeve filters. Free-text preferences and fit require review. Live RAG reasons over evidence alongside these proposals; rehearsal uses no model.

## Evaluation and iterations
Fifteen questions and rubrics cover factual preferences, source guidance, unknown facts, changed constraints and injection. scripts/evaluate_fitlore.py defaults to 12 lexical smoke checks. Explicit --live runs a bounded selection after gates and indexing, records answers and latency, and emits a claim-review CSV. Faithfulness = supported factual claims / reviewed factual claims; separately assess abstention, relevance and constraint adherence. No live quality score exists yet.

Implemented iterations: personal corpus isolation; honest rehearsal/live labelling; availability and coverage filters; source metadata and staleness; lexical preference normalisation; feedback retrieval; historical evidence retention.

## Spending and privacy
Both PATCHBRIEF_ALLOW_CLOUD and FITLORE_RAG_ALLOW_CLOUD gate calls. Shared persistent allowances: 1 ingestion, 1 hosted upload, 10 retrievals, 10 generations, including failures. One explicitly audited ingestion retry was granted after a sandbox DNS failure; the failed attempt remains recorded. These do not guarantee credit-only billing. LangSmith tracing hooks were removed. No automatic retries, purchases or publishing. Server remains local, without production authentication or multi-tenancy.

## Deliverables
- Implemented: local application, persistence, corpus ingestion, retrieval and guarded generation, tests, example corpus, evaluation runner, architecture and demo script.
- Live connectivity verified on 2026-10-17: Nebius embeddings and generation, 13 vectors in Pinecone, cached indexing and a known-source retrieval probe. Manual response review and a broader quality evaluation remain necessary; this is not a production-quality score.
- Pending final submission: measured results/learnings in the required document, ≤5-minute video and code/submission links.

The custom-use-case handout requirements reviewed earlier are addressed by the personal RAG flow. Agency, CRM and finance concepts are supporting demonstrations rather than the assessed core.

## Live smoke test — 17 October 2026

145 automated tests passed in the expanded release suite. The prepared browser consultation used Nebius embeddings, Pinecone retrieval and Nebius structured JSON generation; it saved in 7,473 ms with 1,871 prompt tokens and 169 completion tokens. All three factual excerpts were manually checked against their cited personal brief. Earlier test answers with over-broad claims were retained as Needs changes. Unknown-shopping and conflicting-instruction tests exposed relevance and redundant-question weaknesses. The prepared result is one successful example, not a representative faithfulness, abstention or latency benchmark. Exact provider billing totals were not yet visible.

The free Pinecone Starter plan was verified; fitlore-demo holds 13 vectors of dimension 4096. Nebius Stop usage when the trial ends was saved and verified. The local ledger records two ingestion attempts (one sandbox DNS failure), eight retrieval attempts, seven generation attempts and one hosted upload. Two retrievals and three generations remain; ingestion and hosted uploads are exhausted. Rebuilding the same snapshot uses cached embeddings and avoids repeat uploads. There is no automatic allowance reset.

## Handout verification — 17 October 2026

Source: `Week 2 Project Handout ( Oct 2026 ).pdf`, all nine pages read. This is the **Week 2 custom-use-case option**, not the separately numbered financial “Project 2” example on pages 5–6. Page 1 explicitly permits an original use case and other frameworks; LlamaIndex is therefore consistent with the handout. LangSmith and LangGraph are not universal requirements.

| Handout item | Finding | Evidence / remaining work |
| --- | --- | --- |
| Corpus → chunk → embed → store → retrieve → cited answers (p1) | Met in the personal live path | 13 chunks; Nebius embeddings; Pinecone; hybrid retrieval; saved cited output. |
| Specific user, question, corpus, surface and metric target (p2) | Met as a target | Personal event styling in the browser, ≥95% supported factual claims and p95 <15s; these are not measured achievements. |
| Framework fields (p2–3) | Documented | Data, cleaning, freshness, chunking/models, retrieval and generation above. Refresh is manual after edits, with no scheduled freshness SLA; stale live answers are blocked until re-indexing. |
| Unknown-answer behavior (p3 guidance) | Implemented; partially validated live | Unknown stock/price identified; unsupported excerpts rejected; appearance-analysis boundary runs locally. Relevance still needs improvement. |
| Fifteen-question evaluation (p5, specific to the policy-Q&A example) | Useful benchmark adopted for this custom app; partial | All 15 authored questions evaluated for local retrieval only. Live generation was not run on the complete set. No broad faithfulness/relevance score. |
| Google Doc with overview, datasets, prompts, iterations, observations (p8) | Draft content exists locally; final Google Doc pending | This file plus `app/studio_rag.py:SYSTEM`, result reports and recording guide provide material. No Google Doc link has been verified. |
| ≤5-minute video including AI coding tools and live result (p8) | Script prepared; recording pending | Explain Codex's role in implementation/debugging; distinguish opening a saved live response from making a fresh provider call. |
| Code/workflow assets on GitHub (p8) | Local source exists; hosted link unverified | Publish a clean source package without `.env`, runtime databases, personal exports or private screenshots. Page 8 specifically requests GitHub despite example pages also mentioning zip. |

The handout deadline is Sunday **18 October 2026, 11:59pm Pacific** (p1). No financial chunking comparison, 20-node GraphRAG, or customer-support resolution metric is required unless selecting those particular example projects.

## Measured offline retrieval audit

`python -m scripts.audit_week2` evaluates the 15 authored questions against an in-memory copy of the current corpus without provider calls or persistent changes. Thirteen queries have expected source groups present in this corpus: 10/13 retrieved every expected group in the top five; mean source-group recall@5 is **84.6%**. The two negative cases are unscored, rather than incorrectly counted as successful abstentions. These are lexical retrieval measures, not live answer quality or faithfulness. See `output/week2-retrieval-audit.json` for per-question results and failure analysis.

## Learnings and honest scope

Exact-excerpt validation reduced unsupported factual paraphrases, but quote matching alone does not establish relevance, source truth or good styling judgment. Live shopping questions still triggered unrelated suggestions; conflicting prompts preserved the budget but asked for already-known wardrobe information. The prompt was tightened, without spending remaining calls on an unreported retest. The 145 software tests and six workflow replays establish defined behavior, not a 95% model quality score. Photos are third-party style references or user uploads; neither is analyzed by the model.

## Completed comparative quality evaluation

The local final report is output/submission/FitLore Week 2 Project Report.docx. See /static/quality-report.html and web/quality-results.json for current results, which supersede earlier pending-evaluation notes above. Thirty live attempts used the same fifteen questions on the same corpus. Accepted answers: 9/15 baseline, 14/15 revised. Strict assistant-reviewed rubric passes: 4/15 and 6/15; mean rubric score 40% and 60%. Revised p95: 20.126 seconds, above target. Matching accepted factual excerpts: 33/33; this does not establish broad faithfulness, relevance or source truth and excludes suggestions.

Thirty reviewed traces were exported to LangSmith under a saved $0 trace-spend cap, base retention and extend_trace_retention=False for rubric feedback. Global tracing remains disabled. Two audited fifteen-question grants preserved earlier usage; ceilings are 40 retrievals and generations, used 38 and 37 respectively. Nebius stop-at-trial-end and Pinecone Starter were rechecked between batches. Exact debits may lag the portal displays. The local report is complete; video, native Google Doc conversion if required by the submission form, and a GitHub link remain.
