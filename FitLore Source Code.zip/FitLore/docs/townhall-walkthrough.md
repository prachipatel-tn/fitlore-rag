# Townhall style story

Open http://127.0.0.1:8000/#demos/townhall or choose Discover → The townhall moment.

The story is one continuous page. It shows real, credited editorial photography, followed by supplied wardrobe facts, two authored styling directions, rehearsal checks, questions, expandable source retrieval and save/start actions. Editorial photography is inspiration, not an exact photo of the black linen skirt or brown wool T-shirt.

## Demo path

- Read the supplied pieces and unknown fit details.
- Compare Quiet conviction (finish, tuck or hem, care-label-safe steaming) with A little more structure (an optional existing layer).
- Work through the physical rehearsal checks.
- Expand the source section to inspect case-specific passages.
- Save the example to Saved looks, or choose Style my own pieces to open a personal brief.

## Personal path

Create my look → save brief → review/add wardrobe pieces → Style these pieces → preview consultation → saved plan → reflection.

My studio groups the brief, styling session and sources. How it works and Connections & evaluation are in the footer. Browser Back/Forward and saved-plan URLs preserve navigation context.

Sample wardrobes and feedback remain separate from personal retrieval. These stories use authored guidance and local keyword retrieval; live AI remains gated. Actual wardrobe photographs must be uploaded by the user; sample editorial photos are not silently assigned to garments.
