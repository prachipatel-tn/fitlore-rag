"""Evaluate the 15 authored questions locally, without network or ledger changes.

This measures expected source-group coverage in lexical top five, NOT live RAG
faithfulness. The runtime corpus is copied into memory and never modified.
"""
import json
import sqlite3
from pathlib import Path
from app import fitlore as f

ROOT = Path(__file__).resolve().parents[1]

def main():
 source = sqlite3.connect(f'file:{ROOT}/data/runtime/fitlore.sqlite3?mode=ro', uri=True)
 memory = sqlite3.connect(':memory:')
 memory.row_factory = sqlite3.Row
 source.backup(memory)
 source.close()
 nodes = f.corpus(memory)
 cases = json.loads((ROOT/'examples/fitlore/evaluation.json').read_text())
 rows = []
 for i, case in enumerate(cases, 1):
  hits = f.lexical(case['question'], nodes, 5)
  retrieved = list(dict.fromkeys(n['document_id'] for n in hits))
  expected = case['expected_sources']
  def matches(node, group):
   return node['kind']=='Feedback' if group=='personal-feedback' else node['document_id'].startswith(group)
  available = [g for g in expected if any(matches(n,g) for n in nodes)]
  found = [g for g in available if any(matches(n,g) for n in hits)]
  score = len(found)/len(available) if available else None
  note = ('Known-source retrieval only; no answer generated.' if available else
          'No expected source in the current corpus; answer abstention is not evaluated by retrieval alone.')
  if score is not None and score < 1:
   note = 'Expected source group missing from lexical top five; wording/synonym or ranking failure. Live hybrid retrieval may differ and is not measured here.'
  rows.append({'id':i, **case, 'retrieved_document_ids':retrieved,
               'expected_groups_available':available, 'expected_groups_found':found,
               'source_group_recall_at_5':score, 'analysis':note})
 scored = [r for r in rows if r['source_group_recall_at_5'] is not None]
 report = {'date':'2026-10-17', 'mode':'Offline lexical top-five evaluation; no model, embeddings or hosted retrieval calls',
           'questions':len(rows), 'scorable_known_source_queries':len(scored),
           'mean_source_group_recall_at_5':sum(r['source_group_recall_at_5'] for r in scored)/len(scored),
           'full_expected_group_coverage':sum(r['source_group_recall_at_5']==1 for r in scored),
           'corpus_chunks':len(nodes), 'corpus_signature':f.rag.signature(nodes),
           'faithfulness':None, 'live_answer_relevance':None,
           'limits':'Source groups are rubric categories, not all relevant documents. Negative/absent-source cases require answer review. Not a full live 15-question evaluation.',
           'results':rows}
 for path in [ROOT/'output/week2-retrieval-audit.json', ROOT/'web/week2-retrieval-audit.json']:
  path.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))

if __name__ == '__main__':
 main()
