"""Reproducible behavioral and retrieval evaluation; no live-model quality claims."""
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from app.corpus import CASES, POLICIES, examples
from app.main import AnalysisRequest
from app.engine import analyze
from langsmith import tracing_context

CASES_TO_TEST = [
    ("Vite affected", "vite", "5.4.11", "in_affected_range", "5.4.12", "standard", []),
    ("Vite patched", "vite", "5.4.12", "outside_documented_range", None, "standard", []),
    ("Vite 6", "vite", "6.0.8", "in_affected_range", "6.0.9", "standard", []),
    ("Vite 4", "vite", "4.5.5", "in_affected_range", "4.5.6", "standard", []),
    ("Next 14", "next", "14.2.24", "in_affected_range", "14.2.25", "standard", []),
    ("Next patched", "next", "14.2.25", "outside_documented_range", None, "standard", []),
    ("Next 15", "next", "15.2.2", "in_affected_range", "15.2.3", "standard", []),
    ("Next 11", "next", "11.1.4", "in_affected_range", None, "standard", []),
    ("Axios affected", "axios", "1.7.9", "in_affected_range", "1.8.2", "standard", []),
    ("Axios gap", "axios", "1.8.1", "unknown", None, "standard", []),
    ("Axios patched", "axios", "1.8.2", "outside_documented_range", None, "standard", []),
    ("Reject range", "vite", "^5.4.11", "unknown", None, "standard", []),
    ("Reject prerelease", "vite", "5.4.12-beta.1", "unknown", None, "standard", []),
    ("Missing evidence", "vite", "5.4.11", "unknown", None, "standard", ["vite-versions"]),
    ("Policy switch", "vite", "5.4.11", "in_affected_range", "5.4.12", "accelerated", []),
]


def main():
    samples = {e["id"]: e for e in examples()}
    results = []
    with tracing_context(enabled=False):
        for name, package, version, expected, fix, policy, excluded in CASES_TO_TEST:
            e = samples[package]
            r = analyze(AnalysisRequest(alert=e["alert"], installed_version=version,
                question=e["question"], context=e["context"], policy_text=POLICIES[policy]["text"], exclude_sources=excluded))
            ids = {d["id"] for d in r["evidence"]}
            citation_valid = all(set(x["source_ids"]) <= ids for x in r["recommendations"])
            passed = r["version_status"] == expected and r["documented_patch"] == fix and citation_valid
            if name == "Policy switch":
                passed = passed and r["policy_clause"] == "Moderate: review within 48 hours"
            results.append({"case": name, "expected": expected, "actual": r["version_status"],
                "pass": passed, "valid_citation_ids": citation_valid, "elapsed_ms": r["elapsed_ms"]})
    report = {"generated_at": datetime.now(timezone.utc).isoformat(), "mode": "demo", "cases": results,
              "passed": sum(r["pass"] for r in results), "total": len(results),
              "limitations": "Curated deterministic behavior tests. Citation-ID validity does not establish semantic faithfulness. Live Nebius/Pinecone and model quality require separate credentialed tests."}
    output = Path("output/evaluation")
    output.mkdir(parents=True, exist_ok=True)
    (output / "demo-results.json").write_text(json.dumps(report, indent=2))
    lines = ["# PatchBrief demo evaluation", "", f"Measured: {report['generated_at']}", "", f"Behavior checks: {report['passed']}/{report['total']} passed.", "", report["limitations"], "", "| Case | Expected | Actual | Pass |", "|---|---|---|---|"]
    lines += [f"| {r['case']} | {r['expected']} | {r['actual']} | {r['pass']} |" for r in results]
    (output / "demo-report.md").write_text("\n".join(lines))
    print(f"{report['passed']}/{report['total']} checks passed. Reports in {output}.")
    if report["passed"] != report["total"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
