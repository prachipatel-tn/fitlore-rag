"""Local by default. --live still requires both gates and a current index."""
import argparse
import csv
import json
import math
import time
from pathlib import Path
from dotenv import load_dotenv

def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--live',action='store_true')
 parser.add_argument('--limit',type=int,default=5)
 parser.add_argument('--output',default='output/fitlore-evaluation.json')
 args=parser.parse_args()
 if not 1<=args.limit<=10:parser.error('--limit must be 1–10')
 load_dotenv()
 from app import fitlore as f
 if args.live:f.rag.gate()
 if not args.live:report=f.evaluate()
 else:
  cases=json.loads(Path('examples/fitlore/evaluation.json').read_text())
  ordered=[cases[i] for i in [0,1,7,8,9,3,4,5,6,2]][:args.limit]
  results=[]
  for case in ordered:
   start=time.perf_counter()
   try:
    answer=f.consult(f.Consultation(question=case['question'],mode='live'))
    results.append({**case,'answer':answer,'latency_ms':round((time.perf_counter()-start)*1000),'error':None,'human_faithfulness':None})
   except Exception as e:
    results.append({**case,'error':getattr(e,'detail','Live operation failed'),'latency_ms':round((time.perf_counter()-start)*1000)})
    break
  latencies=sorted(r['latency_ms'] for r in results if not r.get('error'))
  report={'mode':'Live RAG evaluation; human claim review required','results':results,'completed':len(latencies),'p95_ms':latencies[math.ceil(.95*len(latencies))-1] if latencies else None,'faithfulness':None,'note':'Small sample; p95 is descriptive. This local report contains personal evidence.'}
 path=Path(args.output);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(report,indent=2))
 if args.live:
  with path.with_suffix('.review.csv').open('w',newline='') as out:
   writer=csv.writer(out);writer.writerow(['question','claim','source_ids','supported_yes_no','reviewer_notes'])
   for row in report['results']:
    for claim in row.get('answer',{}).get('claims',[]):writer.writerow([row['question'],claim['text'],';'.join(claim['source_ids']),'',''])
 print(f'Saved {path}. Faithfulness requires manual claim review.')

if __name__=='__main__':main()
