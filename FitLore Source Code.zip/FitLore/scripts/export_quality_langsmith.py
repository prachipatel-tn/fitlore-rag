"""Explicit, bounded export of reviewed evaluation runs as base traces.

No background tracing, hosted evaluator, dataset, annotation queue or automation
is used. Explicit feedback sets extend_trace_retention=False; no paid judge runs.
The capped workspace must be verified in the portal before invoking this script.
"""
import argparse
import json
import os
import sqlite3
import uuid
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

ROOT=Path(__file__).resolve().parents[1]
PROJECT='fitlore-week2-quality-2026-10-17'
WORKSPACE=None

def main():
 global WORKSPACE
 p=argparse.ArgumentParser()
 p.add_argument('--verified-zero-spend-cap',action='store_true',required=True)
 args=p.parse_args()
 load_dotenv(ROOT/'.env')
 WORKSPACE=os.environ['LANGSMITH_WORKSPACE_ID']
 from langsmith import Client
 from urllib3.util.retry import Retry
 client=Client(api_key=os.environ['LANGSMITH_API_KEY'],api_url='https://api.smith.langchain.com',retry_config=Retry(total=0),auto_batch_tracing=False,timeout_ms=15000,workspace_id=WORKSPACE)
 prior=list(client.list_projects(limit=1))
 if not prior or str(prior[0].tenant_id)!=WORKSPACE:
  raise SystemExit('Key does not match the workspace whose $0 cap was verified')
 reports=[json.loads((ROOT/'output'/p).read_text()) for p in ['quality-live-15.json','quality-revised-15.json']]
 if any(len(r['results'])!=15 or any(x.get('review') is None for x in r['results']) for r in reports):
  raise SystemExit('Finish all fifteen cases and local rubric review before export')
 projects=list(client.list_projects(name=PROJECT,limit=1))
 project=projects[0] if projects else client.create_project(PROJECT,description='Baseline and revised fifteen-question Week 2 RAG benchmark. Assistant rubric review, no paid judge. Explicit feedback disables retention extension. Base retention and $0 trace spending cap verified.')
 if str(project.tenant_id)!=WORKSPACE:raise SystemExit('Project workspace mismatch')
 log=sqlite3.connect(ROOT/'data/runtime/langsmith-export.sqlite3')
 log.execute('CREATE TABLE IF NOT EXISTS exports(case_id INTEGER PRIMARY KEY CHECK(case_id BETWEEN 1 AND 30), run_id TEXT UNIQUE, status TEXT)')
 for revision,report in enumerate(reports):
  for row in report['results']:
   export_row(client,log,project,row,report,revision)
 result={'project_name':PROJECT,'project_id':str(project.id),'workspace_id':WORKSPACE,'url':f'https://smith.langchain.com/','sent':log.execute("SELECT COUNT(*) FROM exports WHERE status='sent'").fetchone()[0], 'retention':'Workspace default base; feedback extend_trace_retention=False','trace_spend_cap_usd':0}
 (ROOT/'output/langsmith-export-summary.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))

def export_row(client,log,project,row,report,revision):
  export_id=row['case']+revision*15
  existing=log.execute('SELECT run_id,status FROM exports WHERE case_id=?',(export_id,)).fetchone()
  if existing and existing[1]!='schema-rejected':return
  run_id=uuid.UUID(existing[0]) if existing else uuid.uuid4()
  if not existing:log.execute('INSERT INTO exports VALUES(?,?,?)',(export_id,str(run_id),'reserved'))
  log.commit()  # Reserve before network; uncertain requests are never retried.
  answer=row.get('answer',{})
  output={k:answer.get(k,[]) for k in ['claims','suggestions','missing_information']}
  output['local_rubric_review']=row['review']
  client.create_run(name=f'FitLore {"baseline" if revision==0 else "revised"} question {row["case"]:02d}',inputs={'question':row['question'],'rubric':row['rubric']},run_type='chain',project_name=PROJECT,id=run_id,trace_id=run_id,dotted_order=datetime.fromisoformat(row['started']).strftime('%Y%m%dT%H%M%S%fZ')+str(run_id),start_time=datetime.fromisoformat(row['started']),end_time=datetime.fromisoformat(row['ended']),outputs=output,error=row.get('error'),extra={'metadata':{'corpus_signature':report['corpus_signature'],'source_document_ids':list(dict.fromkeys(n['document_id'] for n in answer.get('evidence',[]))),'evaluation':'assistant rubric review; not independent human or paid judge','case':row['case'],'revision':'baseline' if revision==0 else 'revised'}},tags=['week2','base-trace','quality-evaluation','baseline' if revision==0 else 'revised'])
  for key in ['rubric_score','answer_relevance','constraint_adherence']:
   if row['review'].get(key) is not None:
    client.create_feedback(run_id=run_id,trace_id=run_id,session_id=project.id,start_time=datetime.fromisoformat(row['started']),key=key,score=row['review'][key],comment=row['review']['notes'],extend_trace_retention=False,stop_after_attempt=1)
  log.execute('UPDATE exports SET status=? WHERE case_id=?',('sent',export_id))
  log.commit()
  print(json.dumps({'case':row['case'],'trace_sent':str(run_id)}),flush=True)

if __name__=='__main__':main()
