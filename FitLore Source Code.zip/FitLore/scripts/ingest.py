"""Run from project root: python -m scripts.ingest.

Creates the named Pinecone index if absent; writes only the named namespace.
Requires Nebius embeddings and Pinecone credentials. Does not ingest user uploads.
"""
import os
import time
from dotenv import load_dotenv
load_dotenv()

from app.corpus import DOCUMENTS
from app.retrieval import embedding_model, vector_store
from app.budget import reserve


def main():
    reserve("ingestion")
    from pinecone import Pinecone, ServerlessSpec
    from llama_index.core.schema import TextNode
    pc = Pinecone(api_key=os.environ["PINECONE_API_KEY"])
    embed = embedding_model()
    vectors = embed.get_text_embedding_batch([d["title"] + "\n" + d["text"] for d in DOCUMENTS])
    dimension = len(vectors[0])
    name = os.environ["PINECONE_INDEX"]
    if name not in pc.list_indexes().names():
        pc.create_index(name=name, dimension=dimension, metric="cosine",
            spec=ServerlessSpec(cloud=os.getenv("PINECONE_CLOUD", "aws"), region=os.getenv("PINECONE_REGION", "us-east-1")))
    for _ in range(30):
        desc = pc.describe_index(name)
        if desc.status["ready"]:
            break
        time.sleep(2)
    else:
        raise RuntimeError("Index not ready. Retry ingestion later.")
    if desc.dimension != dimension:
        raise ValueError("Embedding dimension differs from index. Choose a new index; do not overwrite the existing one.")
    nodes = [TextNode(id_=d["id"], text=d["title"] + "\n" + d["text"], embedding=v,
        metadata={"source_id": d["id"], "package": d["package"], "cve": d["cve"], "snapshot": d["snapshot"]}) for d, v in zip(DOCUMENTS, vectors)]
    ids = vector_store().add(nodes)
    print(f"Indexed {len(ids)} passages, dimension {dimension}, namespace {os.getenv('PINECONE_NAMESPACE', 'patchbrief-v1')}. Allow time for Pinecone consistency before live queries.")


if __name__ == "__main__":
    main()
