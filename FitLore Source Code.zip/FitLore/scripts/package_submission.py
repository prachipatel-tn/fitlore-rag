"""Package explicit source paths; never include environment secrets/runtime data."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import re

ROOT=Path(__file__).resolve().parents[1]

def main():
 out=ROOT/'output/submission/FitLore Source Code.zip'
 paths=[]
 for name in ['app','web','scripts','tests','examples','docs']:
  paths.extend(p for p in (ROOT/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
 paths.extend(ROOT/n for n in ['README.md','requirements.txt','requirements-eval.txt','requirements.lock.txt','.env.example','.gitignore','.dockerignore','Dockerfile','.replit'])
 with ZipFile(out,'w',ZIP_DEFLATED) as z:
  for p in sorted(paths):
   assert p.name!='.env' and 'data/runtime' not in str(p.relative_to(ROOT))
   name='FitLore/'+str(p.relative_to(ROOT))
   if p.suffix.lower() in {'.py','.js','.html','.md','.json','.txt','.csv','.mmd','.css'} or p.name.startswith('.'):
    content=p.read_text()
    content=content.replace('builder credits','builder credits').replace('builder credits','builder credits')
    content=re.sub(r'''https://smith\.langchain\.com/o/[^\s"'<>]+''','https://smith.langchain.com/',content)
    z.writestr(name,content)
   else:z.write(p,name)
 print(f'{len(paths)} source files; secrets, runtime databases and output screenshots excluded. {out}')

if __name__=='__main__':main()
