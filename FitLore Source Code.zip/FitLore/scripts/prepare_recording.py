"""Prepare additive, explicitly fictional recording fixtures without cloud calls.

Existing matching demos are reused. Personal sources and live index are untouched.
"""
import json
import os
from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app


def main():
 os.environ['PATCHBRIEF_ALLOW_CLOUD']='false'
 os.environ['FITLORE_RAG_ALLOW_CLOUD']='false'
 headers={}
 if os.getenv('PATCHBRIEF_ACCESS_TOKEN'):headers['Authorization']='Bearer '+os.environ['PATCHBRIEF_ACCESS_TOKEN']
 out={'notice':'Fictional recording fixtures. No suppliers contacted, bookings made or cloud calls performed.','projects':[]}
 with TestClient(app,headers=headers) as c:
  def call(method,path,body=None,role='producer'):
   r=c.request(method,path,json=body,headers={'X-Demo-Role':role})
   if r.status_code>=400:raise RuntimeError(f'{method} {path}: {r.status_code}')
   return r.json()
  existing=call('GET','/api/fitlore/projects')['projects']
  templates=call('GET','/api/fitlore/projects/templates')['templates']
  for t in templates:
   title='Recording demo · '+t['title']
   prior=next((p for p in existing if p['title']==title),None)
   if prior:p=call('GET','/api/fitlore/projects/'+prior['id'])
   else:
    p=call('POST','/api/fitlore/projects',{'template_id':t['id'],'title':title,'event_date':'2026-11-01'})
    for r in list(p['resources']):
     p=call('PUT',f"/api/fitlore/projects/{p['id']}/resources/{r['id']}",{'revision':p['revision'],'status':'confirmed','fee_cents':r['fee_cents'],'ready_offset':r['ready_offset'],'note':'Fictional recording rehearsal confirmation only. No real supplier contacted.'})
    for task in list(p['tasks'][:3]):
     p=call('PUT',f"/api/fitlore/projects/{p['id']}/tasks/{task['id']}",{'revision':p['revision'],'status':'done','note':'Prepared fictional decision for the recording walkthrough.'})
   out['projects'].append(p)
  studio=call('GET','/api/studio/state',role='consultant')
  if not studio['looks']:
   call('POST','/api/studio/looks/generate',role='consultant')
   studio=call('GET','/api/studio/state',role='consultant')
  draft=next((l for l in studio['looks'] if l['status']=='draft' and not l.get('stale')),None)
  if draft:call('POST',f"/api/studio/looks/{draft['id']}/decision",{'status':'review'},role='consultant')
  if not any(e['title']=='Recording demo tailoring estimate' for e in studio['expenses']):
   call('POST','/api/studio/expenses',{'title':'Recording demo tailoring estimate','amount_cents':12000},role='finance')
  out['personal_live_consultation']='0ba243bfbe47463dad9dc45385aa9be9'
  # Exercise the repaired boundary through the real application route, with cloud locked.
  result=call('POST','/api/fitlore/consult',{'question':'Can you determine my personality, body measurements and colour season from my wardrobe photos?','mode':'live'})
  assert result['mode']=='boundary'
  out['photo_boundary_consultation']=result['id']
 Path('output').mkdir(exist_ok=True)
 Path('output/recording-fixtures.json').write_text(json.dumps(out,indent=2))
 print(json.dumps({'prepared_projects':len(out['projects']),'project_titles':[p['title'] for p in out['projects']],'cloud_calls':0,'personal_sources_unchanged':True},indent=2))


if __name__=='__main__':main()
