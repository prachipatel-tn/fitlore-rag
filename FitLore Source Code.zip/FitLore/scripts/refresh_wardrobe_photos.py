"""Download explicitly sourced demonstration reference photos; no AI/API calls."""
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
ASSETS = [
 ('reference-navy-blazer.jpg', 'https://windsor.de/medias/sys_master/images/images/hcb/he3/10057499115550/10057499115550.jpg', 'windsor.', 'https://windsor.de/int/en/women/blazers-waistcoats/cotton-stretch-blazer-in-navy/p/30046143-10001376-415', 'Navy tailored blazer'),
 ('reference-ivory-shirt.jpg', 'https://www.careofcarl.at/bilder/artiklar/zoom/29431711r_1.jpg?m=1753704280', 'Care of Carl / NN07', 'https://www.careofcarl.at/de/nn07-colby-shirt-ivory', 'Ivory long-sleeve shirt'),
 ('reference-charcoal-trousers.jpg', 'https://assets.digitalcontent.marksandspencer.app/images/w_1000,q_auto,f_jpg/SD_01_T59_5977_T0_X_EC_90/Straight-Leg-Trousers', 'Marks & Spencer', 'https://www.marksandspencer.com/straight-leg-trousers/p/clp60275924', 'Charcoal straight-leg trousers'),
 ('reference-black-loafers.jpg', 'https://www.tresmode.com/cdn/shop/files/263-HAK-BLACK-_1_1500x.jpg?v=1778224490', 'Tresmode', 'https://www.tresmode.com/products/tresmode-hak-black-mens-leather-penny-loafers', 'Black leather penny loafer'),
 ('reference-blue-scarf.jpg', 'https://sophieguyot.com/13951-large_default/square-90-silk-twill-plain.jpg', 'Sophie Guyot', 'https://sophieguyot.com/en/silk/1335-square-90-silk-twill-plain.html', 'Blue silk square scarf'),
 ('reference-white-sneakers.jpg', 'https://aldoshoes.co.uk/cdn/shop/files/finespec_white_110-002-043_main_sq_nt_1600x1600_9a39e91e-d33d-4cd1-a509-ac2a0e7ba7bc.jpg?v=1771862159&width=1000', 'ALDO', 'https://aldoshoes.co.uk/products/finespec-white-13451152', 'White low-top sneaker'),
]

def download(asset):
 name, url, owner, original, description = asset
 req = Request(url, headers={'User-Agent': 'Mozilla/5.0', 'Accept': 'image/jpeg,image/*;q=0.8'})
 with urlopen(req, timeout=40) as response:
  body = response.read(8_000_000)
 from PIL import Image
 from io import BytesIO
 im = Image.open(BytesIO(body))
 im.verify()
 if not body.startswith(b'\xff\xd8'):
  raise ValueError(f'{name}: expected JPEG, received {body[:12]!r}')
 (ROOT/'web/images'/name).write_bytes(body)
 return {'file': name, 'source': url, 'original': original, 'rights_holder': owner,
         'description': description, 'use': 'Third-party product reference for educational demo; not the user\'s exact item, an endorsement, a stock/price claim, or a grant of redistribution rights. Rights remain with the respective owner.'}

if __name__ == '__main__':
 with ThreadPoolExecutor(max_workers=6) as pool:
  results = list(pool.map(download, ASSETS))
 path = ROOT/'web/images/credits.json'
 credits = [x for x in json.loads(path.read_text()) if not x['file'].startswith('reference-')]
 path.write_text(json.dumps(credits+results, indent=2)+'\n')
 print(json.dumps([{'file': x['file'], 'source': x['rights_holder']} for x in results], indent=2))
