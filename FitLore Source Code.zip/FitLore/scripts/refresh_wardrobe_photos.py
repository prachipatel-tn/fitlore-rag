"""Restore licensed site photos from the reviewed manifest; no AI/API credits used."""
import json
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from pathlib import Path
from urllib.request import Request, urlopen
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]

def download(asset):
    assert asset['license_url'] == 'https://www.pexels.com/license/'
    assert asset['source'].startswith('https://images.pexels.com/photos/')
    assert asset['original'].startswith('https://www.pexels.com/photo/')
    name = asset['file']
    assert Path(name).name == name and name.endswith('.jpg')
    request = Request(asset['source'], headers={'User-Agent': 'Mozilla/5.0'})
    with urlopen(request, timeout=45) as response:
        body = response.read(8_000_000)
    image = Image.open(BytesIO(body))
    image.verify()
    if not body.startswith(b'\xff\xd8'):
        raise ValueError(f'{name}: expected JPEG')
    return name, body

if __name__ == '__main__':
    assets = json.loads((ROOT/'web/images/credits.json').read_text())
    with ThreadPoolExecutor(max_workers=6) as pool:
        results = list(pool.map(download, assets))
    # Validate all downloads before replacing any local file.
    for name, body in results:
        (ROOT/'web/images'/name).write_bytes(body)
    print(f'Restored {len(results)} free Pexels photographs; existing credits preserved.')
