"""Apply the explicitly recorded assistant rubric review and publish a summary.

Scores below are review judgments after reading the outputs, not an automatic
faithfulness judge. Never infer response quality merely from status or citations.
"""
import json
import math
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
BASELINE=[
 (.5,.5,0,'Budget correctly quoted; unrelated outfit advice recommends sneakers despite the recorded Flats category.'),
 (.5,.5,0,'Loafers match the recorded preference; an unsolicited sneaker alternative conflicts with Flats.'),
 (0,0,None,'Exact-excerpt validation rejected the answer; no usable response reached the user.'),
 (1,1,1,'Grounded sitting, walking and movement rehearsal; does not guarantee comfort.'),
 (1,1,1,'Uses reuse preference and process guidance to start with owned pieces.'),
 (0,0,1,'Does not infer competence, but fails to explain the appearance boundary and substitutes an outfit.'),
 (0,0,None,'Quote validation blocked the practical and aspirational preference answer.'),
 (0,0,None,'Unknown awards query was blocked rather than returning a useful abstention.'),
 (.5,.5,1,'Stock and size are explicitly unknown; repeated wardrobe availability and unrelated styling can confuse the distinction.'),
 (1,1,1,'Refuses to invent an endorsement; no unsupported endorsement is produced.'),
 (0,0,None,'Feedback answer was blocked by quote validation.'),
 (0,0,None,'Sleeve-constrained outfit answer was blocked by quote validation.'),
 (.5,.5,.5,'Offers the requested sneaker alternative, but conflates Sneakers with Flats and does not clearly mark the change hypothetical.'),
 (0,0,None,'Colour-season query was blocked instead of giving a clear unknown response.'),
 (1,1,1,'Quotes the supplied goals and preferences; styling interpretation is labelled as a suggestion.'),
]
REVISED=[
 (.5,.5,1,'Correct budget excerpts; still adds unrequested outfit advice and unrelated body-measurement questions.'),
 (1,1,1,'Identifies black loafers and their recorded availability; does not offer sneakers against the Flats setting.'),
 (0,0,1,'Returns presentation logistics and an outfit without identifying the saved occasion; acceptance does not establish relevance.'),
 (1,1,1,'Provides the requested physical comfort rehearsal, with uncertainty about actual fit and temperature.'),
 (1,1,1,'Uses the current reuse preference and owned pieces instead of requiring a whole new wardrobe.'),
 (.5,.5,1,'States the correct no-inference policy, but adds unrelated styling and fit questions.'),
 (0,0,None,'A claim/source mismatch is still rejected despite the excerpt enum; no usable answer returned.'),
 (1,1,1,'Clearly states that awards information is absent, without inventing achievements.'),
 (.5,.5,1,'Explicitly says stock and size are unknown; wardrobe Available=True and extra styling remain distracting.'),
 (1,1,1,'Refuses the request to invent an endorsement.'),
 (0,0,1,'Does not cite the existing feedback record; substitutes generic rehearsal guidance and asks what was disliked.'),
 (.5,.5,1,'Proposes available sleeved pieces and flats, but missing-information text makes an unsupported claim that no other footwear is available.'),
 (.5,.5,1,'Provides a sneaker alternative without changing the profile, but does not clearly label the switch hypothetical.'),
 (.5,.5,0,'Does not invent a colour season, but gives an unverified diagnostic prerequisite and unrelated sneaker advice against Flats.'),
 (1,1,1,'Quotes goals, blue-accent and sleeve preferences and labels outfit interpretation as a suggestion.'),
]

def summarize(path,reviews):
 report=json.loads(path.read_text())
 assert len(report['results'])==15 and len(reviews)==15
 claim_count=supported=0
 for row,(score,relevance,constraints,notes) in zip(report['results'],reviews):
  row['review']={'rubric_score':score,'answer_relevance':relevance,'constraint_adherence':constraints,'notes':notes,'reviewer':'Codex assistant rubric review; not independent human or paid judge'}
  answer=row.get('answer',{})
  lookup={n['id']:' '.join(n['text'].split()) for n in answer.get('evidence',[])}
  for claim in answer.get('claims',[]):
   claim_count+=1
   supported+=any(' '.join(claim['text'].split()) in lookup.get(i,'') for i in claim['source_ids'])
 path.write_text(json.dumps(report,indent=2)+'\n')
 times=sorted(r['elapsed_ms'] for r in report['results'])
 return report,{'accepted':sum(r['status']==200 for r in report['results']),'blocked':sum(r['status']!=200 for r in report['results']),'strict_passes':sum(r['review']['rubric_score']==1 for r in report['results']),'mean_rubric_score':sum(r['review']['rubric_score'] for r in report['results'])/15,'claims':claim_count,'supported_claims':supported,'p95_ms':times[math.ceil(.95*len(times))-1],'tokens':sum(r.get('answer',{}).get('provider_usage',{}).get('total_tokens',0) for r in report['results'])}

def main():
 before,b=summarize(ROOT/'output/quality-live-15.json',BASELINE)
 after,r=summarize(ROOT/'output/quality-revised-15.json',REVISED)
 suite=ET.parse(ROOT/'output/full-test-results.xml').getroot().find('testsuite')
 summary={'date':'2026-10-17','protocol':'Same 15 pre-authored questions on an unchanged 13-chunk corpus; one attempt per question per version; 30 live attempts, no automatic retries, no paid evaluator','review_method':'Assistant reads full responses against authored rubrics. 1=complete rubric, 0.5=useful but incomplete, 0=blocked or unhelpful. This is not independent human evaluation. Excerpt support is a separate programmatic check of accepted factual claims only.','baseline':b,'revised':r,'software_tests':int(suite.attrib['tests']),'remaining_findings':['Answer relevance is still uneven: some simple questions produce unrelated styling or fail to identify the requested fact.','Exact source-excerpt matching does not validate claims in suggestions, source truth, physical comfort, aesthetic judgment or real retailer inventory.','Remaining blocked responses and partial rubric results are retained. A small test set cannot establish production faithfulness or latency.'],'cases':[{'case':x['case'],'question':x['question'],'rubric':x['rubric'],'baseline_status':x['status'],'revised_status':y['status'],'baseline_score':x['review']['rubric_score'],'revised_score':y['review']['rubric_score'],'baseline_notes':x['review']['notes'],'revised_notes':y['review']['notes']} for x,y in zip(before['results'],after['results'])]}
 (ROOT/'web/quality-results.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps({k:v for k,v in summary.items() if k in ['baseline','revised','software_tests']},indent=2))

if __name__=='__main__':main()
