"""At most five sequential live calls per operator-run batch, never automatic retries.

Requires existing gates, a current index and an explicit audited evaluation grant.
Review provider usage between batches. This does not enable application-wide tracing.
"""
import argparse
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from dotenv import load_dotenv

ROOT=Path(__file__).resolve().parents[1]
REPORT=ROOT/'output/quality-live-15.json'

def main():
 p=argparse.ArgumentParser()
 p.add_argument('--start',type=int,required=True)
 p.add_argument('--count',type=int,default=5)
 p.add_argument('--revision',choices=['baseline','revised'],default='baseline')
 args=p.parse_args()
 if not 1<=args.start<=15 or not 1<=args.count<=5 or args.start+args.count>16:
  p.error('Select 1–5 cases within the fifteen-question set')
 load_dotenv(ROOT/'.env')
 os.environ['LANGSMITH_TRACING']='false'
 os.environ['LANGCHAIN_TRACING_V2']='false'
 from app import fitlore as f
 from app.studio import db
 f.rag.gate()
 with db() as c:
  status=f.pipeline_status(c,f.corpus(c))
 if not status['indexed'] or status['stale']:raise SystemExit('A current index is required; no automatic re-indexing')
 cases=json.loads((ROOT/'examples/fitlore/evaluation.json').read_text())
 path=REPORT if args.revision=='baseline' else ROOT/'output/quality-revised-15.json'
 report=json.loads(path.read_text()) if path.exists() else {'date':datetime.now(timezone.utc).isoformat(), 'revision':args.revision, 'protocol':'15 pre-authored questions, one attempt each, live Nebius/Pinecone, no paid judge, no retries', 'corpus_signature':None, 'results':[]}
 with db() as c:sig=f.rag.signature(f.corpus(c))
 if report['corpus_signature'] not in (None,sig):raise SystemExit('Corpus changed between batches')
 report['corpus_signature']=sig
 done={x['case'] for x in report['results']}
 for number in range(args.start,args.start+args.count):
  if number in done:raise SystemExit(f'Case {number} already attempted; refusing duplicate spend')
  case=cases[number-1]
  row={'case':number,**case,'started':datetime.now(timezone.utc).isoformat(),'review':None}
  start=time.perf_counter()
  try:
   answer=f.consult(f.Consultation(question=case['question'],mode='live'))
   row.update(status=200,answer=answer)
  except Exception as e:
   row.update(status=getattr(e,'status_code',500),error=getattr(e,'detail','Provider call failed; inspect locally without printing credentials'))
  row['elapsed_ms']=round((time.perf_counter()-start)*1000)
  row['ended']=datetime.now(timezone.utc).isoformat()
  report['results'].append(row)
  path.write_text(json.dumps(report,indent=2)+'\n')
  print(json.dumps({'case':number,'status':row['status'],'elapsed_ms':row['elapsed_ms']}),flush=True)
  if row['status'] in (403,502,500):
   print('Batch stopped on quota/provider failure. No retry.',flush=True)
   break

if __name__=='__main__':main()
