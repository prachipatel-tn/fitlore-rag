import pytest
from app.budget import BudgetBlocked, reserve
from app.budget import current_limits, grant_ingestion_retry, grant_quality_evaluation, grant_quality_retest
import sqlite3


def test_default_lock_blocks_before_database_creation(monkeypatch, tmp_path):
    path = tmp_path / "budget.db"
    monkeypatch.delenv("PATCHBRIEF_ALLOW_CLOUD", raising=False)
    monkeypatch.setenv("PATCHBRIEF_BUDGET_DB", str(path))
    with pytest.raises(BudgetBlocked, match="locked"):
        reserve("ingestion")
    assert not path.exists()


def test_attempt_allowance_persists_across_connections(monkeypatch, tmp_path):
    monkeypatch.setenv("PATCHBRIEF_ALLOW_CLOUD", "true")
    monkeypatch.setenv("PATCHBRIEF_BUDGET_DB", str(tmp_path / "budget.db"))
    reserve("ingestion")
    with pytest.raises(BudgetBlocked, match="exhausted"):
        reserve("ingestion")
    for _ in range(10):
        reserve("generation")
    with pytest.raises(BudgetBlocked, match="exhausted"):
        reserve("generation")


def test_operator_retry_is_audited_bounded_and_preserves_failed_attempt(monkeypatch, tmp_path):
    path = tmp_path / 'budget.db'
    monkeypatch.setenv('PATCHBRIEF_ALLOW_CLOUD', 'true')
    monkeypatch.setenv('PATCHBRIEF_BUDGET_DB', str(path))
    with pytest.raises(BudgetBlocked):
        grant_ingestion_retry('Network restriction prevented the first request')
    reserve('ingestion')
    with pytest.raises(BudgetBlocked):
        reserve('ingestion')
    grant_ingestion_retry('Network restriction prevented the first request')
    assert current_limits() == {'ingestion': 2, 'retrieval': 10, 'generation': 10, 'vector_write': 1}
    with pytest.raises(BudgetBlocked):
        grant_ingestion_retry('Do not grant another attempt')
    reserve('ingestion')
    with pytest.raises(BudgetBlocked):
        reserve('ingestion')
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT attempts FROM usage WHERE kind='ingestion'").fetchone()[0] == 2
        assert db.execute('SELECT reason FROM ingestion_retry_grant').fetchone()[0].startswith('Network restriction')
    monkeypatch.setenv('PATCHBRIEF_ALLOW_CLOUD', 'false')
    with pytest.raises(BudgetBlocked, match='locked'):
        grant_ingestion_retry('Cloud lock must still be respected')


def test_quality_evaluation_grant_is_single_bounded_and_preserves_usage(monkeypatch, tmp_path):
    path=tmp_path/'budget.db'
    monkeypatch.setenv('PATCHBRIEF_BUDGET_DB',str(path))
    monkeypatch.setenv('PATCHBRIEF_ALLOW_CLOUD','true')
    reserve('retrieval')
    grant_quality_evaluation('User requested 15-question evaluation; credit-only billing verified')
    assert current_limits()['retrieval']==25
    assert current_limits()['generation']==25
    assert current_limits()['ingestion']==1
    assert current_limits()['vector_write']==1
    with pytest.raises(BudgetBlocked):
        grant_quality_evaluation('A second grant must be rejected without resetting attempts')
    with sqlite3.connect(path) as c:
        assert c.execute("SELECT attempts FROM usage WHERE kind='retrieval'").fetchone()[0]==1
    for _ in range(24):reserve('retrieval')
    with pytest.raises(BudgetBlocked):reserve('retrieval')
    monkeypatch.setenv('PATCHBRIEF_ALLOW_CLOUD','false')
    with pytest.raises(BudgetBlocked):grant_quality_evaluation('Must not grant anything while the cloud gate is closed')


def test_quality_retest_requires_prior_grant_and_cannot_repeat(monkeypatch,tmp_path):
    monkeypatch.setenv('PATCHBRIEF_BUDGET_DB',str(tmp_path/'budget.db'))
    monkeypatch.setenv('PATCHBRIEF_ALLOW_CLOUD','true')
    reserve('generation')
    with pytest.raises(BudgetBlocked):grant_quality_retest('A comparison must not precede the initial evaluation')
    grant_quality_evaluation('User requested evaluation and provider safeguards verified')
    grant_quality_retest('Quote schema corrected after six rejections; credit-only billing verified again')
    assert current_limits()['retrieval']==40
    assert current_limits()['generation']==40
    assert current_limits()['vector_write']==1
    with pytest.raises(BudgetBlocked):grant_quality_retest('A second comparison is never granted automatically or manually')
