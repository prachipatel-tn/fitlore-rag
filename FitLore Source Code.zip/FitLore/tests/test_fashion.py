from fastapi.testclient import TestClient
from app.main import app
client=TestClient(app)
def test_fashion_preferences_and_provenance(monkeypatch):
 monkeypatch.delenv('PATCHBRIEF_ACCESS_TOKEN',raising=False)
 catalog=client.get('/api/fashion/catalog').json()
 assert len(catalog['looks'])==6
 assert catalog['cloud_enabled'] is False
 response=client.post('/api/fashion/style',json={'look_id':'1','occasion':'Campus','coverage':'More coverage','footwear':'Sneakers','intensity':'Statement'})
 assert response.status_code==200
 data=response.json()
 assert data['pieces']==['Long-sleeve cotton overshirt','Wide-leg trousers','Low-top sneakers','Statement shoulder bag']
 assert all(s in {x['id'] for x in catalog['sources']} for s in data['source_ids'])
def test_fashion_rejects_invalid_inputs(monkeypatch):
 monkeypatch.delenv('PATCHBRIEF_ACCESS_TOKEN',raising=False)
 assert client.post('/api/fashion/style',json={'look_id':'missing'}).status_code==404
 assert client.post('/api/fashion/style',json={'look_id':'1','occasion':'unknown'}).status_code==422

def test_consultation_respects_brief_without_inventing_credentials(monkeypatch):
 monkeypatch.delenv('PATCHBRIEF_ACCESS_TOKEN',raising=False)
 r=client.post('/api/fashion/consult',json={'name':'Alex','role':'Designer','direction':'expressive','formality':'Relaxed','budget':'Use what I own'})
 assert r.status_code==200
 kit=r.json()
 assert kit['title']=='Expressive original'
 assert kit['outfit'][0]=='Soft overshirt'
 assert 'Alex' in kit['introduction'] and '[your actual focus]' in kit['introduction']
 assert 'no purchase is required' in kit['budget_note']
 assert 'Local consultation templates' in kit['provenance']['status']
 assert client.post('/api/fashion/consult',json={'direction':'invented'}).status_code==422
