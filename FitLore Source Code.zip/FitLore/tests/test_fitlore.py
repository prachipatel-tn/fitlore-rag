import base64
import io
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app import fitlore as f

@pytest.fixture
def client(tmp_path,monkeypatch):
 monkeypatch.setenv('FITLORE_VECTOR_STORE','sqlite')
 monkeypatch.setenv('FITLORE_STUDIO_DB',str(tmp_path/'personal.db'))
 monkeypatch.setenv('PATCHBRIEF_BUDGET_DB',str(tmp_path/'budget.db'))
 monkeypatch.setenv('PATCHBRIEF_ALLOW_CLOUD','false')
 monkeypatch.setenv('FITLORE_RAG_ALLOW_CLOUD','false')
 monkeypatch.setenv('NEBIUS_EMBEDDING_MODEL','test-embedding')
 monkeypatch.delenv('PATCHBRIEF_ACCESS_TOKEN',raising=False)
 return TestClient(app)

def test_personal_corpus_isolated_from_studio(client):
 client.get('/api/studio/state')
 s=client.get('/api/fitlore/state').json()
 assert len(s['garments'])==6 and len(s['documents'])==4
 with f.db() as c:
  nodes=f.corpus(c)
 assert not any(n['document_id'] in {'brief','event','brand','process'} for n in nodes)

def test_rehearsal_never_calls_provider_and_saves_evidence(client,monkeypatch):
 monkeypatch.setattr(f.rag,'embed',lambda *a:pytest.fail('No provider in rehearsal'))
 monkeypatch.setattr(f.rag,'generate',lambda *a:pytest.fail('No provider in rehearsal'))
 r=client.post('/api/fitlore/consult',json={'question':'Help with my presentation','mode':'demo'})
 assert r.status_code==200,r.text
 d=r.json();assert d['mode']=='demo' and d['looks']
 assert 'Black leather loafers' in d['looks'][0]['pieces']
 assert 'White low-top sneakers' not in d['looks'][0]['pieces']
 assert all(i in {e['id'] for e in d['evidence']} for cl in d['claims'] for i in cl['source_ids'])
 assert len(client.get('/api/fitlore/state').json()['consultations'])==1

def test_live_locked_before_provider_calls(client,monkeypatch):
 monkeypatch.setattr(f.rag,'embed',lambda *a:pytest.fail('Locked'))
 monkeypatch.setattr(f.rag,'generate',lambda *a:pytest.fail('Locked'))
 assert client.post('/api/fitlore/index').status_code==403
 assert client.post('/api/fitlore/consult',json={'question':'Help with presentation','mode':'live'}).status_code==403


def test_unsupported_photo_assessment_explains_boundary_without_paid_calls(client,monkeypatch):
 monkeypatch.setattr(f.rag,'embed',lambda *a:pytest.fail('No embeddings for unsupported photo assessment'))
 monkeypatch.setattr(f.rag,'generate',lambda *a:pytest.fail('No model for unsupported photo assessment'))
 r=client.post('/api/fitlore/consult',json={'question':'Determine my personality and body measurements from my wardrobe photos','mode':'live'})
 assert r.status_code==200
 assert r.json()['mode']=='boundary' and r.json()['claims']==[]
 assert 'No photo analysis' in r.json()['notice']

def test_profile_and_feedback_invalidate_saved_plan(client):
 r=client.post('/api/fitlore/consult',json={'question':'Help with presentation'}).json()
 p=client.get('/api/fitlore/state').json()['profile'];p['footwear']='Sneakers'
 assert client.put('/api/fitlore/profile',json=p).status_code==200
 s=client.get('/api/fitlore/state').json();assert s['consultations'][0]['stale']
 assert client.post('/api/fitlore/consultations/'+r['id']+'/feedback',json={'outcome':'Needs changes','text':'Prefer sneakers for the walk.'}).status_code==200
 with f.db() as c:assert any('Prefer sneakers' in n['text'] for n in f.corpus(c))
 new=client.post('/api/fitlore/consult',json={'question':'Help with presentation'}).json()
 assert 'White low-top sneakers' in new['looks'][0]['pieces']

def test_unavailable_and_sleeve_constraints(client):
 s=client.get('/api/fitlore/state').json()
 for g in s['garments']:
  if g['category'] in {'Top','Layer'}:
   g['sleeves']=False
   client.put('/api/fitlore/wardrobe/'+g['id'],json=g)
 r=client.post('/api/fitlore/consult',json={'question':'Help with presentation'}).json()
 assert r['looks']==[] and any('No complete' in x for x in r['missing_information'])
 assert client.delete('/api/fitlore/wardrobe/personal-profile').status_code==404

def test_document_import_delete_and_invalid_upload(client):
 data=base64.b64encode(b'The presentation is outdoors. Bring a warm layer.').decode()
 r=client.post('/api/fitlore/documents/upload',json={'filename':'brief.txt','content':data})
 assert r.status_code==200,r.text
 id=r.json()['id']
 assert any(e['document_id']==id for e in client.get('/api/fitlore/evidence?q=outdoors').json()['evidence'])
 assert client.delete('/api/fitlore/documents/'+id).status_code==200
 assert client.delete('/api/fitlore/documents/guide-method').status_code==403
 assert client.post('/api/fitlore/documents/upload',json={'filename':'bad.pdf','content':'invalid'}).status_code==422
 assert client.post('/api/fitlore/documents',json={'title':'Bad URL','text':'A source note','url':'javascript:alert(1)'}).status_code==422

def test_blank_pdf_does_not_create_source(client):
 from pypdf import PdfWriter
 w=PdfWriter();w.add_blank_page(width=100,height=100);buf=io.BytesIO();w.write(buf)
 r=client.post('/api/fitlore/documents/upload',json={'filename':'scan.pdf','content':base64.b64encode(buf.getvalue()).decode()})
 assert r.status_code==422

def test_text_pdf_is_extracted_with_page_marker(client):
 from pypdf import PdfWriter
 from pypdf.generic import DictionaryObject, NameObject, DecodedStreamObject
 w=PdfWriter();p=w.add_blank_page(width=300,height=300)
 font=DictionaryObject({NameObject('/Type'):NameObject('/Font'),NameObject('/Subtype'):NameObject('/Type1'),NameObject('/BaseFont'):NameObject('/Helvetica')})
 p[NameObject('/Resources')]=DictionaryObject({NameObject('/Font'):DictionaryObject({NameObject('/F1'):font})})
 stream=DecodedStreamObject();stream.set_data(b'BT /F1 12 Tf 10 100 Td (Outdoor event requires a warm layer.) Tj ET')
 p[NameObject('/Contents')]=stream
 buf=io.BytesIO();w.write(buf)
 r=client.post('/api/fitlore/documents/upload',json={'filename':'event.pdf','content':base64.b64encode(buf.getvalue()).decode()})
 assert r.status_code==200,r.text
 assert '[Page 1]' in r.json()['text'] and 'warm layer' in r.json()['text']

def test_corpus_overflow_rolls_back_document(client):
 client.get('/api/fitlore/state')
 text=' '.join('word'+str(i) for i in range(3400))
 for _ in range(8):
  r=client.post('/api/fitlore/documents',json={'title':'Long source','text':text})
  if r.status_code!=200:break
 assert r.status_code==422
 assert client.get('/api/fitlore/state').status_code==200

def test_live_pipeline_with_fakes_cache_and_staleness(client,monkeypatch):
 monkeypatch.setattr(f.rag,'gate',lambda:None)
 monkeypatch.setattr(f,'reserve',lambda kind:None)
 monkeypatch.setattr(f.rag,'embed',lambda texts:[[1.0,float('budget' in t.lower())] for t in texts])
 monkeypatch.setattr(f.rag,'generate',lambda q,e:{'claims':[{'text':e[0]['text'],'source_ids':[e[0]['id']]}],'suggestions':[],'missing_information':[]})
 assert client.post('/api/fitlore/index').status_code==200
 assert client.post('/api/fitlore/index').json()['cached']
 assert client.post('/api/fitlore/consult',json={'question':'What is my budget?','mode':'live'}).status_code==200
 client.post('/api/fitlore/documents',json={'title':'Event update','text':'The event is now outdoors.'})
 monkeypatch.setattr(f.rag,'embed',lambda *a:pytest.fail('Stale index called provider'))
 assert client.post('/api/fitlore/consult',json={'question':'What is my budget?','mode':'live'}).status_code==409

def test_invalid_generated_citations_do_not_save(client,monkeypatch):
 monkeypatch.setattr(f.rag,'gate',lambda:None)
 monkeypatch.setattr(f,'live_evidence',lambda q,n:n[:2])
 monkeypatch.setattr(f.rag,'generate',lambda q,e:{'claims':[{'text':'Wrong','source_ids':['unknown']}],'suggestions':[],'missing_information':[]})
 assert client.post('/api/fitlore/consult',json={'question':'What is my budget?','mode':'live'}).status_code==409
 assert client.get('/api/fitlore/state').json()['consultations']==[]

def test_local_evaluation_and_export_are_honest(client):
 r=client.post('/api/fitlore/evaluate').json()
 assert r['total']==12 and r['passed']==12,r
 assert r['faithfulness'] is None and not r['live_generation_evaluated']
 out=client.get('/api/fitlore/export').json()
 assert out['format']=='fitlore-workspace-v1'
 assert 'api_key' not in str(out).lower()

def test_personal_page_and_put_limit(client):
 assert 'Your next chapter' in client.get('/').text
 assert client.put('/api/fitlore/profile',content=b'x'*128001).status_code==413

def test_built_in_cases_rehearse_without_provider_or_personal_mutations(client,monkeypatch):
 monkeypatch.setattr(f.rag,'embed',lambda *a:pytest.fail('Demo called embeddings'))
 monkeypatch.setattr(f.rag,'generate',lambda *a:pytest.fail('Demo called generation'))
 before=client.get('/api/fitlore/state').json()
 with f.db() as c:signature=f.rag.signature(f.corpus(c))
 cases=client.get('/api/fitlore/demos').json()['cases']
 assert {c['id'] for c in cases}=={'townhall','creator','conference'}
 for case in cases:
  r=client.post('/api/fitlore/demos/'+case['id']+'/rehearse').json()
  assert r['mode']=='demo' and r['demo_case_id']==case['id']
  assert all(id in {n['id'] for n in r['evidence']} for claim in r['claims'] for id in claim['source_ids'])
  assert all(n['document_id'].startswith(('demo-'+case['id'],'guide-')) for n in r['evidence'])
 after=client.get('/api/fitlore/state').json()
 assert after['profile']==before['profile'] and after['garments']==before['garments']
 assert after['documents']==before['documents']
 with f.db() as c:assert signature==f.rag.signature(f.corpus(c))
 assert not any(s['stale'] for s in after['consultations'])

def test_townhall_does_not_claim_optional_items_owned_or_leak_feedback(client):
 r=client.post('/api/fitlore/demos/townhall/rehearse').json()
 assert [g['name'] for g in r['walkthrough']['garments']]==['Black linen skirt','Brown wool T-shirt']
 assert r['looks']==[]  # No complete wardrobe look is fabricated from two items.
 assert any('shoes' in q for q in r['missing_information'])
 assert client.post('/api/fitlore/consultations/'+r['id']+'/feedback',json={'outcome':'Would try','text':'DEMO ONLY: liked the styling.'}).status_code==200
 with f.db() as c:assert not any('DEMO ONLY' in n['text'] for n in f.corpus(c))
 assert client.get('/api/fitlore/state').json()['feedback'][0]['demo_case_id']=='townhall'

def test_case_evidence_search_is_scoped(client):
 r=client.get('/api/fitlore/demos/townhall/evidence?q=black%20linen%20skirt').json()
 assert any(n['document_id'].startswith('demo-townhall') for n in r['evidence'])
 assert client.get('/api/fitlore/demos/no-such-case/evidence').status_code==404
 assert client.post('/api/fitlore/demos/no-such-case/rehearse').status_code==404
