import json
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app import fitlore as f
from app import personal_vectors as h


def test_host_validation_prevents_key_transmission_to_unexpected_target(monkeypatch):
 monkeypatch.setenv('PINECONE_INDEX','fitlore-demo')
 calls=[]
 def fake(method,url,body=None):
  calls.append(url)
  return {'dimension':2,'metric':'cosine','status':{'ready':True},'host':'evil.example'}
 monkeypatch.setattr(h,'request',fake)
 with pytest.raises(ValueError,match='host'):h.target(2)
 assert calls==['https://api.pinecone.io/indexes/fitlore-demo']


def test_namespace_changes_with_model_revision_and_prefix(monkeypatch):
 monkeypatch.setenv('FITLORE_PINECONE_NAMESPACE','personal')
 assert h.namespace('a','model')!=h.namespace('b','model')
 assert h.namespace('a','model')!=h.namespace('a','other')
 monkeypatch.setenv('FITLORE_PINECONE_NAMESPACE','other')
 assert h.namespace('a','model').startswith('other-')


def test_missing_and_unknown_remote_results_fail_closed(monkeypatch):
 monkeypatch.setattr(h,'target',lambda d:'https://example.pinecone.io')
 for matches in [[],[{'id':'outside'}],[{'id':'known'},{'id':'known'}]]:
  monkeypatch.setattr(h,'request',lambda *a,**kw:{'matches':matches})
  with pytest.raises(ValueError):h.ranked_ids([1,0],[{'id':'known'}],'ns')


def test_cached_local_vectors_sync_once_then_use_remote_ranking(tmp_path,monkeypatch):
 monkeypatch.setenv('FITLORE_STUDIO_DB',str(tmp_path/'personal.db'))
 monkeypatch.setenv('PATCHBRIEF_BUDGET_DB',str(tmp_path/'budget.db'))
 monkeypatch.setenv('FITLORE_VECTOR_STORE','sqlite')
 monkeypatch.setenv('NEBIUS_EMBEDDING_MODEL','fixture-model')
 monkeypatch.setenv('PINECONE_INDEX','fitlore-demo')
 monkeypatch.delenv('PATCHBRIEF_ACCESS_TOKEN',raising=False)
 monkeypatch.setattr(f.rag,'gate',lambda:None)
 monkeypatch.setattr(f,'reserve',lambda kind:None)
 monkeypatch.setattr(f.rag,'embed',lambda texts:[[1.0,0.5] for _ in texts])
 client=TestClient(app)
 assert client.post('/api/fitlore/index').status_code==200
 uploaded=[];queried=[]
 monkeypatch.setattr(h,'upload',lambda nodes,vectors,sig,model:uploaded.append((nodes,vectors)) or h.namespace(sig,model))
 monkeypatch.setenv('FITLORE_VECTOR_STORE','pinecone')
 assert not client.get('/api/fitlore/state').json()['pipeline']['indexed']
 monkeypatch.setattr(f.rag,'embed',lambda *a:pytest.fail('Cached vectors must not be re-embedded'))
 assert client.post('/api/fitlore/index').status_code==200
 assert client.post('/api/fitlore/index').json()['cached']
 assert len(uploaded)==1
 monkeypatch.setattr(f.rag,'embed',lambda texts:[[1.0,0.5] for _ in texts])
 def ranked(vector,nodes,ns):
  queried.append(ns);return [n['id'] for n in nodes[::-1]]
 monkeypatch.setattr(h,'ranked_ids',ranked)
 monkeypatch.setattr(f.rag,'generate',lambda q,e:{'claims':[],'suggestions':[],'missing_information':['Fit requires checking.']})
 assert client.post('/api/fitlore/consult',json={'question':'What should I wear?','mode':'live'}).status_code==200
 assert len(queried)==1
 monkeypatch.setenv('PINECONE_INDEX','different-index')
 assert client.get('/api/fitlore/state').json()['pipeline']['stale']
 monkeypatch.setattr(f.rag,'embed',lambda *a:pytest.fail('Stale hosted manifest must stop before embedding'))
 assert client.post('/api/fitlore/consult',json={'question':'What should I wear?','mode':'live'}).status_code==409


def test_upload_sends_no_source_text_and_checks_acknowledgement(monkeypatch):
 calls=[]
 monkeypatch.setattr(h,'target',lambda d:'https://example.pinecone.io')
 monkeypatch.setattr(h,'reserve',lambda kind:calls.append(kind))
 def request(method,url,body):
  assert body['vectors'][0]['metadata']=={'source_id':'known'}
  assert 'private source text' not in json.dumps(body)
  return {'upsertedCount':0}
 monkeypatch.setattr(h,'request',request)
 with pytest.raises(ValueError,match='acknowledge'):
  h.upload([{'id':'known','text':'private source text'}],[[1,0]],'sig','model')
 assert calls==['vector_write']
