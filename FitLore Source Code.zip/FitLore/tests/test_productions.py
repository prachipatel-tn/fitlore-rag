import pytest
from fastapi.testclient import TestClient
from app.main import app
from app import studio_rag
from app.project_templates import ROLE_LABELS


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv('FITLORE_STUDIO_DB', str(tmp_path / 'projects.db'))
    monkeypatch.setenv('PATCHBRIEF_ALLOW_CLOUD', 'false')
    monkeypatch.setenv('FITLORE_RAG_ALLOW_CLOUD', 'false')
    monkeypatch.delenv('PATCHBRIEF_ACCESS_TOKEN', raising=False)
    monkeypatch.setattr(studio_rag, 'embed', lambda *args: pytest.fail('No embeddings in a project rehearsal'))
    monkeypatch.setattr(studio_rag, 'generate', lambda *args: pytest.fail('No generation in a project rehearsal'))
    return TestClient(app)


def create(client, template='creator-collaboration'):
    r = client.post('/api/fitlore/projects', json={'template_id': template, 'event_date': '2026-11-01'})
    assert r.status_code == 200, r.text
    return r.json()


def complete(client, p, id, actor='producer'):
    return client.put(f"/api/fitlore/projects/{p['id']}/tasks/{id}", json={'revision': p['revision'], 'status': 'done', 'note': 'Recorded during the local rehearsal.'}, headers={'X-Demo-Role': actor})


def confirm(client, p, id, **changes):
    resource = next(r for r in p['resources'] if r['id'] == id)
    data = {k: resource[k] for k in ['status', 'fee_cents', 'ready_offset', 'note']}
    data.update(revision=p['revision'], status='confirmed', note='User-recorded fixture confirmation.')
    data.update(changes)
    r = client.put(f"/api/fitlore/projects/{p['id']}/resources/{id}", json=data)
    assert r.status_code == 200, r.text
    return r.json()


def task(p, id):
    return next(t for t in p['tasks'] if t['id'] == id)


def test_six_workflows_documented_and_all_requested_roles_represented(client):
    templates = client.get('/api/fitlore/projects/templates').json()['templates']
    assert len(templates) == 6
    assert {role for t in templates for role in t['roles']} == set(ROLE_LABELS)
    assert all(len(t['references']) >= 2 and t['workflow'] for t in templates)
    assert all(ref['url'].startswith('https://') and ref['checked'] == '2026-10-17' for t in templates for ref in t['references'])


@pytest.mark.parametrize('name', ['personal-occasion', 'creator-collaboration', 'image-refresh', 'boutique-shoot', 'designer-dressing', 'brand-dinner'])
def test_every_workflow_can_be_rehearsed_and_exported(client, name):
    p = create(client, name)
    for resource in p['resources']:
        p = confirm(client, p, resource['id'])
    for t in p['tasks']:
        r = complete(client, p, t['id'])
        assert r.status_code == 200, r.text
        p = r.json()
    assert p['summary']['done'] == len(p['tasks'])
    assert p['summary']['needs_review'] == 0
    assert not p['cloud_calls']
    out = client.get(f"/api/fitlore/projects/{p['id']}/export").json()
    assert out['format'] == 'fitlore-project-v1'
    assert out['tasks'] and len(client.get('/api/fitlore/projects').json()['projects']) == 1


def test_confirmation_and_dependencies_gate_completion(client):
    p = create(client)
    assert complete(client, p, 'selection').status_code == 409
    p = complete(client, p, 'terms').json()
    assert complete(client, p, 'selection').status_code == 409
    p = confirm(client, p, 'jacket')
    p = confirm(client, p, 'top')
    p = complete(client, p, 'selection').json()
    assert task(p, 'selection')['effective_status'] == 'done'


def test_changed_resource_invalidates_all_dependent_completed_decisions(client):
    p = create(client)
    p = complete(client, p, 'terms').json()
    p = confirm(client, p, 'jacket')
    p = confirm(client, p, 'top')
    p = complete(client, p, 'selection').json()
    p = complete(client, p, 'fitting').json()
    p = confirm(client, p, 'jacket', status='unavailable', note='Designer recalled the jacket.')
    assert task(p, 'terms')['effective_status'] == 'done'
    assert task(p, 'selection')['effective_status'] == 'needs_review'
    assert task(p, 'fitting')['effective_status'] == 'needs_review'
    assert 'unavailable' in ' '.join(task(p, 'selection')['blockers'])


def test_late_delivery_and_budget_have_visible_actionable_blockers(client):
    p = create(client)
    p = complete(client, p, 'terms').json()
    p = confirm(client, p, 'top')
    p = confirm(client, p, 'jacket', ready_offset=0, fee_cents=90000)
    blockers = ' '.join(task(p, 'selection')['blockers'])
    assert 'ready after' in blockers and 'budget' in blockers
    assert complete(client, p, 'selection').status_code == 409


def test_stale_writes_and_wrong_role_rejected(client):
    p = create(client)
    assert complete(client, p, 'terms', 'photographer').status_code == 403
    new = complete(client, p, 'terms', 'brand').json()
    assert complete(client, p, 'terms', 'brand').status_code == 409
    assert client.get(f"/api/fitlore/projects/{new['id']}?view=venue").status_code == 400
    own = client.get(f"/api/fitlore/projects/{new['id']}?view=creator").json()
    assert own['tasks'] and all(t['owner'] == 'creator' for t in own['tasks'])
    assert 'not authenticated' in own['notice']


def test_optional_alterations_can_be_skipped_without_inventing_a_booking(client):
    p = create(client, 'personal-occasion')
    p = confirm(client, p, 'tailor', status='not_needed', note='No alterations chosen by the client.')
    assert p['summary']['estimate_cents'] == 0
    r = client.put(f"/api/fitlore/projects/{p['id']}/resources/skirt", json={'revision': p['revision'], 'status': 'not_needed', 'fee_cents': 0, 'ready_offset': -14, 'note': 'Try to skip a required piece.'})
    assert r.status_code == 422


def test_sources_are_scoped_and_new_evidence_invalidates_completion(client):
    p = create(client)
    other = create(client, 'brand-dinner')
    p = complete(client, p, 'terms').json()
    r = client.post(f"/api/fitlore/projects/{p['id']}/documents", json={'revision': p['revision'], 'title': 'Updated agreement', 'text': 'AMBERPAPAYA the creator requests sleeves in every look.', 'url': 'https://example.org/brief'})
    assert r.status_code == 200, r.text
    p = r.json()
    assert task(p, 'terms')['effective_status'] == 'needs_review'
    ev = client.get(f"/api/fitlore/projects/{p['id']}/evidence?q=AMBERPAPAYA").json()
    assert ev['evidence'] and all(n['document_id'].startswith(p['id']) for n in ev['evidence'])
    assert client.get(f"/api/fitlore/projects/{other['id']}/evidence?q=AMBERPAPAYA").json()['evidence'] == []
    assert 'no AI generation' in ev['mode']


def test_project_rehearsal_does_not_mutate_personal_wardrobe(client):
    before = client.get('/api/fitlore/state').json()
    p = create(client)
    confirm(client, p, 'jacket')
    after = client.get('/api/fitlore/state').json()
    assert before['profile'] == after['profile'] and before['garments'] == after['garments']
    assert before['documents'] == after['documents']


def test_brief_date_change_invalidates_done_tasks_and_old_due_dates(client):
    p = create(client)
    p = complete(client, p, 'terms').json()
    data = {k: p[k] for k in ['revision', 'title', 'brief', 'event_date', 'budget_cents']}
    data['event_date'] = '2026-11-10'
    r = client.put(f"/api/fitlore/projects/{p['id']}/brief", json=data)
    assert r.status_code == 200, r.text
    p = r.json()
    assert task(p, 'terms')['effective_status'] == 'needs_review'
    assert task(p, 'terms')['due_date'] == '2026-11-03'


def test_unknown_project_invalid_date_and_unsafe_source(client):
    assert client.get('/api/fitlore/projects/missing').status_code == 404
    assert client.post('/api/fitlore/projects', json={'template_id': 'nope', 'event_date': '2026-11-01'}).status_code == 404
    assert client.post('/api/fitlore/projects', json={'template_id': 'personal-occasion', 'event_date': '9999-12-31'}).status_code == 422
    p = create(client)
    assert client.post(f"/api/fitlore/projects/{p['id']}/documents", json={'revision': p['revision'], 'title': 'Unsafe', 'text': 'A valid source note.', 'url': 'javascript:alert(1)'}).status_code == 422


def test_custom_resource_and_handoff_are_linked_and_scoped(client):
    p = create(client, 'boutique-shoot')
    other = create(client, 'brand-dinner')
    r = client.post(f"/api/fitlore/projects/{p['id']}/resources", json={'revision': p['revision'], 'title': 'Backup studio', 'provider': 'Fictional studio team', 'owner': 'venue', 'kind': 'Venue', 'fee_cents': 1000, 'ready_offset': -5, 'note': 'Awaiting access confirmation.'})
    assert r.status_code == 200, r.text
    p = r.json()
    new = p['resources'][-1]
    assert new['status'] == 'requested'
    r = client.post(f"/api/fitlore/projects/{p['id']}/tasks", json={'revision': p['revision'], 'title': 'Confirm backup access', 'owner': 'venue', 'day_offset': -4, 'depends_on': [], 'resource_ids': [new['id']]})
    assert r.status_code == 200, r.text
    p = r.json()
    assert p['tasks'][-1]['effective_status'] == 'blocked'
    p = confirm(client, p, new['id'])
    assert p['tasks'][-1]['effective_status'] == 'todo'
    assert complete(client, p, p['tasks'][-1]['id'], 'venue').status_code == 200
    bad = client.post(f"/api/fitlore/projects/{other['id']}/tasks", json={'revision': other['revision'], 'title': 'Invalid dependency', 'owner': 'venue', 'day_offset': 0, 'resource_ids': [new['id']]})
    assert bad.status_code == 422


def test_supplier_name_can_be_recorded_and_new_inputs_require_review(client):
    p = create(client)
    p = complete(client, p, 'terms').json()
    p = confirm(client, p, 'jacket', provider='Fictional designer showroom', title='Alternative designer jacket')
    assert p['resources'][0]['provider'] == 'Fictional designer showroom'
    assert p['resources'][0]['title'] == 'Alternative designer jacket'
    evidence = client.get(f"/api/fitlore/projects/{p['id']}/evidence?q=showroom").json()['evidence']
    assert any('Fictional designer showroom' in n['text'] for n in evidence)


def test_source_capacity_rejection_keeps_saved_project_intact(client):
    p = create(client)
    text = ' '.join('evidence'+str(i) for i in range(1000))
    for i in range(30):
        r = client.post(f"/api/fitlore/projects/{p['id']}/documents", json={'revision': p['revision'], 'title': f'Long source {i}', 'text': text})
        if r.status_code != 200:
            break
        p = r.json()
    assert r.status_code == 422, r.text
    current = client.get(f"/api/fitlore/projects/{p['id']}").json()
    assert current['revision'] == p['revision']
    assert len(current['documents']) == len(p['documents'])
    assert client.get(f"/api/fitlore/projects/{p['id']}/evidence?q=jacket").status_code == 200


def test_workflow_team_can_expand_without_inviting_a_real_vendor(client):
    p = create(client)
    r = client.post(f"/api/fitlore/projects/{p['id']}/roles", json={'revision': p['revision'], 'role': 'caterer'})
    assert r.status_code == 200, r.text
    p = r.json()
    assert 'caterer' in p['roles'] and 'not authenticated' in p['notice']
    assert client.get(f"/api/fitlore/projects/{p['id']}?view=caterer").status_code == 200
    assert client.post(f"/api/fitlore/projects/{p['id']}/roles", json={'revision': p['revision'], 'role': 'invalid'}).status_code == 422
