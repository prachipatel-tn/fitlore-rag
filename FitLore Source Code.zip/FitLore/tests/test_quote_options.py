from app.studio_rag import quote_options


def test_schema_excerpts_remain_exact_bounded_and_preserve_decimal_values():
    text='Budget ceiling: USD 100.00. Footwear: Flats. '+('A lengthy source phrase with useful context '*30)
    source=' '.join(text.split())
    choices=quote_options([{'text':text},{'text':text}])
    assert 'Budget ceiling: USD 100.00.' in choices
    assert len(choices)==len(set(choices))
    assert all(c in source and len(c)<=300 and len(c.split())<=35 for c in choices)
