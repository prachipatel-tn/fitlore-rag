"""Recording release contracts: complete role coverage and wardrobe constraints."""
import itertools
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app import studio_rag


@pytest.fixture
def workspace(tmp_path,monkeypatch):
 monkeypatch.setenv('FITLORE_STUDIO_DB',str(tmp_path/'release.db'))
 monkeypatch.setenv('PATCHBRIEF_BUDGET_DB',str(tmp_path/'budget.db'))
 monkeypatch.setenv('FITLORE_VECTOR_STORE','sqlite')
 monkeypatch.delenv('PATCHBRIEF_ACCESS_TOKEN',raising=False)
 monkeypatch.setattr(studio_rag,'embed',lambda *a:pytest.fail('Local scenarios must not call embeddings'))
 monkeypatch.setattr(studio_rag,'generate',lambda *a:pytest.fail('Local scenarios must not call generation'))
 return TestClient(app)


@pytest.mark.parametrize('footwear,coverage,shoes_available,sleeves',list(itertools.product(['Any','Flats','Sneakers','Heels'],['Any','Sleeves'],[True,False],[True,False])))
def test_wardrobe_scenarios_obey_client_constraints(workspace,footwear,coverage,shoes_available,sleeves):
 s=workspace.get('/api/fitlore/state').json()
 p=s['profile'];p.update(footwear=footwear,coverage=coverage)
 assert workspace.put('/api/fitlore/profile',json=p).status_code==200
 for g in s['garments']:
  if g['category']=='Shoes':g['available']=shoes_available
  if g['category'] in {'Top','Layer'}:g['sleeves']=sleeves
  assert workspace.put('/api/fitlore/wardrobe/'+g['id'],json=g).status_code==200
 r=workspace.post('/api/fitlore/consult',json={'question':'Build a look for my presentation using my owned pieces','mode':'demo'})
 assert r.status_code==200
 current={g['id']:g for g in workspace.get('/api/fitlore/state').json()['garments']}
 for look in r.json()['looks']:
  items=[current[id] for id in look['item_ids']]
  assert all(g['available'] for g in items)
  assert any(g['category']=='Shoes' and (footwear=='Any' or g['footwear']==footwear) for g in items)
  assert coverage=='Any' or any(g['sleeves'] for g in items)
  assert look['additional_cost_cents']==0
 if not shoes_available or (coverage=='Sleeves' and not sleeves) or footwear=='Heels':
  assert not r.json()['looks']
  assert any('No complete' in note for note in r.json()['missing_information'])


@pytest.mark.parametrize('template',['personal-occasion','creator-collaboration','image-refresh','boutique-shoot','designer-dressing','brand-dinner'])
def test_each_workflow_role_view_and_reopened_project(workspace,template):
 p=workspace.post('/api/fitlore/projects',json={'template_id':template,'event_date':'2026-11-01'}).json()
 for role in p['roles']:
  r=workspace.get(f"/api/fitlore/projects/{p['id']}?view={role}")
  assert r.status_code==200
  assert all(t['owner']==role for t in r.json()['tasks'])
 reopened=TestClient(app).get('/api/fitlore/projects/'+p['id']).json()
 assert reopened['id']==p['id'] and reopened['revision']==p['revision']
 assert reopened['resources']==p['resources'] and reopened['tasks']==p['tasks']


def test_catalog_and_reference_images_are_bundled_locally(workspace):
 catalog=workspace.get('/api/fashion/catalog').json()
 for look in catalog['looks']:
  assert look['image'].startswith('/static/images/')
  response=workspace.get(look['image'])
  assert response.status_code==200 and response.content.startswith(b'\xff\xd8')
 for path in Path('web/images').glob('*.jpg'):
  assert path.stat().st_size>10000 and path.read_bytes().startswith(b'\xff\xd8')


def test_local_photo_boundary_remains_clear_when_cloud_is_locked(workspace,monkeypatch):
 monkeypatch.setenv('PATCHBRIEF_ALLOW_CLOUD','false')
 r=workspace.post('/api/fitlore/consult',json={'question':'Can you identify my colour season and body measurements from my photos?','mode':'live'})
 assert r.status_code==200 and r.json()['mode']=='boundary'
 assert 'No photo analysis' in r.json()['notice']
