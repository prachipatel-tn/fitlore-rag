import pytest
from fastapi.testclient import TestClient
from app.main import app

@pytest.fixture
def studio(tmp_path,monkeypatch):
 monkeypatch.setenv('FITLORE_STUDIO_DB',str(tmp_path/'studio.sqlite3'))
 monkeypatch.delenv('PATCHBRIEF_ACCESS_TOKEN',raising=False)
 return TestClient(app)
def h(role):return {'X-Demo-Role':role}
def test_persistent_board_and_approval(studio):
 r=studio.post('/api/studio/looks/generate',headers=h('consultant'))
 assert r.status_code==200
 id=r.json()[0]['id']
 assert studio.post(f'/api/studio/looks/{id}/decision',json={'status':'approved'},headers=h('client')).status_code==409
 assert studio.post(f'/api/studio/looks/{id}/decision',json={'status':'review'},headers=h('consultant')).status_code==200
 assert studio.post(f'/api/studio/looks/{id}/decision',json={'status':'approved'},headers=h('client')).status_code==200
 assert studio.get('/api/studio/state').json()['metrics']['approved_looks']==1

def test_brief_revision_invalidates_old_approval(studio):
 l=studio.post('/api/studio/looks/generate').json()[0]
 studio.post(f"/api/studio/looks/{l['id']}/decision",json={'status':'review'})
 studio.post(f"/api/studio/looks/{l['id']}/decision",json={'status':'approved'},headers=h('client'))
 p=studio.get('/api/studio/state').json()['project'];p['goals']='New direction'
 assert studio.put('/api/studio/project',json=p).status_code==200
 s=studio.get('/api/studio/state').json()
 assert s['metrics']['stale_looks']==3 and s['metrics']['approved_looks']==0
 assert studio.post(f"/api/studio/looks/{l['id']}/decision",json={'status':'review'}).status_code==409

def test_demo_role_action_boundaries(studio):
 assert studio.post('/api/studio/looks/generate',headers=h('client')).status_code==403
 assert studio.post('/api/studio/expenses',headers=h('analyst'),json={'title':'Item','amount_cents':1200}).status_code==403
 assert studio.get('/api/studio/state',headers=h('invalid')).status_code==400
 assert studio.get('/api/studio/state',headers=h('client')).json()['documents']==[]

def test_sources_safe_url_and_unknown_price(studio):
 assert studio.post('/api/studio/sources',json={'title':'X','url':'javascript:alert(1)'}).status_code==422
 r=studio.post('/api/studio/sources',json={'title':'Owned blazer','type':'Owned item','notes':'Already owned'})
 assert r.status_code==200 and r.json()['price_cents'] is None
 assert r.json()['availability']=='Unverified'

def test_finance_cents_and_projection(studio):
 item=studio.post('/api/studio/expenses',headers=h('finance'),json={'title':'Tailoring estimate','amount_cents':12550}).json()
 assert studio.post('/api/studio/expenses/'+item['id']+'/approve',headers=h('finance')).status_code==200
 assert studio.get('/api/studio/state',headers=h('finance')).json()['metrics']['approved_estimate_cents']==12550
 assert studio.get('/api/studio/state',headers=h('client')).json()['expenses']==[]

def test_sketch_persistence_and_validation(studio):
 strokes=[{'color':'#252820','points':[{'x':10,'y':20},{'x':30,'y':40}]}]
 assert studio.put('/api/studio/sketch',json={'strokes':strokes}).status_code==200
 assert studio.get('/api/studio/state').json()['sketch'][0]['strokes']==strokes
 assert studio.put('/api/studio/sketch',json={'strokes':[{'points':[{'x':-1,'y':0}]}]}).status_code==422

def test_evidence_is_cited_and_no_match_abstains(studio):
 a=studio.post('/api/studio/ask',json={'question':'client preferences budget'}).json()
 assert a['citations'] and any('500' in c['text'] for c in a['citations'])
 b=studio.post('/api/studio/ask',json={'question':'quantum entanglement blackholes'}).json()
 assert not b['citations'] and 'could not find' in b['answer']
 assert b['rag_complete'] is False

def test_document_ingestion_and_reference_validation(studio):
 studio.post('/api/studio/documents',json={'title':'Special fixture','text':'The campaign codename is orchid.'})
 a=studio.post('/api/studio/ask',json={'question':'orchid codename'}).json()
 assert a['citations'][0]['title']=='Special fixture'
 assert studio.post('/api/studio/looks',json={'title':'Unknown','source_ids':['missing']}).status_code==422
