import pytest
from fastapi.testclient import TestClient
from app.main import app
from app import studio_rag as rag

@pytest.fixture
def client(tmp_path,monkeypatch):
 monkeypatch.setenv('FITLORE_STUDIO_DB',str(tmp_path/'studio.db'))
 monkeypatch.setenv('PATCHBRIEF_ALLOW_CLOUD','false')
 monkeypatch.setenv('FITLORE_RAG_ALLOW_CLOUD','false')
 monkeypatch.setenv('NEBIUS_EMBEDDING_MODEL','test-embedding')
 monkeypatch.delenv('PATCHBRIEF_ACCESS_TOKEN',raising=False)
 return TestClient(app)

def test_locked_before_external_calls(client,monkeypatch):
 def forbidden(*a):raise AssertionError('Network adapter invoked while locked')
 monkeypatch.setattr(rag,'embed',forbidden)
 monkeypatch.setattr(rag,'generate',forbidden)
 assert client.post('/api/studio/rag/index').status_code==403
 assert client.post('/api/studio/rag/answer',json={'question':'What is my budget?'}).status_code==403
 assert client.get('/api/studio/rag/status').json()['indexed'] is False

def fake_providers(monkeypatch):
 monkeypatch.setattr(rag,'gate',lambda:None)
 monkeypatch.setattr(rag,'reserve',lambda kind:None)
 monkeypatch.setattr(rag,'embed',lambda texts:[[1.0,float('budget' in t.lower())] for t in texts])
 monkeypatch.setattr(rag,'generate',lambda question,evidence:{'claims':[{'text':evidence[0]['text'],'source_ids':[evidence[0]['id']]}],'suggestions':[],'missing_information':[]})

def test_full_pipeline_with_fake_providers_and_cache(client,monkeypatch):
 fake_providers(monkeypatch)
 a=client.post('/api/studio/rag/index')
 assert a.status_code==200 and a.json()['indexed']==4
 assert client.post('/api/studio/rag/index').json()['cached'] is True
 b=client.post('/api/studio/rag/answer',json={'question':'What is the client budget?'})
 assert b.status_code==200 and b.json()['claims'][0]['source_ids'][0] in {e['id'] for e in b.json()['evidence']}

def test_stale_index_blocks_retrieval_before_embedding(client,monkeypatch):
 fake_providers(monkeypatch);client.post('/api/studio/rag/index')
 client.post('/api/studio/documents',json={'title':'Update','text':'The new event is outdoors.'})
 monkeypatch.setattr(rag,'embed',lambda texts:pytest.fail('Stale index must not call embeddings'))
 assert client.get('/api/studio/rag/status').json()['stale'] is True
 assert client.post('/api/studio/rag/answer',json={'question':'Where is the event?'}).status_code==409

def test_unknown_citations_rejected(client,monkeypatch):
 fake_providers(monkeypatch);client.post('/api/studio/rag/index')
 monkeypatch.setattr(rag,'generate',lambda q,e:{'claims':[{'text':'Unsupported claim','source_ids':['invented']}],'suggestions':[],'missing_information':[]})
 r=client.post('/api/studio/rag/answer',json={'question':'What should I wear?'})
 assert r.status_code==409 and 'citation' in r.json()['detail']

def test_chunk_overlap_and_no_trailing_duplicate():
 words=[f'w{i}' for i in range(450)]
 nodes=rag.chunks([{'id':'doc','revision':1,'title':'Test','text':' '.join(words)}])
 assert len(nodes)==3
 assert nodes[0]['text'].split()[-40:]==nodes[1]['text'].split()[:40]
 assert len(rag.chunks([{'id':'doc','revision':1,'title':'Test','text':' '.join(words[:230])}]))==1

def test_nonfinite_vectors_rejected():
 with pytest.raises(ValueError):rag.validate_vectors([[float('nan'),1]],1)
 with pytest.raises(ValueError):rag.validate_vectors([[0,0]],1)
 with pytest.raises(ValueError):rag.validate_vectors([[1,2],[1]],2)


@pytest.mark.parametrize('finish_reason', ['stop', 'length'])
def test_generator_requests_constrained_json_and_rejects_truncation(monkeypatch,finish_reason):
 import json
 from types import SimpleNamespace
 import llama_index.llms.openai_like as provider
 monkeypatch.setenv('NEBIUS_MODEL','test-model')
 monkeypatch.setenv('NEBIUS_API_KEY','test-not-a-secret')
 monkeypatch.setattr(rag,'reserve',lambda kind:None)
 captured={}
 class FakeLLM:
  def __init__(self,**kwargs):captured.update(kwargs)
  def chat(self,messages):
   value={'claims':[{'text':'Budget: $100','source_ids':['known']}],'suggestions':[],'missing_information':[]}
   return SimpleNamespace(message=SimpleNamespace(content=json.dumps(value)),raw={'choices':[{'finish_reason':finish_reason}]},additional_kwargs={'prompt_tokens':100,'completion_tokens':50,'total_tokens':150,'ignored':'private'})
 monkeypatch.setattr(provider,'OpenAILike',FakeLLM)
 evidence=[{'id':'known','text':'Budget: $100','title':'Brief'}]
 if finish_reason=='length':
  with pytest.raises(ValueError,match='token limit'):rag.generate('Budget?',evidence)
 else:
  result=rag.validate_answer(rag.generate('Budget?',evidence),evidence)
  assert result['provider_usage']=={'prompt_tokens':100,'completion_tokens':50,'total_tokens':150}
 schema=captured['additional_kwargs']['response_format']['json_schema']['schema']
 assert schema['properties']['claims']['items']['properties']['source_ids']['items']['enum']==['known']
 assert captured['max_retries']==0


def test_real_source_ids_do_not_allow_unsupported_paraphrase():
 evidence=[{'id':'shoe','text':'Black loafers. Footwear: Flats.'}]
 answer={'claims':[{'text':'These loafers are comfortable and guaranteed suitable.','source_ids':['shoe']}],'suggestions':[],'missing_information':[]}
 with pytest.raises(ValueError,match='exact excerpt'):rag.validate_answer(answer,evidence)
 answer['claims'][0]['text']='Footwear: Flats.'
 assert rag.validate_answer(answer,evidence)['claims']==answer['claims']
