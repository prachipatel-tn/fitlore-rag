'use strict';
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const state = {cases:[], policies:{}, selected:null, result:null, status:null, token:'', tab:'brief'};
let toastTimer;
function toast(message, error=false) { const box=$('#toast'); box.textContent=message;box.className=error?'error':'';box.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>box.hidden=true,error?12000:4500); }
async function api(path, options={}) {
  const response=await fetch(path,{...options,headers:{'Content-Type':'application/json',...(state.token?{'Authorization':`Bearer ${state.token}`} : {}),...options.headers}});
  let data; try { data=await response.json(); } catch { throw new Error(`Unexpected response (${response.status}).`); }
  if(!response.ok) throw new Error(typeof data.detail==='string'?data.detail:`Request validation failed (${response.status}). Check input fields.`);
  return data;
}
function view(name) {
  $$('.view').forEach(el=>el.hidden=el.id!==`view-${name}`);
  $$('.nav-item').forEach(el=>el.classList.toggle('active',el.dataset.view===name));
  $('#breadcrumb').textContent={workspace:'Review desk',sources:'Source library',evaluation:'Evaluation',connections:'Connections',architecture:'Architecture'}[name];
  if(name==='sources') loadSources();
  if(name==='connections') loadStatus();
}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>view(b.dataset.view)));
$('#banner-connect').onclick=()=>view('connections');
$('#mode-indicator').onclick=()=>view('connections');
function renderCases(){
  $('#case-list').innerHTML=state.cases.map(c=>`<button type="button" class="case-card ${state.selected===c.id?'selected':''}" data-case="${esc(c.id)}" aria-pressed="${state.selected===c.id}"><span class="case-icon">${{vite:'ϟ',next:'N',axios:'a'}[c.id]||'↥'}</span><span><span class="case-title">${esc(c.package)} <span class="severity ${esc(c.severity)}">${esc(c.severity)}</span></span><small>${esc(c.cve)} · ${esc(c.version)}</small></span><span class="radio"></span></button>`).join('');
  $$('[data-case]').forEach(b=>b.onclick=()=>selectCase(b.dataset.case));
}
function selectCase(id){
  const c=state.cases.find(c=>c.id===id); if(!c)return;
  state.selected=id;renderCases();$('#installed-version').value=c.version;$('#question').value=c.question;$('#context').value=c.context;$('#alert-json').value=JSON.stringify(c.alert,null,2);$('#omit-versions').checked=false;
  resetResult();
}
function stage(index){$$('.workflow-step').forEach((el,i)=>el.classList.toggle('current',i===index));}
function resetResult(){ state.result=null;$('#result-content').hidden=true;$('#loading-state').hidden=true;$('#empty-state').hidden=false;$('#result-label').textContent='AWAITING ANALYSIS';stage(0); }
function updatePolicy(){
  const choice=$('#policy-select').value;
  if(choice==='custom'){ $('#policy-text').value='';$('.policy-details').open=true; }
  else $('#policy-text').value=state.policies[choice]?.text||'';
}
$('#policy-select').onchange=()=>{updatePolicy();markStale();};
function markStale(){if(state.result)$('#result-label').textContent='INPUT CHANGED · REGENERATE';}
$('#analysis-form').addEventListener('input',markStale);
$('#analysis-mode').onchange=()=>{$('#mode-indicator').textContent=$('#analysis-mode').value==='live'?'● Live requested':'● Demo mode';markStale();};
$('#policy-text').addEventListener('input',()=>{$('#policy-select').value='custom';});
$('#policy-file').onchange=async(e)=>{const f=e.target.files[0];if(!f)return;if(f.size>16000)return toast('Policy must be less than 16 KB.',true);$('#policy-select').value='custom';$('#policy-text').value=await f.text();markStale();toast('Policy loaded. Review the text before generating.');};
$('#import-button').onclick=()=>$('#alert-file').click();
$('#alert-file').onchange=async(e)=>{
  const f=e.target.files[0];if(!f)return;
  try{if(f.size>64000)throw new Error('Upload one alert JSON file smaller than 64 KB.');const alert=JSON.parse(await f.text());if(!alert.dependency?.package?.name||!alert.security_advisory)throw new Error('Expected a single Dependabot alert object with dependency and security_advisory fields.');state.selected=null;renderCases();$('#alert-json').value=JSON.stringify(alert,null,2);$('#installed-version').value='';$('#context').value='';$('#question').value='Prepare a cited remediation review for this alert.';$('.advanced').open=true;resetResult();toast('Alert imported. Enter the exact installed version from your lockfile.');$('#installed-version').focus();}
  catch(err){toast(err.message,true);}finally{e.target.value='';}
};
function requestBody(){
  let alert;try{alert=JSON.parse($('#alert-json').value);}catch{throw new Error('The alert JSON is invalid. Fix it under “Inspect alert”.');}
  const packageName=alert.dependency?.package?.name;
  return {alert,installed_version:$('#installed-version').value.trim(),question:$('#question').value,context:$('#context').value,policy_text:$('#policy-text').value,policy_name:state.policies[$('#policy-select').value]?.name ? `${state.policies[$('#policy-select').value].name} (fictional sample)` : 'Supplied team policy',mode:$('#analysis-mode').value,exclude_sources:$('#omit-versions').checked?[`${packageName}-versions`]:[]};
}
$('#analysis-form').onsubmit=async(e)=>{
  e.preventDefault();let body;try{body=requestBody();}catch(err){toast(err.message,true);return;}
  const button=$('#analyze-button');button.disabled=true;$('#empty-state').hidden=true;$('#result-content').hidden=true;$('#loading-state').hidden=false;$('#result-label').textContent='ANALYZING';stage(1);
  $('#loading-copy').textContent=body.mode==='live'?'Retrieving from Pinecone and preparing a Nebius/Fireworks draft.':'Searching the local source snapshot and checking exact versions.';
  try{const result=await api('/api/analyze',{method:'POST',body:JSON.stringify(body),signal:AbortSignal.timeout(120000)});state.result=result;renderResult(result);toast('Review brief ready. Inspect the evidence before exporting.');}
  catch(err){resetResult();toast(err.name==='TimeoutError'?'Analysis timed out. No result was substituted.':err.message,true);}
  finally{button.disabled=false;$('#loading-state').hidden=true;}
};
function citations(ids){return ids.map(id=>`<button class="citation" data-source="${esc(id)}">↗ ${esc(id)}</button>`).join('');}
function evidenceCard(d){return `<article class="evidence-card" id="source-${esc(d.id)}"><div class="source-id">${esc(d.id)}</div><h3>${esc(d.title)}</h3><p>${esc(d.text)}</p><div class="source-meta"><span>${esc(d.kind)}</span>${d.published?`<span>Published ${esc(d.published)}</span>`:''}<span>Snapshot ${esc(d.snapshot)}</span></div>${d.url?`<a href="${esc(d.url)}" target="_blank" rel="noopener noreferrer">Open vendor advisory ↗</a>`:'<span class="source-meta">Provided for this run; not an external source.</span>'}</article>`;}
function renderResult(r){
  stage(2);
  $('#result-content').hidden=false;$('#empty-state').hidden=true;$('#result-label').textContent=r.mode==='demo'?'DEMO · NO MODEL CALLED':'LIVE · AI DRAFT';
  $('#mode-indicator').textContent=r.mode==='demo'?'● Demo mode':'● Live result';
  $('#evidence-count').textContent=r.evidence.length;
  const status={in_affected_range:'In affected range',outside_documented_range:'Outside listed range',unknown:'Evidence needed'}[r.version_status];
  $('#tab-brief').innerHTML=`<div class="result-title"><div><div class="result-id">${esc(r.identifier)} · ${esc(r.package)}</div><h3>${esc(r.title)}</h3></div><span class="status-label ${esc(r.version_status)}">${esc(status)}</span></div>
    <div class="result-metrics"><div><small>Installed version</small><strong>${esc(r.installed_version)}</strong></div><div><small>Documented fix</small><strong>${esc(r.documented_patch||'Unresolved')}</strong></div><div><small>Exposure</small><strong class="tiny-value">Under investigation</strong></div></div>
    <p class="footnote">${r.documented_patch?'The documented fix addresses this advisory in the same release branch; it is not a recommendation for the latest secure release.':'No upgrade target inferred. Outside a listed range does not mean the application is secure.'} ${citations(r.version_source_ids)}</p>
    <div class="section-caption">01 / TEAM RESPONSE</div><div class="policy-callout">${esc(r.policy_clause||'Review timing needs a team decision.')}<small>${esc(r.policy_name)} · ${r.policy_clause?'timed from alert intake, not a resolution promise':'no unambiguous supported clause found'}</small>${r.policy_clause?citations(['team-policy']):''}</div>
    <div class="section-caption">02 / CHANGE CONSIDERATIONS</div>${r.recommendations.length?r.recommendations.map(x=>`<div class="recommendation"><p>${esc(x.text)}</p>${citations(x.source_ids)}<small>${esc(x.kind)}</small></div>`).join(''):'<p class="footnote">No supported recommendation available in this corpus.</p>'}
    <div class="section-caption">03 / SUGGESTED VERIFICATION</div><ul class="check-list">${r.suggested_tests.map(t=>`<li>${esc(t)}</li>`).join('')}</ul><p class="footnote">Engineering suggestions for reviewer consideration, not vendor-mandated tests.</p>
    <div class="gaps"><div class="section-caption">KEEP THESE QUESTIONS OPEN</div><ul class="check-list">${r.gaps.map(t=>`<li>${esc(t)}</li>`).join('')}</ul></div><p class="footnote">${esc(r.citation_check)}</p>`;
  $('#tab-evidence').innerHTML=r.evidence.length?r.evidence.map(evidenceCard).join(''):'<p>No relevant evidence retrieved.</p>';
  $('#ticket-text').textContent=r.markdown;$('#run-meta').textContent=`${r.elapsed_ms} ms · ${r.retrieval}`;
  $$('[data-source]').forEach(b=>b.onclick=()=>{switchTab('evidence');document.getElementById(`source-${b.dataset.source}`)?.scrollIntoView({behavior:'smooth',block:'center'});});
  switchTab('brief');
}
function switchTab(tab){state.tab=tab;$$('[data-tab]').forEach(b=>{b.classList.toggle('active',b.dataset.tab===tab);b.setAttribute('aria-selected',b.dataset.tab===tab);});$$('.result-tab').forEach(el=>el.hidden=el.id!==`tab-${tab}`);}
$$('[data-tab]').forEach(b=>b.onclick=()=>switchTab(b.dataset.tab));
function download(contents,name,type){const url=URL.createObjectURL(new Blob([contents],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('#export-md').onclick=()=>{if(state.result){download(state.result.markdown,`patchbrief-${state.result.identifier}.md`,'text/markdown');stage(3);}};
$('#export-json').onclick=()=>{if(state.result)download(JSON.stringify(state.result,null,2),`patchbrief-${state.result.identifier}.json`,'application/json');};
$('#copy-ticket').onclick=async()=>{try{await navigator.clipboard.writeText(state.result.markdown);toast('Markdown copied.');}catch{toast('Clipboard unavailable. Use Export ticket instead.',true);}};
async function loadSources(){try{const data=await api('/api/corpus');$('#source-library').innerHTML=data.documents.map(evidenceCard).join('');}catch(e){toast(e.message,true);}}
async function loadStatus(){
  try{state.status=await api('/api/status');const s=state.status;
    const items=[['Nebius','Generation & embeddings',s.provider==='nebius'?s.model:'Embedding provider','N'],['Pinecone','Vector retrieval',s.pinecone,'◈'],['LlamaIndex','RAG orchestration','Installed · used by live pipeline','▥'],['Fireworks AI','Optional generation provider',s.provider==='fireworks'?s.model:'Available as an alternate adapter','✳'],['Replit','Deployment target','Configuration included · not deployed','▦']];
    $('#connection-grid').innerHTML=items.map(([name,desc,status,icon])=>`<div class="connection-card"><div class="service-icon">${icon}</div><h3>${name}</h3><p>${desc}</p><span class="connection-status">${esc(status)}</span></div>`).join('');
    $('#missing-config').textContent=s.missing.length?`Still needed: ${s.missing.join(', ')}`:'Environment values are present. Run ingestion and a live request to verify the connections.';
  }catch(e){toast(e.message,true);}
}
$('#refresh-status').onclick=()=>loadStatus();
$('#unlock').onclick=async()=>{state.token=$('#access-token').value;try{await boot();toast('Workspace unlocked.');}catch(e){toast(e.message,true);}};

const evalCases=[
  ['Vite vulnerable boundary','vite','5.4.11','in_affected_range','5.4.12'],
  ['Vite patch boundary','vite','5.4.12','outside_documented_range',null],
  ['Vite 6 branch','vite','6.0.8','in_affected_range','6.0.9'],
  ['Vite 4 branch','vite','4.5.5','in_affected_range','4.5.6'],
  ['Next.js 14 branch','next','14.2.24','in_affected_range','14.2.25'],
  ['Next.js patched','next','14.2.25','outside_documented_range',null],
  ['Next.js 15 branch','next','15.2.2','in_affected_range','15.2.3'],
  ['Next.js 11 needs review','next','11.1.4','in_affected_range',null],
  ['Axios vulnerable','axios','1.7.9','in_affected_range','1.8.2'],
  ['Axios advisory gap','axios','1.8.1','unknown',null],
  ['Axios patched','axios','1.8.2','outside_documented_range',null],
  ['Reject version ranges','vite','^5.4.11','unknown',null],
  ['Reject prerelease inference','vite','5.4.12-beta.1','unknown',null],
  ['Missing version passage','vite','5.4.11','unknown',null,'omit'],
  ['Policy changes response','vite','5.4.11','in_affected_range','5.4.12','policy'],
];
function initEval(){ $('#eval-rows').innerHTML=evalCases.map((c,i)=>`<tr><td>${esc(c[0])}</td><td>${esc(c[5]==='policy'?'48-hour review clause':c[3].replaceAll('_',' '))}</td><td id="eval-${i}">Not run</td></tr>`).join('');$('#eval-summary').innerHTML='<div class="eval-stat"><strong>15</strong><small>Behavior checks</small></div><div class="eval-stat"><strong>—</strong><small>Passing cases</small></div><div class="eval-stat"><strong>Local</strong><small>Demo API only</small></div>';}
$('#run-eval').onclick=async()=>{
  const button=$('#run-eval');button.disabled=true;let passed=0;initEval();
  for(let i=0;i<evalCases.length;i++){
    const [name,id,version,expected,patch,variant]=evalCases[i];const sample=state.cases.find(c=>c.id===id);const cell=$(`#eval-${i}`);cell.textContent='Running…';
    try{if(!sample)throw new Error('Unlock/load the workspace first.');const r=await api('/api/analyze',{method:'POST',body:JSON.stringify({alert:sample.alert,installed_version:version,question:sample.question,context:sample.context,policy_text:state.policies[variant==='policy'?'accelerated':'standard'].text,policy_name:'Fictional evaluation policy',mode:'demo',exclude_sources:variant==='omit'?[`${id}-versions`]:[]})});const ids=new Set(r.evidence.map(d=>d.id));const ok=r.version_status===expected&&r.documented_patch===patch&&r.exposure_status==='under_investigation'&&r.recommendations.every(x=>x.source_ids.length&&x.source_ids.every(id=>ids.has(id)))&&(variant!=='policy'||r.policy_clause==='Moderate: review within 48 hours');cell.textContent=ok?'✓ Pass':'✕ Fail';cell.className=ok?'pass':'fail';if(ok)passed++;}
    catch(e){cell.textContent='Error';cell.className='fail';cell.title=e.message;}
  }
  $('#eval-summary').innerHTML=`<div class="eval-stat"><strong>15</strong><small>Behavior checks</small></div><div class="eval-stat"><strong>${passed}/15</strong><small>Passing cases · just measured</small></div><div class="eval-stat"><strong>${Math.round(passed/15*100)}%</strong><small>Behavior pass rate · not faithfulness</small></div>`;button.disabled=false;toast(`${passed} of 15 demo checks passed.`,passed!==15);
};
async function boot(){await loadStatus();const data=await api('/api/examples');state.cases=data.cases;state.policies=data.policies;updatePolicy();selectCase('vite');initEval();}
boot().catch(e=>{toast(e.message,true);view('connections');});
