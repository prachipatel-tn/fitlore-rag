'use strict';
window.FitLorePhotos = (()=>{
 const editorial={"city": {"image": "edit-city", "url": "https://www.pexels.com/photo/woman-in-elegant-navy-blue-blazer-and-trousers-walking-on-the-square-18709016/", "credit": "Omar Ramadan", "alt": "Woman wearing a navy blazer and trousers on a city square"}, "townhall": {"image": "edit-presence", "url": "https://www.pexels.com/photo/woman-in-black-long-sleeves-and-gray-trouser-standing-beside-the-black-chair-while-looking-afar-8871845/", "credit": "Mikhail Nilov", "alt": "Woman in a black top and grey trousers in a meeting room"}, "creator": {"image": "edit-creator", "url": "https://www.pexels.com/photo/man-photographing-models-in-a-studio-13448981/", "credit": "Airam Dato-on", "alt": "Photographer and two models during a studio fashion shoot"}, "conference": {"image": "edit-tailoring", "url": "https://www.pexels.com/photo/woman-in-gray-coat-and-pants-5991637/", "credit": "Hakim Santoso", "alt": "Close-up of a grey belted tailored jacket and matching trousers"}, "boutique": {"image": "edit-boutique", "url": "https://www.pexels.com/photo/clothes-racks-in-a-boutique-5424922/", "credit": "Arina Krasnikova", "alt": "Clothing rails inside a boutique"}, "dinner": {"image": "edit-dinner", "url": "https://www.pexels.com/photo/elegant-candlelit-dinner-table-setting-36547499/", "credit": "Catherine Chechun", "alt": "Candlelit dinner table with elegant place settings"}, "designer": {"image": "free-black-dress", "url": "https://www.pexels.com/photo/gorgeous-woman-in-long-black-dress-4614891/", "credit": "HONG SON", "alt": "Woman wearing a long black dress outside a cafe"}};
 const refs={"Top": ["free-white-shirt", "Woman wearing a white shirt and grey trousers", "https://www.pexels.com/photo/woman-wearing-white-dress-shirt-and-gray-pants-15221657/"], "Bottom": ["free-grey-trousers", "Woman wearing grey trousers and a black blazer on steps", "https://www.pexels.com/photo/young-woman-on-grunge-steps-7000908/"], "Layer": ["free-navy-blazer", "Woman wearing a navy blazer against a light background", "https://www.pexels.com/photo/portrait-of-a-pretty-brunette-wearing-a-navy-blue-jacket-19989572/"], "Shoes": ["free-black-loafers", "Black textured loafers displayed on a light surface", "https://www.pexels.com/photo/elegant-black-loafers-on-minimalist-display-38721541/"], "Sneakers": ["free-white-sneakers", "White sneakers against a dark red background", "https://www.pexels.com/photo/photo-of-white-sneakers-11324525/"], "Accessory": ["free-blue-scarf", "Woman wearing a blue headscarf outdoors", "https://www.pexels.com/photo/woman-wearing-blue-scarf-1972032/"], "Dress": ["free-black-dress", "Woman wearing a long black dress outside a cafe", "https://www.pexels.com/photo/gorgeous-woman-in-long-black-dress-4614891/"]};
 const safe=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function garment(g,editable=false){
  const ref=refs[g.category==='Shoes'&&g.footwear==='Sneakers'?'Sneakers':g.category]||refs.Top,own=Boolean(g.image);
  const credit=ref[2]?`<a href="${safe(ref[2])}" target="_blank" rel="noopener noreferrer" title="Free Pexels style inspiration, not a photo of your exact item.">Inspiration · Pexels ↗</a>`:'Style reference';
  return `<figure class="piece-figure ${!own?'licensed-reference':''}"><img src="${safe(own?g.image:'/static/images/'+ref[0]+'.jpg')}" alt="${safe(own?g.name:ref[1])}" loading="eager"><figcaption>${own?'Your photo':credit}</figcaption>${editable&&!own?`<button class="piece-upload" data-edit="${safe(g.id)}" aria-label="Add a photo of ${safe(g.name)}">＋ Add your photo</button>`:''}</figure>`;
 }
 function savedCover(session,garments){
  if(session.mode==='boundary')return '<span class="saved-type">CAPABILITY CHECK<em>Clear boundaries.<br>Better decisions.</em></span>';
  if(session.demo_case_id&&editorial[session.demo_case_id]){
   const p=editorial[session.demo_case_id];
   return `<img src="/static/images/${p.image}.jpg" alt="${safe(p.alt)}" loading="lazy"><span>Sample story · editorial inspiration</span>`;
  }
  const ids=[...new Set((session.looks||[]).flatMap(l=>l.item_ids||[]))];
  const items=ids.map(id=>garments.find(g=>g.id===id)).filter(Boolean).slice(0,4);
  if(!items.length)return '<span class="saved-type">SAVED STYLING NOTES<em>Your brief.<br>Your next move.</em></span>';
  return `<span class="saved-piece-grid" data-piece-count="${items.length}">${items.map(g=>{
   const ref=refs[g.category==='Shoes'&&g.footwear==='Sneakers'?'Sneakers':g.category]||refs.Top;
   return `<span class="saved-piece"><img src="${safe(g.image||'/static/images/'+ref[0]+'.jpg')}" alt="${safe(g.image?g.name:ref[1]+'; category inspiration for '+g.name)}" loading="lazy"><span>${safe(g.name)}</span></span>`;
  }).join('')}</span><span class="saved-cover-label">${items.every(g=>g.image)?'Your garment photos':'Selected pieces · reference photos'}</span>`;
 }
 document.addEventListener('error',event=>{
  const img=event.target;
  if(img.tagName!=='IMG'||img.dataset.fallbackApplied)return;
  img.dataset.fallbackApplied='true';img.src='/static/images/edit-boutique.jpg';img.alt='Editorial style reference; original image unavailable';
  const caption=img.closest('figure')?.querySelector('figcaption');
  if(caption)caption.textContent='Reference photography · original image unavailable';
 },true);
 return {garment,editorial,savedCover};
})();
