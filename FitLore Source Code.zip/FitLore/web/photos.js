'use strict';
window.FitLorePhotos = (()=>{
 const refs={
  Top:['reference-ivory-shirt','Ivory long-sleeve shirt reference','https://www.careofcarl.at/de/nn07-colby-shirt-ivory'],
  Bottom:['reference-charcoal-trousers','Charcoal straight-leg trouser reference','https://www.marksandspencer.com/straight-leg-trousers/p/clp60275924'],
  Layer:['reference-navy-blazer','Navy tailored blazer reference','https://windsor.de/int/en/women/blazers-waistcoats/cotton-stretch-blazer-in-navy/p/30046143-10001376-415'],
  Shoes:['reference-black-loafers','Black leather loafer reference','https://www.tresmode.com/products/tresmode-hak-black-mens-leather-penny-loafers'],
  Sneakers:['reference-white-sneakers','White low-top sneaker reference','https://aldoshoes.co.uk/products/finespec-white-13451152'],
  Accessory:['reference-blue-scarf','Blue silk scarf reference','https://sophieguyot.com/en/silk/1335-square-90-silk-twill-plain.html'],
  Dress:['1595777457583-95e059d581b8','A person wearing a red occasion dress']
 };
 const safe=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function garment(g,editable=false){
  const ref=refs[g.category==='Shoes'&&g.footwear==='Sneakers'?'Sneakers':g.category]||refs.Top,own=Boolean(g.image);
  const credit=ref[2]?`<a href="${safe(ref[2])}" target="_blank" rel="noopener noreferrer" title="Third-party reference, not your exact item. Price and availability not verified.">Style reference ↗</a>`:'Style reference';
  return `<figure class="piece-figure ${!own&&ref[0].startsWith('reference-')?'product-reference':''}"><img src="${safe(own?g.image:'/static/images/'+ref[0]+'.jpg')}" alt="${safe(own?g.name:ref[1])}" loading="eager"><figcaption>${own?'Your photo':credit}</figcaption>${editable&&!own?`<button class="piece-upload" data-edit="${safe(g.id)}" aria-label="Add a photo of ${safe(g.name)}">＋ Add your photo</button>`:''}</figure>`;
 }
 document.addEventListener('error',event=>{
  const img=event.target;
  if(img.tagName!=='IMG'||img.dataset.fallbackApplied)return;
  img.dataset.fallbackApplied='true';img.src='/static/images/1613186145425-5bb4eca455d7.jpg';img.alt='Editorial style reference; original image unavailable';
  const caption=img.closest('figure')?.querySelector('figcaption');
  if(caption)caption.textContent='Reference photography · original image unavailable';
 },true);
 return {garment};
})();
